import fs from 'node:fs';
import ts from 'typescript';
import assert from 'node:assert/strict';
const js=ts.transpileModule(fs.readFileSync(new URL('../lib/study-edit.ts',import.meta.url),'utf8'),{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
const {applyStudyEdit:edit,editTools}=await import('data:text/javascript;base64,'+Buffer.from(js).toString('base64'));
const fresh=()=>({tasks:[{id:'t',date:'2026-10-13',actual:90,status:'已完成',topic:'极限'}],logs:[{id:'l',date:'2026-10-13',hours:2,items:{高数:'极限',英语:'词汇'},subjectHours:{高数:2}}],mistakes:[{id:'m',date:'2026-10-13',question:'完整题目'.repeat(500)}],progress:{'高数|极限':{state:'学习中'}},reports:[{id:'r',date:'2026-10-13',type:'日报'},{id:'w',date:'2026-10-12',end:'2026-10-18',type:'周报',summary:'周报'}]});
for(const [kind,id] of [['任务','t'],['学习记录','l'],['错题','m'],['知识点','高数|极限'],['报告','r']]){
 const d=fresh(),calls=[],refresh=(_,day)=>calls.push(day);
 const result=edit(d,'delete_study_record',{record_type:kind,record_id:id},refresh);
 assert.equal(edit(d,'list_deleted_study_records',{},refresh).count,1);
 assert.equal(edit(d,'delete_study_record',{record_type:kind,record_id:id},refresh).already_deleted,true);
 const restored=edit(d,'restore_study_record',{deletion_id:result.deletion_id},refresh);
 assert.equal(restored.record_id,id);
 assert.equal(edit(d,'list_deleted_study_records',{},refresh).count,0);
 assert.equal(edit(d,'restore_study_record',{deletion_id:result.deletion_id},refresh).already_restored,true);
 if(kind==='错题')assert.equal(d.mistakes[0].question.length,2000);
 if(['任务','学习记录','错题'].includes(kind))assert.ok(calls.length&&d.reports.find(r=>r.id==='w').needsRegeneration);
}
let d=fresh();edit(d,'edit_study_log',{date:'2026-10-13',items:{高数:null},hours:null,subject_hours:{高数:null},notes:''},()=>{});
assert.deepEqual(d.logs[0].items,{英语:'词汇'});assert.equal(d.logs[0].hours,null);assert.deepEqual(d.logs[0].subjectHours,{});
edit(d,'edit_study_task',{task_id:'t',date:'2026-10-14',actual_minutes:null,status:'待开始'},()=>{});assert.equal(d.tasks[0].actual,null);assert.equal(d.tasks[0].topic,'极限');
for(const a of [{task_id:'t',date:'2026-02-30'},{task_id:'t',actual_minutes:-1},{task_id:'t',status:'假的'},{task_id:'t',time:'25:00'},{task_id:'t',foo:1}])assert.throws(()=>edit(d,'edit_study_task',a,()=>{}));
assert.throws(()=>edit(d,'delete_study_record',{record_type:'__proto__',record_id:'x'},()=>{}));
assert.throws(()=>edit(d,'delete_study_record',{record_type:'错题',record_id:'missing'},()=>{}));
let result=edit(d,'delete_study_record',{record_type:'学习记录',record_id:'l'},()=>{});d.logs.push({id:'new',date:'2026-10-13'});assert.throws(()=>edit(d,'restore_study_record',{deletion_id:result.deletion_id},()=>{}));
assert.equal(new Set(editTools.map(t=>t.name)).size,5);
console.log('PASS: five tool schemas, all record types, full-content restore, idempotent retries, restore conflicts, partial edits, null clearing, invalid input, affected reports');
