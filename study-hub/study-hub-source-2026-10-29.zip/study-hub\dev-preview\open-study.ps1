# Desktop launcher: starts the local study server (with saved data) if needed, then opens it in the browser.
# Kept ASCII-only so Windows PowerShell 5.1 parses it regardless of file encoding.
$port = 5180
$url = "http://localhost:$port/"
$running = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
if (-not $running) {
  $server = Join-Path $PSScriptRoot 'server.ps1'
  Start-Process powershell -WindowStyle Hidden -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$server`"", '-Port', $port, '-Persist')
  for ($i = 0; $i -lt 40 -and -not (Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue); $i++) { Start-Sleep -Milliseconds 250 }
}
Start-Process $url
