import fs from 'node:fs';
import ts from 'typescript';
import assert from 'node:assert/strict';
import { webcrypto } from 'node:crypto';
globalThis.crypto??=webcrypto;
const read=p=>fs.readFileSync(new URL('../'+p,import.meta.url),'utf8');
const compile=source=>ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
const load=source=>import('data:text/javascript;base64,'+Buffer.from(compile(source)).toString('base64'));
const account=await load(read('lib/study-account.ts'));
const scopeA=await account.studyCacheScope('account-A'),scopeB=await account.studyCacheScope('account-B');
assert.notEqual(scopeA,scopeB);assert.equal(scopeA.length,64);
assert.equal(await account.matchesStudyScope(new Request('https://test/api/sync',{headers:{'X-Study-Scope':scopeA}}),'account-B'),false);
assert.deepEqual(account.makeEmptyStudyData(),{tasks:[],logs:[],mistakes:[],reports:[],progress:{},history:[],chat:[]});
assert.match(read('app/mcp/route.ts'),/function makeInitialData\(\): StudyData \{ return makeEmptyStudyData\(\); \}/);
assert.ok(!read('app/mcp/route.ts').includes('log-1011'),'MCP source no longer carries original private seed records');
let user=null,queries=0;
const payloadA=JSON.stringify({tasks:[{id:'private-A',topic:'A的私人任务'}],logs:[],mistakes:[],reports:[]});
const rows=new Map([['account-A',{userId:'account-A',payload:payloadA,revision:4,updatedAt:'before'}]]);
function fakeDb(){return {
  select(){queries++;return {from(){let id;const query={where(condition){id=condition.value;return query;},limit(){return Promise.resolve([...rows.values()].filter(row=>!id||row.userId===id));}};return query;}};},
  insert(){return {values(value){return {onConflictDoNothing(){return {returning(){if(rows.has(value.userId))return [];rows.set(value.userId,value);return [{revision:value.revision}];}};}};}};},
};}
globalThis.accountMocks={getChatGPTUser:async()=>user,getDb:fakeDb,eq:(_column,value)=>({value}),and:(...x)=>x,sql:()=>'',studyStates:{userId:'user_id',revision:'revision',updatedAt:'updated_at'},withStudyAudit:(_before,after)=>after,...account};
const mocked=source=>source.replace(/^import .*?;\r?\n/gm,'').replace("export const dynamic", "const {getChatGPTUser,getDb,eq,and,sql,studyStates,withStudyAudit,matchesStudyScope,studyCacheScope}=globalThis.accountMocks;\nexport const dynamic");
const sync=await load(mocked(read('app/api/sync/route.ts')));
const session=await load(mocked(read('app/api/session/route.ts')));
assert.equal((await sync.GET(new Request('https://test/api/sync'))).status,401);
assert.equal(queries,0,'anonymous access never reaches data');
user={userId:'account-B',displayName:'B'};
assert.equal((await sync.GET(new Request('https://test/api/sync',{headers:{'X-Study-Scope':scopeA}}))).status,403);
assert.equal(queries,0,'account-switch mismatch never reads another record');
let state=await (await session.GET()).json();assert.equal(state.cacheScope,scopeB);assert.equal(state.legacyCacheEligible,false);
assert.equal((await (await sync.GET(new Request('https://test/api/sync',{headers:{'X-Study-Scope':scopeB}}))).json()).data,null,'new B has no A records');
const before=queries;
assert.equal((await sync.PUT(new Request('https://test/api/sync',{method:'PUT',headers:{'X-Study-Scope':scopeA},body:JSON.stringify({data:{tasks:['old account']},revision:0})}))).status,403);
assert.equal(queries,before);
assert.equal((await sync.PUT(new Request('https://test/api/sync',{method:'PUT',headers:{'X-Study-Scope':scopeB},body:JSON.stringify({data:account.makeEmptyStudyData(),revision:0})}))).status,200);
assert.equal(rows.get('account-A').payload,payloadA,'B write preserves A byte-for-byte');assert.equal(rows.get('account-B').payload,JSON.stringify(account.makeEmptyStudyData()));
user={userId:'account-A',displayName:'A'};
assert.equal((await (await sync.GET(new Request('https://test/api/sync',{headers:{'X-Study-Scope':scopeA}}))).json()).data.tasks[0].id,'private-A');
state=await (await session.GET()).json();assert.equal(state.cacheScope,scopeA);assert.equal(state.legacyCacheEligible,false,'unscoped migration disabled once multiple accounts exist');
rows.delete('account-B');state=await (await session.GET()).json();assert.equal(state.legacyCacheEligible,true,'only the original sole stored account may migrate legacy cache');
console.log('PASS: anonymous 401, per-user scope, cross-account 403 before DB, A/B reads and writes isolated, empty new accounts, legacy cache eligibility');
if(process.env.STUDY_TEST_DOM){
  const {JSDOM}=await import(process.env.STUDY_TEST_DOM);
  for(const loggedIn of [false,true]){
    const dom=new JSDOM('<body class="booting"><div id="bootScreen"></div><div class="app"></div></body>',{url:'http://localhost:5173',runScripts:'outside-only'}),w=dom.window;
    let reads=0,started=0;const scripts=[];
    Object.defineProperty(w,'localStorage',{value:{getItem(){reads++;throw Error('No unscoped storage access');}}});
    w.fetch=async()=>({ok:loggedIn,json:async()=>({authenticated:true,cacheScope:scopeB,legacyCacheEligible:false,displayName:'B'})});
    w.startStudySession=async()=>{started++;};const append=w.document.body.appendChild.bind(w.document.body);
    w.document.body.appendChild=node=>{const result=append(node);if(node.tagName==='SCRIPT'){scripts.push(node.src);queueMicrotask(()=>node.onload());}return result;};
    await w.eval(read('public/study-bootstrap.js'));
    assert.equal(reads,0,'anonymous and new accounts never read legacy owner cache');
    if(loggedIn){assert.equal(started,1);assert.equal(w.StudySession.cacheKey,'xilien-study-v2:'+scopeB);assert.equal(scripts.length,6);assert.equal(w.document.querySelector('#bootScreen'),null);}
    else {assert.equal(started,0);assert.equal(scripts.length,0);assert.ok(w.document.querySelector('a[href^="/signin-with-chatgpt"]'));}
    dom.window.close();
  }
  console.log('PASS: anonymous bootstrap does not load app or read cache; new account storage namespace is independent; UI loads only after identity confirmation');
}
delete globalThis.accountMocks;
