import { makeEmptyStudyData } from "../../lib/study-account";
import { and, eq, sql } from "drizzle-orm";
import { getChatGPTUser } from "../../app/chatgpt-auth";
import { getDb } from "../../db";
import { studyStates } from "../../db/schema";
import { editTools, applyStudyEdit } from "../../lib/study-edit";
import { withStudyAudit } from "../../lib/study-audit";

export const dynamic = "force-dynamic";
const MAX_BODY_BYTES = 1_000_000;
const subjects = ["高数", "线代", "数学二", "408", "英语", "政治", "健身", "复盘"];
const mistakeCauses = ["概念不清", "条件遗漏", "方法选择错误", "计算失误", "审题错误", "知识遗忘"];
const progressStates = ["未开始", "学习中", "待巩固", "已掌握", "需要复习"];

type StudyData = {
  tasks: any[];
  logs: any[];
  mistakes: any[];
  reports: any[];
  progress: Record<string, any>;
  history: any[];
  chat: any[];
  [key: string]: any;
};

const toolDefinitions = [
  ...editTools,
  {
    name: "get_study_day",
    description: "读取用户自己的某一天学习档案：计划任务、实际记录、错题、应复测错题和日报。没有记录时明确返回空数据，不推断完成情况。",
    inputSchema: { type: "object", properties: { date: { type: "string", description: "日期 YYYY-MM-DD；省略时读取今天（Asia/Shanghai）" } }, additionalProperties: false },
  },
  {
    name: "record_study_update",
    description: "把用户在聊天中明确汇报的实际学习事实合并写入指定日期，自动更新该日日报。仅传用户明确说出的字段；缺失字段不要猜测。重复补充会合并同一条日期记录，不会新建重复日报。",
    inputSchema: { type: "object", required: ["date"], properties: {
      date: { type: "string", description: "实际学习日期 YYYY-MM-DD" },
      hours: { type: "number", minimum: 0, maximum: 24, description: "当天总有效学习小时数；用户明确提供时才传" },
      subject_hours: { type: "object", description: "明确提供的科目有效小时数，键仅限科目名；不会用总时长反推各科" },
      items: { type: "object", description: "用户明确完成的科目与内容，例如 {高数: 复习无穷小比较}；仅放实际，不放计划" },
      notes: { type: "string", description: "明确汇报的补充事实或更正" },
    }, additionalProperties: false },
  },
  {
    name: "complete_study_task",
    description: "将用户明确表示已完成的一项计划任务标记为完成。请先读取当天任务，再使用返回的 task_id。不得仅因计划存在就标记完成。",
    inputSchema: { type: "object", required: ["date", "task_id"], properties: {
      date: { type: "string", description: "任务日期 YYYY-MM-DD" },
      task_id: { type: "string", description: "get_study_day 返回的任务 ID" },
      actual_minutes: { type: "number", minimum: 0, maximum: 1440, description: "用户明确说明的实际用时，分钟" },
    }, additionalProperties: false },
  },
  {
    name: "defer_study_task",
    description: "将一项未完成的计划任务顺延到新日期。原任务 ID 保持不变，只移动计划日期；不会标记为完成，也不会自动堆积其他任务。",
    inputSchema: { type: "object", required: ["task_id", "from_date", "to_date"], properties: {
      task_id: { type: "string" }, from_date: { type: "string", description: "原计划日期 YYYY-MM-DD" }, to_date: { type: "string", description: "新的计划日期 YYYY-MM-DD" },
      time: { type: "string", description: "可选新开始时间 HH:mm" },
    }, additionalProperties: false },
  },
  {
    name: "upsert_study_task",
    description: "按用户在聊天中提出的计划新增或修改学习任务。此工具只写计划，不表示任务已完成。已有任务通过 task_id 修改。",
    inputSchema: { type: "object", required: ["date", "subject", "topic", "duration_minutes"], properties: {
      date: { type: "string", description: "计划日期 YYYY-MM-DD" },
      task_id: { type: "string", description: "修改已有任务时传入其 ID；新计划省略" },
      subject: { type: "string", enum: subjects },
      chapter: { type: "string" },
      topic: { type: "string", minLength: 1, maxLength: 500 },
      duration_minutes: { type: "number", minimum: 0, maximum: 1440 },
      priority: { type: "string", enum: ["高", "中", "低"] },
      time: { type: "string", description: "可选开始时间 HH:mm" },
    }, additionalProperties: false },
  },
  {
    name: "record_mistake",
    description: "将用户明确指出的错题加入《错题》，安排首次复测；相同题目的聊天重试会合并。只有明确说独立复测仍错时才增加错误次数。",
    inputSchema: { type: "object", required: ["date", "subject", "topic"], properties: {
      date: { type: "string", description: "做错或复测日期 YYYY-MM-DD" },
      subject: { type: "string", enum: subjects },
      source: { type: "string" }, chapter: { type: "string" }, topic: { type: "string", minLength: 1, maxLength: 300 },
      question: { type: "string", maxLength: 6000 }, wrong_answer: { type: "string", maxLength: 6000 },
      error_steps: { type: "string", maxLength: 6000 }, correct_answer: { type: "string", maxLength: 6000 },
      solution: { type: "string", maxLength: 6000 },
      problem_id: { type: "string", maxLength: 160, description: "可选题号或稳定题目标识，用于精确合并同一道题" },
      cause: { type: "string", enum: mistakeCauses },
      repeat_error: { type: "boolean", description: "仅当用户明确说这次是独立复测且再次做错时设为 true" },
    }, additionalProperties: false },
  },
  {
    name: "search_mistakes",
    description: "在《错题》中查询用户自己的错题，可按日期、科目、状态、复测日期或题目关键字筛选。",
    inputSchema: { type: "object", properties: {
      query: { type: "string", maxLength: 200 }, subject: { type: "string", enum: subjects }, status: { type: "string" },
      date_from: { type: "string" }, date_to: { type: "string" }, due_on: { type: "string" }, limit: { type: "integer", minimum: 1, maximum: 100 },
    }, additionalProperties: false },
  },
  {
    name: "update_mistake",
    description: "修订一条已有错题，或记录一次独立复测。只有独立复测通过时才能标记为已掌握；复测失败会增加错误次数并重排复测。",
    inputSchema: { type: "object", required: ["mistake_id"], properties: {
      mistake_id: { type: "string" }, subject: { type: "string", enum: subjects }, source: { type: "string" }, chapter: { type: "string" }, topic: { type: "string" },
      question: { type: "string" }, wrong_answer: { type: "string" }, error_steps: { type: "string" }, correct_answer: { type: "string" }, solution: { type: "string" },
      cause: { type: "string", enum: mistakeCauses }, next_review: { type: "string" }, retest_date: { type: "string" }, retest_result: { type: "string", enum: ["通过", "失败"] }, independent_retest: { type: "boolean" },
    }, additionalProperties: false },
  },
  {
    name: "update_knowledge_progress",
    description: "根据用户明确确认的学习进展更新知识点状态与复习日期。已掌握必须有用户确认或独立测试通过作为依据。",
    inputSchema: { type: "object", required: ["subject", "topic", "status"], properties: {
      subject: { type: "string", enum: subjects }, chapter: { type: "string" }, topic: { type: "string", minLength: 1, maxLength: 300 },
      status: { type: "string", enum: progressStates }, last_review: { type: "string", description: "最近复习日期 YYYY-MM-DD" },
      next_review: { type: "string", description: "下次复习日期 YYYY-MM-DD" }, score: { type: "number", minimum: 0, maximum: 100 }, note: { type: "string", maxLength: 1000 },
    }, additionalProperties: false },
  },
  {
    name: "get_knowledge_progress",
    description: "读取知识点学习进度，可按科目、知识点和状态筛选；未建立的知识点保持未开始/未记录，不推断为掌握。",
    inputSchema: { type: "object", properties: { subject: { type: "string", enum: subjects }, topic: { type: "string" }, status: { type: "string", enum: progressStates }, limit: { type: "integer", minimum: 1, maximum: 200 } }, additionalProperties: false },
  },
  {
    name: "get_study_reports",
    description: "查询已保存的日报、周报、月报。可按报告类型或日期范围筛选。",
    inputSchema: { type: "object", properties: { report_type: { type: "string", enum: ["日报", "周报", "月报"] }, date_from: { type: "string" }, date_to: { type: "string" }, limit: { type: "integer", minimum: 1, maximum: 100 } }, additionalProperties: false },
  },
  {
    name: "generate_daily_report",
    description: "读取并汇总指定日期的真实计划、实际学习记录和错题，创建或更新日报。未记录字段会保留为未记录。",
    inputSchema: { type: "object", required: ["date"], properties: { date: { type: "string" } }, additionalProperties: false },
  },
  {
    name: "update_study_report",
    description: "修订已有报告的摘要或补充说明，不改写底层学习记录。只传用户明确要求修改的字段。",
    inputSchema: { type: "object", required: ["report_id"], properties: { report_id: { type: "string" }, summary: { type: "string", maxLength: 2000 }, content_updates: { type: "object" } }, additionalProperties: false },
  },
  {
    name: "generate_period_report",
    description: "基于档案中真实记录生成并保存周报或月报。未记录的时长、完成率保持未记录，不把空白当成零或未完成。",
    inputSchema: { type: "object", required: ["report_type", "start_date", "end_date"], properties: {
      report_type: { type: "string", enum: ["周报", "月报"] },
      start_date: { type: "string", description: "统计周期首日 YYYY-MM-DD" },
      end_date: { type: "string", description: "统计周期末日 YYYY-MM-DD，含当日" },
    }, additionalProperties: false },
  },
  {
    name: "search_study_data",
    description: "跨任务、学习记录、错题、报告和进度搜索历史数据；支持关键词、日期范围、科目、报告类型及错题状态。返回真实匹配项，不生成历史事实。",
    inputSchema: { type: "object", properties: {
      query: { type: "string", maxLength: 200 }, date_from: { type: "string" }, date_to: { type: "string" }, subject: { type: "string", enum: subjects },
      report_type: { type: "string", enum: ["日报", "周报", "月报"] }, mistake_status: { type: "string" }, limit: { type: "integer", minimum: 1, maximum: 100 },
    }, additionalProperties: false },
  },
  {
    name: "sync_learning_day",
    description: "晚间批量同步当前对话中可确认的某一天学习事实：合并实际记录、更新明确完成/部分完成/未完成的任务、去重并写入错题、更新知识点进度，并生成/更新日报。只传本次可确认信息；不读取其他 ChatGPT 历史聊天，不得把未提及的内容推测为完成。",
    inputSchema: { type: "object", required: ["date"], properties: {
      date: { type: "string" },
      study_update: { type: "object", description: "当天总时长、分科时长、实际学习内容和补充事实；不明确的字段省略" },
      task_updates: { type: "array", items: { type: "object", required: ["task_id", "status"], properties: { task_id: { type: "string" }, status: { type: "string", enum: ["已完成", "部分完成", "未完成"] }, actual_minutes: { type: "number", minimum: 0, maximum: 1440 } }, additionalProperties: false } },
      new_mistakes: { type: "array", items: { type: "object", required: ["subject", "topic"], properties: { subject: { type: "string", enum: subjects }, source: { type: "string" }, chapter: { type: "string" }, topic: { type: "string" }, question: { type: "string" }, problem_id: { type: "string" }, wrong_answer: { type: "string" }, error_steps: { type: "string" }, correct_answer: { type: "string" }, solution: { type: "string" }, cause: { type: "string", enum: mistakeCauses } }, additionalProperties: false } },
      progress_updates: { type: "array", items: { type: "object", required: ["subject", "topic", "status"], properties: { subject: { type: "string", enum: subjects }, chapter: { type: "string" }, topic: { type: "string" }, status: { type: "string", enum: progressStates }, last_review: { type: "string" }, next_review: { type: "string" }, score: { type: "number", minimum: 0, maximum: 100 }, note: { type: "string" } }, additionalProperties: false } },
    }, additionalProperties: false },
  },
  {
    name: "get_study_change_history",
    description: "读取本账号学习档案的变更日志，包括修改时间、对象、变更字段及新旧值摘要。",
    inputSchema: { type: "object", properties: { date_from: { type: "string" }, date_to: { type: "string" }, limit: { type: "integer", minimum: 1, maximum: 100 } }, additionalProperties: false },
  },
];

export async function POST(request: Request) {
  let rpc: any;
  try {
    const raw = await request.text();
    if (new TextEncoder().encode(raw).byteLength > MAX_BODY_BYTES) return Response.json({ error: "请求过大" }, { status: 413 });
    rpc = JSON.parse(raw);
  } catch {
    return Response.json({ jsonrpc: "2.0", id: null, error: { code: -32700, message: "无效的 JSON 请求" } }, { status: 400 });
  }
  if (!rpc || rpc.jsonrpc !== "2.0" || typeof rpc.method !== "string") {
    return Response.json({ jsonrpc: "2.0", id: rpc?.id ?? null, error: { code: -32600, message: "无效的 JSON-RPC 请求" } }, { status: 400 });
  }

  if (rpc.method === "notifications/initialized" || rpc.method === "notifications/cancelled") return new Response(null, { status: 202 });
  if (rpc.method === "initialize") {
    return rpcResponse(rpc.id, { protocolVersion: rpc.params?.protocolVersion || "2025-03-26", capabilities: { tools: { listChanged: false } }, serverInfo: { name: "xilien-study-hub", version: "1.0.0" } });
  }
  if (rpc.method === "ping") return rpcResponse(rpc.id, {});
  if (rpc.method === "tools/list") return rpcResponse(rpc.id, { tools: toolDefinitions });
  if (rpc.method !== "tools/call") return Response.json({ jsonrpc: "2.0", id: rpc.id ?? null, error: { code: -32601, message: "不支持的方法" } }, { status: 200 });

  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "请先使用同一 ChatGPT 账号连接并登录此私有学习系统" }, { status: 401 });
  const name = rpc.params?.name;
  const args = rpc.params?.arguments ?? {};
  try {
    const result = await callTool(name, args, user.userId, String(rpc.id ?? crypto.randomUUID()));
    return rpcResponse(rpc.id, { content: [{ type: "text", text: JSON.stringify(result) }], structuredContent: result, isError: false });
  } catch (error) {
    const message = error instanceof Error ? error.message : "操作失败";
    return rpcResponse(rpc.id, { content: [{ type: "text", text: message }], isError: true });
  }
}

function rpcResponse(id: unknown, result: unknown) {
  return Response.json({ jsonrpc: "2.0", id: id ?? null, result }, { headers: { "Cache-Control": "no-store" } });
}

function validDate(value: any): value is string {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(parsed.valueOf()) && parsed.toISOString().slice(0, 10) === value;
}
function todayShanghai() { return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Shanghai", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date()); }
function plusDays(date: string, days: number) { const d = new Date(`${date}T12:00:00Z`); d.setUTCDate(d.getUTCDate() + days); return d.toISOString().slice(0, 10); }
function makeInitialData(): StudyData { return makeEmptyStudyData(); }

async function callTool(name: string, a: any, userId: string, requestId: string) {
  if (!toolDefinitions.some((t) => t.name === name)) throw new Error("未知工具");
  if (editTools.some(t => t.name === name)) {
    if (name === "list_deleted_study_records") return applyStudyEdit(await readData(userId), name, a, upsertDailyReport);
    let result: any;
    await mutateData(userId, d => {
      result = applyStudyEdit(d, name, a, upsertDailyReport);
      d.history.push({ at: new Date().toISOString(), action: "聊天接口删改：" + name, requestId });
    });
    return result;
  }
  if (name === "get_study_day") {
    const date = a.date || todayShanghai();
    if (!validDate(date)) throw new Error("日期格式必须是 YYYY-MM-DD");
    const data = await readData(userId);
    const tasks = data.tasks.filter((x) => x.date === date);
    const log = data.logs.find((x) => x.date === date) ?? null;
    const mistakes = data.mistakes.filter((x) => x.date === date);
    const dueReviews = data.mistakes.filter((x) => x.next === date && x.status !== "已掌握");
    const report = data.reports.find((x) => x.type === "日报" && x.date === date) ?? null;
    return { date, tasks, log, mistakes, dueReviews, report, note: "未出现的数据表示未记录，不代表未完成。" };
  }
  if (name === "record_study_update") {
    if (!validDate(a.date)) throw new Error("日期格式必须是 YYYY-MM-DD");
    if (a.hours !== undefined && (!finiteRange(a.hours, 0, 24))) throw new Error("hours 必须在 0–24 之间");
    if (a.subject_hours !== undefined) validateSubjectHours(a.subject_hours);
    if (a.items !== undefined) validateSubjectText(a.items);
    if (a.notes !== undefined && (typeof a.notes !== "string" || a.notes.length > 3000)) throw new Error("notes 格式无效");
    if (a.hours === undefined && !Object.keys(a.items || {}).length && !Object.keys(a.subject_hours || {}).length && !a.notes) throw new Error("请至少提供一项明确的学习事实；空白信息没有写入");
    const data = await mutateData(userId, (d) => {
      let log = d.logs.find((x) => x.date === a.date);
      if (!log) { log = { id: `log-${a.date}`, date: a.date, hours: null, items: {}, confirmed: true, source: "ChatGPT 聊天记录" }; d.logs.push(log); }
      if (a.hours !== undefined) log.hours = a.hours;
      if (a.items) log.items = { ...(log.items || {}), ...a.items };
      if (a.subject_hours) log.subjectHours = { ...(log.subjectHours || {}), ...a.subject_hours };
      if (a.notes) log.notes = a.notes;
      log.confirmed = true; log.source = "ChatGPT 聊天记录"; log.updatedAt = new Date().toISOString();
      upsertDailyReport(d, a.date);
      d.history.push({ at: new Date().toISOString(), action: "聊天接口更新学习记录", date: a.date, requestId });
    });
    return { success: true, date: a.date, log: data.logs.find((x) => x.date === a.date), report: data.reports.find((x) => x.type === "日报" && x.date === a.date) };
  }
  if (name === "complete_study_task") {
    if (!validDate(a.date) || typeof a.task_id !== "string") throw new Error("需要有效日期和 task_id");
    if (a.actual_minutes !== undefined && !finiteRange(a.actual_minutes, 0, 1440)) throw new Error("actual_minutes 必须在 0–1440 之间");
    const data = await mutateData(userId, (d) => {
      const task = d.tasks.find((x) => x.id === a.task_id && x.date === a.date);
      if (!task) throw new Error("没有找到该日期的任务，请先调用 get_study_day 查看 task_id");
      task.status = "已完成";
      if (a.actual_minutes !== undefined) task.actual = a.actual_minutes;
      upsertDailyReport(d, a.date);
      d.history.push({ at: new Date().toISOString(), action: "聊天接口完成任务", date: a.date, id: task.id, requestId });
    });
    return { success: true, task: data.tasks.find((x) => x.id === a.task_id), report: data.reports.find((x) => x.type === "日报" && x.date === a.date) };
  }
  if (name === "defer_study_task") {
    if (!validDate(a.from_date) || !validDate(a.to_date) || a.to_date <= a.from_date || typeof a.task_id !== "string") throw new Error("延期日期必须晚于原计划日期");
    if (a.time !== undefined && !/^([01]\d|2[0-3]):[0-5]\d$/.test(a.time)) throw new Error("时间请使用 HH:mm");
    const data = await mutateData(userId, (d) => {
      const task = d.tasks.find((x) => x.id === a.task_id && x.date === a.from_date);
      if (!task) throw new Error("没有找到原日期的该项任务");
      task.deferredFrom = task.deferredFrom || a.from_date; task.deferredAt = new Date().toISOString();
      task.date = a.to_date; task.status = "待开始";
      if (a.time) task.time = a.time;
      d.history.push({ at: new Date().toISOString(), action: "聊天接口顺延任务", from: a.from_date, to: a.to_date, id: task.id, requestId });
    });
    return { success: true, task: data.tasks.find((x) => x.id === a.task_id) };
  }
  if (name === "upsert_study_task") {
    if (!validDate(a.date) || !subjects.includes(a.subject) || typeof a.topic !== "string" || !a.topic.trim() || !finiteRange(a.duration_minutes, 0, 1440)) throw new Error("计划字段无效");
    if (a.time !== undefined && !/^([01]\d|2[0-3]):[0-5]\d$/.test(a.time)) throw new Error("时间请使用 HH:mm");
    const data = await mutateData(userId, (d) => {
      let task = a.task_id ? d.tasks.find((x) => x.id === a.task_id && x.date === a.date) : d.tasks.find((x) => x.date === a.date && x.subject === a.subject && x.topic.trim() === a.topic.trim());
      if (a.task_id && !task) throw new Error("未找到待修改的任务");
      if (!task) { task = { id: crypto.randomUUID(), date: a.date, subject: a.subject, chapter: a.chapter || "", topic: a.topic.trim(), duration: a.duration_minutes, actual: null, status: "待开始", priority: a.priority || "中", time: a.time || "" }; d.tasks.push(task); }
      else Object.assign(task, { subject: a.subject, chapter: a.chapter ?? task.chapter, topic: a.topic.trim(), duration: a.duration_minutes, priority: a.priority ?? task.priority, time: a.time ?? task.time });
      d.history.push({ at: new Date().toISOString(), action: a.task_id ? "聊天接口修改计划" : "聊天接口新增计划", date: a.date, id: task.id, requestId });
    });
    return { success: true, task: data.tasks.find((x) => x.date === a.date && x.subject === a.subject && x.topic === a.topic.trim()) };
  }
  if (name === "record_mistake") {
    if (!validDate(a.date) || !subjects.includes(a.subject) || typeof a.topic !== "string" || !a.topic.trim()) throw new Error("错题日期、科目和知识点不能为空");
    for (const key of ["source", "chapter", "question", "problem_id", "wrong_answer", "error_steps", "correct_answer", "solution"]) if (a[key] !== undefined && (typeof a[key] !== "string" || a[key].length > 6000)) throw new Error(`字段 ${key} 无效`);
    if (a.cause !== undefined && !mistakeCauses.includes(a.cause)) throw new Error("错误原因分类无效");
    const data = await mutateData(userId, (d) => {
      const topic = a.topic.trim();
      const match = d.mistakes.find((m) => m.subject === a.subject && m.topic === topic && ((a.problem_id && m.problemId === a.problem_id) || (a.question && m.question === a.question && m.source === (a.source || ""))));
      if (match) {
        for (const [src, dst] of [["source","source"],["chapter","chapter"],["question","question"],["problem_id","problemId"],["wrong_answer","wrong"],["error_steps","errorSteps"],["correct_answer","correct"],["solution","solution"],["cause","reason"]]) if (a[src] !== undefined) match[dst] = a[src];
        if (a.repeat_error === true) { match.count = (match.count || 1) + 1; match.status = match.count >= 3 ? "高频错误" : "重点薄弱"; }
        match.date = a.date; match.last = a.date; match.next = plusDays(a.date, match.count >= 3 ? 3 : match.count >= 2 ? 2 : 1);
      } else {
        d.mistakes.unshift({ id: crypto.randomUUID(), date: a.date, subject: a.subject, source: a.source || "", chapter: a.chapter || "", topic, question: a.question || "", problemId: a.problem_id || "", wrong: a.wrong_answer || a.error_steps || "", errorSteps: a.error_steps || "", correct: a.correct_answer || "", solution: a.solution || "", reason: a.cause || "待分析", count: 1, status: "待复测", next: plusDays(a.date, 1), last: "未复测" });
      }
      upsertDailyReport(d, a.date);
      d.history.push({ at: new Date().toISOString(), action: "聊天接口记录错题", date: a.date, topic, requestId });
    });
    return { success: true, mistake: data.mistakes.find((m) => m.subject === a.subject && m.topic === a.topic.trim() && (a.problem_id ? m.problemId === a.problem_id : a.question ? m.question === a.question && m.source === (a.source || "") : m.date === a.date)), report: data.reports.find((x) => x.type === "日报" && x.date === a.date) };
  }
  if (name === "search_mistakes") {
    const data = await readData(userId), query = String(a.query || "").toLowerCase();
    if (a.date_from && !validDate(a.date_from) || a.date_to && !validDate(a.date_to) || a.due_on && !validDate(a.due_on)) throw new Error("日期格式必须为 YYYY-MM-DD");
    const matches = data.mistakes.filter((m) => (!a.subject || m.subject === a.subject) && (!a.status || m.status === a.status) && (!a.date_from || m.date >= a.date_from) && (!a.date_to || m.date <= a.date_to) && (!a.due_on || m.next === a.due_on) && (!query || JSON.stringify(m).toLowerCase().includes(query))).slice(0, clampLimit(a.limit, 50, 100));
    return { count: matches.length, mistakes: matches };
  }
  if (name === "update_mistake") {
    if (typeof a.mistake_id !== "string") throw new Error("需要 mistake_id");
    for (const k of ["next_review", "retest_date"]) if (a[k] !== undefined && !validDate(a[k])) throw new Error(`${k} 日期格式必须为 YYYY-MM-DD`);
    if (a.retest_result && a.independent_retest !== true) throw new Error("只有用户明确完成独立复测后才能登记复测结果");
    const data = await mutateData(userId, (d) => {
      const mistake = d.mistakes.find((m) => m.id === a.mistake_id);
      if (!mistake) throw new Error("未找到该错题");
      for (const [from, to] of [["subject","subject"],["source","source"],["chapter","chapter"],["topic","topic"],["question","question"],["wrong_answer","wrong"],["error_steps","errorSteps"],["correct_answer","correct"],["solution","solution"],["cause","reason"]]) if (a[from] !== undefined) mistake[to] = a[from];
      if (a.next_review) mistake.next = a.next_review;
      if (a.retest_result) {
        const date = a.retest_date || todayShanghai(); mistake.last = date;
        if (a.retest_result === "通过") { mistake.status = "已掌握"; mistake.next = ""; }
        else { mistake.count = (mistake.count || 1) + 1; mistake.status = mistake.count >= 3 ? "高频错误" : "重点薄弱"; mistake.next = plusDays(date, mistake.count >= 3 ? 3 : 2); }
        upsertDailyReport(d, date);
      }
      d.history.push({ at: new Date().toISOString(), action: "聊天接口修订错题", id: mistake.id, requestId });
    });
    return { success: true, mistake: data.mistakes.find((m) => m.id === a.mistake_id) };
  }
  if (name === "update_knowledge_progress") {
    if (!subjects.includes(a.subject) || typeof a.topic !== "string" || !a.topic.trim() || !progressStates.includes(a.status)) throw new Error("知识点进度字段无效");
    if (a.status === "已掌握" && !a.note) throw new Error("请先确认用户明确表示已掌握或独立测试通过，再提供依据说明 note");
    for (const k of ["last_review", "next_review"]) if (a[k] !== undefined && !validDate(a[k])) throw new Error(`${k} 日期格式必须为 YYYY-MM-DD`);
    if (a.score !== undefined && !finiteRange(a.score, 0, 100)) throw new Error("score 必须在 0–100 之间");
    const key = `${a.subject}|${a.topic.trim()}`;
    const data = await mutateData(userId, (d) => {
      d.progress[key] = { ...(d.progress[key] || {}), state: a.status, last: a.last_review || todayShanghai(), next: a.next_review || d.progress[key]?.next || "", chapter: a.chapter || d.progress[key]?.chapter || "", ...(a.score === undefined ? {} : { score: a.score }), ...(a.note === undefined ? {} : { note: a.note }) };
      d.history.push({ at: new Date().toISOString(), action: "聊天接口更新知识点", key, state: a.status, requestId });
    });
    return { success: true, topic: key, progress: data.progress[key] };
  }
  if (name === "get_knowledge_progress") {
    const data = await readData(userId), query = String(a.topic || "").toLowerCase();
    const items = Object.entries(data.progress).map(([key, value]) => ({ key, subject: key.split("|")[0], topic: key.split("|").slice(1).join("|"), ...(value as object) })).filter((p: any) => (!a.subject || p.subject === a.subject) && (!a.status || p.state === a.status) && (!query || p.topic.toLowerCase().includes(query))).slice(0, clampLimit(a.limit, 100, 200));
    return { count: items.length, progress: items };
  }
  if (name === "get_study_reports") {
    if (a.date_from && !validDate(a.date_from) || a.date_to && !validDate(a.date_to)) throw new Error("日期格式必须为 YYYY-MM-DD");
    const data = await readData(userId), reports = data.reports.filter((r) => (!a.report_type || r.type === a.report_type) && (!a.date_from || (r.end || r.date) >= a.date_from) && (!a.date_to || r.date <= a.date_to)).sort((x, y) => y.date.localeCompare(x.date)).slice(0, clampLimit(a.limit, 30, 100));
    return { count: reports.length, reports };
  }
  if (name === "generate_daily_report") {
    if (!validDate(a.date)) throw new Error("日期格式必须为 YYYY-MM-DD");
    const data = await mutateData(userId, (d) => { upsertDailyReport(d, a.date); d.history.push({ at: new Date().toISOString(), action: "聊天接口生成日报", date: a.date, requestId }); });
    return { success: true, report: data.reports.find((r) => r.type === "日报" && r.date === a.date) };
  }
  if (name === "update_study_report") {
    if (a.summary === undefined && a.content_updates === undefined) throw new Error("请提供要修订的摘要或报告内容");
    if (a.summary !== undefined && (typeof a.summary !== "string" || a.summary.length > 2000)) throw new Error("摘要格式无效");
    if (a.content_updates !== undefined && (!a.content_updates || typeof a.content_updates !== "object" || Array.isArray(a.content_updates) || JSON.stringify(a.content_updates).length > 15000)) throw new Error("报告修订内容无效或过大");
    const data = await mutateData(userId, (d) => {
      const report = d.reports.find((r) => r.id === a.report_id);
      if (!report) throw new Error("未找到该报告");
      if (a.summary !== undefined) report.summary = a.summary;
      if (a.content_updates) report.content = { ...(report.content || {}), ...a.content_updates };
      report.updated = new Date().toISOString();
      d.history.push({ at: new Date().toISOString(), action: "聊天接口修订报告", id: report.id, requestId });
    });
    return { success: true, report: data.reports.find((r) => r.id === a.report_id) };
  }
  if (name === "generate_period_report") {
    if (!validDate(a.start_date) || !validDate(a.end_date) || !["周报", "月报"].includes(a.report_type) || a.end_date < a.start_date) throw new Error("报告类型或日期范围无效");
    const length = (Date.parse(`${a.end_date}T12:00:00Z`) - Date.parse(`${a.start_date}T12:00:00Z`)) / 86400000 + 1;
    if (length > 32) throw new Error("报告范围最多 32 天");
    const data = await mutateData(userId, (d) => {
      const logs = d.logs.filter((l) => l.date >= a.start_date && l.date <= a.end_date);
      const tasks = d.tasks.filter((t) => t.date >= a.start_date && t.date <= a.end_date);
      const knownTasks = tasks.filter((t) => t.status === "已完成" || t.status === "未完成");
      const completed = knownTasks.filter((t) => t.status === "已完成").length;
      const recordedHours = logs.filter((l) => typeof l.hours === "number").map((l) => l.hours as number);
      const hours = recordedHours.length ? recordedHours.reduce((sum, n) => sum + n, 0) : null;
      const mistakes = d.mistakes.filter((m) => m.date >= a.start_date && m.date <= a.end_date);
      const existing = d.reports.find((r) => r.type === a.report_type && r.date === a.start_date && r.end === a.end_date);
      const report = {
        id: existing?.id || `${a.report_type}-${a.start_date}-${a.end_date}`, type: a.report_type,
        date: a.start_date, end: a.end_date,
        summary: `记录 ${logs.length} 天 · 学习时长 ${hours == null ? "未记录" : `${hours} 小时`} · 计划完成率 ${knownTasks.length ? `${Math.round(completed / knownTasks.length * 100)}%` : "未记录"}`,
        content: {
          hours, recordDays: logs.length, rate: knownTasks.length ? Math.round(completed / knownTasks.length * 100) : null,
          tasks: knownTasks.length, done: completed, mistakes: mistakes.length,
          subjects: subjects.map((subject) => ({ subject, hours: logs.reduce((sum, l) => sum + (Number(l.subjectHours?.[subject]) || 0), 0) })),
          weak: d.mistakes.filter((m) => m.count >= 2).map((m) => m.topic),
          plan: logs.length ? "根据本期记录和已标记的薄弱知识点安排后续复习。" : "本期没有学习记录，暂不评价学习趋势。",
        }, updated: new Date().toISOString(), source: "聊天接口（基于真实记录汇总）",
      };
      const index = d.reports.findIndex((r) => r.type === a.report_type && r.date === a.start_date && r.end === a.end_date);
      if (index < 0) d.reports.unshift(report); else d.reports[index] = report;
      d.history.push({ at: new Date().toISOString(), action: "聊天接口生成周期报告", type: a.report_type, date: a.start_date, end: a.end_date, requestId });
    });
    return { success: true, report: data.reports.find((r) => r.type === a.report_type && r.date === a.start_date && r.end === a.end_date) };
  }
  if (name === "search_study_data") {
    for (const k of ["date_from", "date_to"]) if (a[k] && !validDate(a[k])) throw new Error("日期格式必须为 YYYY-MM-DD");
    const data = await readData(userId), q = String(a.query || "").toLowerCase(), hits: any[] = [];
    const inRange = (date: string) => (!a.date_from || date >= a.date_from) && (!a.date_to || date <= a.date_to);
    const add = (type: string, id: string, date: string, subject: string, item: any) => {
      if (!inRange(date) || a.subject && subject !== a.subject && !JSON.stringify(item).includes(a.subject) || !q && !a.subject && !a.date_from && !a.date_to && !a.report_type && !a.mistake_status) return;
      if (type === "报告" && a.report_type && item.type !== a.report_type || type === "错题" && a.mistake_status && item.status !== a.mistake_status) return;
      if (q && !JSON.stringify(item).toLowerCase().includes(q)) return;
      hits.push({ type, id, date, subject: subject || "", item });
    };
    for (const x of data.tasks) add("任务", x.id, x.date, x.subject, x);
    for (const x of data.logs) add("学习记录", x.id || x.date, x.date, "", x);
    for (const x of data.mistakes) add("错题", x.id, x.date, x.subject, x);
    for (const x of data.reports) add("报告", x.id, x.date, "", x);
    for (const [key, value] of Object.entries(data.progress)) add("知识点", key, (value as any).last || "0000-01-01", key.split("|")[0], { key, ...value as object });
    hits.sort((x, y) => y.date.localeCompare(x.date));
    const limit = clampLimit(a.limit, 50, 100);
    return { count: hits.length, results: hits.slice(0, limit), truncated: hits.length > limit };
  }
  if (name === "sync_learning_day") {
    if (!validDate(a.date)) throw new Error("日期格式必须为 YYYY-MM-DD");
    const update = a.study_update || {};
    if (update.hours !== undefined && !finiteRange(update.hours, 0, 24)) throw new Error("study_update.hours 必须在 0–24 之间");
    if (update.subject_hours !== undefined) validateSubjectHours(update.subject_hours);
    if (update.items !== undefined) validateSubjectText(update.items);
    if (update.notes !== undefined && (typeof update.notes !== "string" || update.notes.length > 3000)) throw new Error("study_update.notes 格式无效");
    for (const t of a.task_updates || []) if (typeof t.task_id !== "string" || !["已完成", "部分完成", "未完成"].includes(t.status) || t.actual_minutes !== undefined && !finiteRange(t.actual_minutes, 0, 1440)) throw new Error("task_updates 字段无效");
    for (const m of a.new_mistakes || []) if (!subjects.includes(m.subject) || typeof m.topic !== "string" || !m.topic.trim() || !(m.question || m.problem_id)) throw new Error("每条批量错题必须有知识点，并提供题目文字或题号以便去重");
    for (const p of a.progress_updates || []) if (!subjects.includes(p.subject) || typeof p.topic !== "string" || !progressStates.includes(p.status) || p.status === "已掌握" && !p.note) throw new Error("progress_updates 无效；标记已掌握需有明确依据 note");
    if (update.hours === undefined && !Object.keys(update.items || {}).length && !Object.keys(update.subject_hours || {}).length && !update.notes && !(a.task_updates || []).length && !(a.new_mistakes || []).length && !(a.progress_updates || []).length) throw new Error("没有可同步的明确学习事实");
    const data = await mutateData(userId, (d) => {
      if (update.hours !== undefined || update.items || update.subject_hours || update.notes) mergeStudyLog(d, a.date, update);
      for (const t of a.task_updates || []) {
        const task = d.tasks.find((x) => x.id === t.task_id && x.date === a.date);
        if (!task) throw new Error(`未找到当天任务 ${t.task_id}`);
        task.status = t.status; if (t.actual_minutes !== undefined) task.actual = t.actual_minutes;
      }
      for (const m of a.new_mistakes || []) addMistakeToData(d, { ...m, date: a.date }, false);
      for (const p of a.progress_updates || []) {
        const key = `${p.subject}|${p.topic.trim()}`;
        d.progress[key] = { ...(d.progress[key] || {}), state: p.status, last: p.last_review || todayShanghai(), next: p.next_review || d.progress[key]?.next || "", chapter: p.chapter || d.progress[key]?.chapter || "", ...(p.score === undefined ? {} : { score: p.score }), ...(p.note === undefined ? {} : { note: p.note }) };
      }
      upsertDailyReport(d, a.date);
      d.history.push({ at: new Date().toISOString(), action: "批量同步当日学习信息", date: a.date, requestId });
    });
    return { success: true, date: a.date, log: data.logs.find((l) => l.date === a.date) || null, tasks: data.tasks.filter((t) => t.date === a.date), mistakes: data.mistakes.filter((m) => m.date === a.date), report: data.reports.find((r) => r.type === "日报" && r.date === a.date), updated_at: new Date().toISOString() };
  }
  if (name === "get_study_change_history") {
    if (a.date_from && !validDate(a.date_from) || a.date_to && !validDate(a.date_to)) throw new Error("日期格式必须为 YYYY-MM-DD");
    const data = await readData(userId), history = (data.audit || []).filter((h: any) => (!a.date_from || h.at?.slice(0, 10) >= a.date_from) && (!a.date_to || h.at?.slice(0, 10) <= a.date_to)).slice(-clampLimit(a.limit, 30, 100)).reverse();
    return { count: history.length, changes: history };
  }
  throw new Error("工具未实现");
}

function finiteRange(v: any, min: number, max: number) { return typeof v === "number" && Number.isFinite(v) && v >= min && v <= max; }
function clampLimit(value: any, fallback: number, maximum: number) { return typeof value === "number" && Number.isInteger(value) ? Math.max(1, Math.min(maximum, value)) : fallback; }
function validateSubjectHours(value: any) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("subject_hours 必须是科目到小时的对象");
  for (const [key, hours] of Object.entries(value)) if (!subjects.includes(key) || !finiteRange(hours, 0, 24)) throw new Error("subject_hours 中的科目或时长无效");
}
function validateSubjectText(value: any) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("items 必须是科目到实际内容的对象");
  for (const [key, content] of Object.entries(value)) if (!subjects.includes(key) || typeof content !== "string" || content.length > 3000) throw new Error("items 中的科目或内容无效");
}

async function readData(userId: string): Promise<StudyData> {
  const [row] = await getDb().select().from(studyStates).where(eq(studyStates.userId, userId)).limit(1);
  if (!row) return makeInitialData();
  const parsed = JSON.parse(row.payload);
  return normalizeData(parsed);
}
function normalizeData(input: any): StudyData {
  return { ...input, tasks: Array.isArray(input?.tasks) ? input.tasks : [], logs: Array.isArray(input?.logs) ? input.logs : [], mistakes: Array.isArray(input?.mistakes) ? input.mistakes : [], reports: Array.isArray(input?.reports) ? input.reports : [], progress: input?.progress && typeof input.progress === "object" ? input.progress : {}, history: Array.isArray(input?.history) ? input.history : [], chat: Array.isArray(input?.chat) ? input.chat : [] };
}
async function mutateData(userId: string, mutate: (data: StudyData) => void): Promise<StudyData> {
  const db = getDb();
  for (let attempt = 0; attempt < 6; attempt++) {
    const [row] = await db.select().from(studyStates).where(eq(studyStates.userId, userId)).limit(1);
    const previous = row ? normalizeData(JSON.parse(row.payload)) : null;
    const data = previous ? normalizeData(JSON.parse(JSON.stringify(previous))) : makeInitialData();
    mutate(data);
    const audited = withStudyAudit(previous, data, { action: data.history.at(-1)?.action || "MCP 数据更新", actor: "ChatGPT学习接口", revision: (row?.revision || 0) + 1, requestId: data.history.at(-1)?.requestId });
    const payload = JSON.stringify(audited);
    if (!row) {
      const inserted = await db.insert(studyStates).values({ userId, payload, revision: 1 }).onConflictDoNothing().returning({ revision: studyStates.revision });
      if (inserted.length) return audited;
    } else {
      const updated = await db.update(studyStates).set({ payload, revision: row.revision + 1, updatedAt: sql`CURRENT_TIMESTAMP` }).where(and(eq(studyStates.userId, userId), eq(studyStates.revision, row.revision))).returning({ revision: studyStates.revision });
      if (updated.length) return audited;
    }
  }
  throw new Error("档案正在被其他设备更新，请稍后重试；没有覆盖其他设备的数据");
}

function mergeStudyLog(data: StudyData, date: string, update: any) {
  let log = data.logs.find((x) => x.date === date);
  if (!log) { log = { id: `log-${date}`, date, hours: null, items: {}, confirmed: true, source: "ChatGPT 聊天记录" }; data.logs.push(log); }
  if (update.hours !== undefined) log.hours = update.hours;
  if (update.items) log.items = { ...(log.items || {}), ...update.items };
  if (update.subject_hours) log.subjectHours = { ...(log.subjectHours || {}), ...update.subject_hours };
  if (update.notes) log.notes = update.notes;
  log.confirmed = true; log.source = "ChatGPT 聊天记录"; log.updatedAt = new Date().toISOString();
}

function addMistakeToData(data: StudyData, a: any, repeatError: boolean) {
  const topic = a.topic.trim();
  const match = data.mistakes.find((m) => m.subject === a.subject && m.topic === topic && (a.problem_id ? m.problemId === a.problem_id : a.question && m.question === a.question && m.source === (a.source || "")));
  if (match) {
    for (const [src, dst] of [["source","source"], ["chapter","chapter"], ["question","question"], ["problem_id","problemId"], ["wrong_answer","wrong"], ["error_steps","errorSteps"], ["correct_answer","correct"], ["solution","solution"], ["cause","reason"]]) if (a[src] !== undefined) match[dst] = a[src];
    if (repeatError) { match.count = (match.count || 1) + 1; match.status = match.count >= 3 ? "高频错误" : "重点薄弱"; }
    match.date = a.date; match.last = a.date; match.next = plusDays(a.date, match.count >= 3 ? 3 : match.count >= 2 ? 2 : 1);
    return match;
  }
  const mistake = { id: crypto.randomUUID(), date: a.date, subject: a.subject, source: a.source || "", chapter: a.chapter || "", topic, question: a.question || "", problemId: a.problem_id || "", wrong: a.wrong_answer || a.error_steps || "", errorSteps: a.error_steps || "", correct: a.correct_answer || "", solution: a.solution || "", reason: a.cause || "待分析", count: 1, status: "待复测", next: plusDays(a.date, 1), last: "未复测" };
  data.mistakes.unshift(mistake);
  return mistake;
}

function upsertDailyReport(data: StudyData, date: string) {
  const tasks = data.tasks.filter((t) => t.date === date);
  const log = data.logs.find((l) => l.date === date);
  const completed = tasks.filter((t) => t.status === "已完成").map((t) => t.topic);
  const hours = log?.hours ?? (tasks.some((t) => typeof t.actual === "number") ? tasks.reduce((sum, t) => sum + (Number(t.actual) || 0), 0) / 60 : null);
  const items = log?.items || {};
  const subjectTime = subjects.map((s) => `${s}：${log?.subjectHours?.[s] != null ? `${log.subjectHours[s]}小时` : tasks.some((t) => t.subject === s && typeof t.actual === "number") ? `${tasks.filter((t) => t.subject === s).reduce((sum, t) => sum + (Number(t.actual) || 0), 0)}分钟` : "未记录"}`).join("；");
  const report = {
    id: `daily-${date}`, type: "日报", date,
    summary: `实际学习：${hours == null ? "未记录时长" : `${hours}小时`}；已记录内容 ${Object.keys(items).length} 科；明确完成任务 ${completed.length} 项`,
    content: {
      planned: tasks.map((t) => `${t.subject}：${t.topic}`), actual: items, hours,
      completion: null, subjectTime, topics: completed,
      mistakes: data.mistakes.filter((m) => m.date === date).length,
      review: data.mistakes.filter((m) => m.last === date && m.last !== "未复测").length,
      issues: tasks.filter((t) => t.status === "未完成").map((t) => t.topic),
      suggestion: "报告只汇总已确认的学习记录；未提及的任务和时长保留为未记录。",
      notes: log?.notes || "",
    }, updated: new Date().toISOString(), source: "聊天接口（根据明确记录生成）",
  };
  const index = data.reports.findIndex((r) => r.type === "日报" && r.date === date);
  if (index < 0) data.reports.unshift(report); else data.reports[index] = { ...data.reports[index], ...report };
}
