import { and, eq, sql } from "drizzle-orm";
import { getChatGPTUser } from "../../chatgpt-auth";
import { getDb } from "../../../db";
import { studyStates } from "../../../db/schema";
import { withStudyAudit } from "../../../lib/study-audit";
import { matchesStudyScope } from "../../../lib/study-account";

export const dynamic = "force-dynamic";
const MAX_BYTES = 2_000_000;

export async function GET(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "请使用你的 ChatGPT 账号登录" }, { status: 401 });
  if (!await matchesStudyScope(request, user.userId)) return Response.json({ error: "账号已变更或页面版本过旧，请刷新后继续" }, { status: 403 });
  try {
    if (new URL(request.url).searchParams.get("meta") === "1") {
      const [row] = await getDb().select({ revision: studyStates.revision, updatedAt: studyStates.updatedAt }).from(studyStates).where(eq(studyStates.userId, user.userId)).limit(1);
      return Response.json({ revision: row?.revision ?? 0, updatedAt: row?.updatedAt ?? null }, { headers: { "Cache-Control": "no-store" } });
    }
    const [row] = await getDb().select().from(studyStates).where(eq(studyStates.userId, user.userId)).limit(1);
    return Response.json(row ? { data: JSON.parse(row.payload), revision: row.revision, updatedAt: row.updatedAt } : { data: null, revision: 0 }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "云端暂时不可用，请保留本机备份后重试" }, { status: 503 });
  }
}

export async function PUT(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "请使用你的 ChatGPT 账号登录" }, { status: 401 });
  if (!await matchesStudyScope(request, user.userId)) return Response.json({ error: "账号已变更或页面版本过旧，请刷新后继续" }, { status: 403 });
  const length = Number(request.headers.get("content-length") || 0);
  if (length > MAX_BYTES) return Response.json({ error: "学习档案超过 2 MB 上限，请先导出备份" }, { status: 413 });

  let body: { data?: unknown; revision?: number };
  try {
    const raw = await request.text();
    if (new TextEncoder().encode(raw).byteLength > MAX_BYTES) return Response.json({ error: "学习档案超过 2 MB 上限" }, { status: 413 });
    body = JSON.parse(raw);
  } catch {
    return Response.json({ error: "请求数据格式无效" }, { status: 400 });
  }
  if (!body.data || typeof body.data !== "object" || !Number.isInteger(body.revision) || (body.revision ?? -1) < 0) {
    return Response.json({ error: "缺少学习数据或版本号" }, { status: 400 });
  }

  const expectedRevision = body.revision as number;
  try {
    const db = getDb();
    const initialPayload = JSON.stringify(body.data);
    if (expectedRevision === 0) {
      const inserted = await db.insert(studyStates).values({ userId: user.userId, payload: initialPayload, revision: 1 }).onConflictDoNothing().returning({ revision: studyStates.revision });
      if (inserted.length) return Response.json({ revision: 1, updatedAt: new Date().toISOString() });
    } else {
      const [previousRow] = await db.select().from(studyStates).where(eq(studyStates.userId, user.userId)).limit(1);
      if (!previousRow || previousRow.revision !== expectedRevision) {
        return Response.json({ error: "其他设备已经更新了档案；云端数据未被覆盖，请刷新后再试", revision: previousRow?.revision ?? null, updatedAt: previousRow?.updatedAt ?? null }, { status: 409 });
      }
      const previous = JSON.parse(previousRow.payload);
      const action = body.data && typeof body.data === "object" && Array.isArray((body.data as any).history) ? (body.data as any).history.at(-1)?.action : "网站数据同步";
      const payload = JSON.stringify(withStudyAudit(previous, body.data, { action: typeof action === "string" ? action : "网站数据同步", actor: "网站", revision: expectedRevision + 1 }));
      const updated = await db.update(studyStates).set({ payload, revision: expectedRevision + 1, updatedAt: sql`CURRENT_TIMESTAMP` }).where(and(eq(studyStates.userId, user.userId), eq(studyStates.revision, expectedRevision))).returning({ revision: studyStates.revision, updatedAt: studyStates.updatedAt });
      if (updated.length) return Response.json(updated[0]);
    }
    const [current] = await db.select({ revision: studyStates.revision, updatedAt: studyStates.updatedAt }).from(studyStates).where(eq(studyStates.userId, user.userId)).limit(1);
    return Response.json({ error: "其他设备已经更新了档案；云端数据未被覆盖，请刷新后再试", revision: current?.revision ?? null, updatedAt: current?.updatedAt ?? null }, { status: 409 });
  } catch {
    return Response.json({ error: "云端保存失败；本机缓存仍保留，请稍后重试" }, { status: 503 });
  }
}
