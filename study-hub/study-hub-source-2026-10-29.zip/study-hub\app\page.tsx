import { getChatGPTUser, chatGPTSignInPath } from "./chatgpt-auth";

export const dynamic = "force-dynamic";

export default async function Home() {
  const user = await getChatGPTUser();
  if (!user) return (
    <div className="welcome">
      <link rel="stylesheet" href="/welcome.css" />
      <link rel="stylesheet" href="/welcome-workspace.css" />
      <header className="welcome-nav"><a className="welcome-logo" href="/"><span>濂</span><strong>希濂 <small>STUDY HUB</small></strong></a><a className="welcome-login" href={chatGPTSignInPath('/')} target="_top">登录我的空间 <span>↗</span></a></header>
      <main className="welcome-main">
        <section className="welcome-copy"><div className="welcome-kicker"><i /> 为认真备考的每一天</div><h1>把目标放远。<br />把今天，<em>学扎实。</em></h1><p>让计划、错题和复习各归其位。<br />一个安静、清楚、属于你自己的考研学习空间。</p><a className="welcome-cta" href={chatGPTSignInPath('/')} target="_top">开始我的备考 <span>→</span></a><div className="welcome-assurance"><span>按科目组织</span><span>间隔复测</span><span>个人档案独立保存</span></div></section>
        <section className="welcome-visual" aria-label="学习空间界面示意"><div className="welcome-orbit"/><div className="welcome-window"><div className="window-top"><span>YOUR STUDY SPACE</span><i/><i/><i/></div><div className="window-greeting"><small>每一步，都在靠近。</small><h2>专注于今天的下一件事</h2><span>计划清晰一点，学习从容一点。</span></div><div className="window-subjects"><span>数学</span><span>英语二</span><span>408</span><span>政治</span></div><div className="window-task"><i/><div><strong>学完一个章节，再做完整训练</strong><small>章节学习 → 整章练习 → 统一讲解</small></div><b>↗</b></div><div className="window-task"><i/><div><strong>把讲懂，变成独立做对</strong><small>记录错因 · 到期重做 · 留下进步</small></div><b>↗</b></div><div className="window-bottom"><span>你的节奏，你来决定。</span><span>界面示意</span></div></div><div className="welcome-note"><span>✦</span><p>好的计划，不必复杂。<br /><strong>只需让下一步足够清楚。</strong></p></div></section>
      </main>
      <section className="welcome-features"><article><span>01 / PLAN</span><h2>各科清楚，不再混在一起</h2><p>数学、英语二、408、政治独立分区，把每天的安排放在该在的位置。</p></article><article><span>02 / RECALL</span><h2>让错题真正进入复习</h2><p>按章节归档，区分讲懂和独立通过，把复测接进每天的学习节奏。</p></article><article><span>03 / YOURS</span><h2>每个人，都有自己的空间</h2><p>使用自己的 ChatGPT 账号登录。计划、错题与学习记录按账号分别保存。</p></article></section>
      <footer className="welcome-footer"><span>希濂 · 学习空间</span><span>慢慢来，每一步都算数。</span></footer>
    </div>
  );
  return (
    <main style={{ position: "fixed", inset: 0, background: "#f5f6f3" }}>
      <iframe
        title="希濂 · 考研学习管理系统"
        src="/study.html"
        style={{ width: "100%", height: "100%", border: 0 }}
        referrerPolicy="same-origin"
      />
      <span style={{ position: "absolute", width: 1, height: 1, overflow: "hidden" }}>
        已登录：{user.displayName}
      </span>
    </main>
  );
}
