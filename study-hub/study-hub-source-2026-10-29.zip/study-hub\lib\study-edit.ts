// Shared, deterministic edits. Authentication and optimistic locking remain in the MCP route.
const kinds: Record<string, string> = { '任务': 'tasks', '学习记录': 'logs', '错题': 'mistakes', '报告': 'reports', '知识点': 'progress' };
const subjects = ['高数','线代','数学二','408','英语','政治','健身','复盘'];
const schema = (properties: any, required: string[]) => ({ type: 'object', properties, required, additionalProperties: false });
const str = { type: 'string', minLength: 1 };
const nullableNumber = (max: number) => ({ type: ['number','null'], minimum: 0, maximum: max });
export const editTools = [
  { name: 'delete_study_record', description: '按用户明确要求删除一条任务、学习记录、错题、报告或知识点，移入可恢复回收站。先查询取得精确 record_id（知识点使用 key），不可猜测 ID；有歧义先澄清。仅删除指定记录，不清空账号。重复删除不会重复处理。', inputSchema: schema({ record_type: { type:'string', enum:Object.keys(kinds) }, record_id:str, reason:{type:'string',maxLength:1000} }, ['record_type','record_id']), annotations: { destructiveHint:true, idempotentHint:true, openWorldHint:false } },
  { name: 'list_deleted_study_records', description: '查询当前账号可恢复的已删除信息及 deletion_id。', inputSchema: schema({record_type:{type:'string',enum:Object.keys(kinds)},limit:{type:'integer',minimum:1,maximum:100}},[]), annotations:{readOnlyHint:true,openWorldHint:false} },
  { name: 'restore_study_record', description: '按用户要求恢复回收站中的一条记录。先查询取得 deletion_id；遇到同 ID 或相同日期学习记录冲突时拒绝覆盖。', inputSchema:schema({deletion_id:str},['deletion_id']), annotations:{destructiveHint:false,idempotentHint:true,openWorldHint:false} },
  { name: 'edit_study_task', description:'精确修改已有计划任务；仅更新提供的字段。可纠正日期、科目、内容、状态及实际时长；actual_minutes=null 清空误填用时，不能把计划用时当实际用时。先读取 task_id，状态须有用户明确依据。', inputSchema:schema({task_id:str,date:{type:'string'},subject:{type:'string',enum:subjects},chapter:{type:'string'},topic:str,duration_minutes:{type:'number',minimum:0,maximum:1440},actual_minutes:nullableNumber(1440),status:{type:'string',enum:['待开始','已完成','部分完成','未完成']},priority:{type:'string',enum:['高','中','低']},time:{type:'string',description:'HH:mm，空字符串清空开始时间'}},['task_id']) },
  { name:'edit_study_log', description:'修正某天已有学习记录，保留未指定字段。items 科目值=null 删除该科学习内容；subject_hours 科目值=null 清空该科时长；hours=null 清空总时长；notes 空字符串清空备注。仅写明确事实，不推算用时。同步更新已有日报。', inputSchema:schema({date:str,hours:nullableNumber(24),items:{type:'object',properties:Object.fromEntries(subjects.map(s=>[s,{type:['string','null'],maxLength:3000}])),additionalProperties:false},subject_hours:{type:'object',properties:Object.fromEntries(subjects.map(s=>[s,nullableNumber(24)])),additionalProperties:false},notes:{type:'string',maxLength:3000}},['date']) }
];
function date(v:any) { if(typeof v!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(v)||Number.isNaN(Date.parse(v))||new Date(v).toISOString().slice(0,10)!==v) throw Error('日期必须为有效 YYYY-MM-DD'); }
function text(v:any,max=6000,nonempty=false) { if(typeof v!=='string'||v.length>max||(nonempty&&!v.trim())) throw Error('文字字段无效'); }
function num(v:any,max:number,nullable=false) {if(nullable&&v===null)return;if(typeof v!=='number'||!Number.isFinite(v)||v<0||v>max)throw Error('时长超出范围');}
function key(x:any) {return x.id||x.date;}
export function applyStudyEdit(d:any,name:string,a:any,refresh:(d:any,date:string)=>void) {
  const definition=editTools.find(t=>t.name===name);
  if(!definition) throw Error('未知编辑操作');
  if(!a||typeof a!=='object'||Array.isArray(a))throw Error('参数必须为对象');
  for(const k of Object.keys(a))if(!Object.hasOwn(definition.inputSchema.properties,k))throw Error('未知字段：'+k);
  for(const k of definition.inputSchema.required)text(a[k],500,true);
  const dates=new Set<string>();
  const track=(r:any)=>{if(r?.date)dates.add(r.date);if(r?.last&&/^\d{4}-\d{2}-\d{2}$/.test(r.last))dates.add(r.last);};
  const finish=(result:any)=>{
    for(const day of dates){if(d.reports.some((r:any)=>r.type==='日报'&&r.date===day))refresh(d,day);}
    for(const r of d.reports)if(['周报','月报'].includes(r.type)&&[...dates].some(day=>r.date<=day&&(r.end||r.date)>=day)){r.needsRegeneration=true;r.summary='【源记录已修改，请重新生成】'+r.summary.replace(/^【源记录已修改，请重新生成】/,'');}
    return {success:true,...result};
  };
  if(name==='list_deleted_study_records'){
    if(a.record_type!==undefined&&!Object.hasOwn(kinds,a.record_type))throw Error('记录类型无效');
    if(a.limit!==undefined&&(!Number.isInteger(a.limit)||a.limit<1||a.limit>100))throw Error('limit 无效');
    const rows=(d.deletedRecords||[]).filter((r:any)=>!r.restoredAt&&(!a.record_type||a.record_type===r.record_type));
    return {count:rows.length,records:rows.slice().reverse().slice(0,a.limit||30)};
  }
  if(name==='delete_study_record'){
    if(!Object.hasOwn(kinds,a.record_type))throw Error('记录类型无效');
    if(a.reason!==undefined)text(a.reason,1000);
    const collection=kinds[a.record_type];
    const row=collection==='progress'?(Object.hasOwn(d.progress,a.record_id)?d.progress[a.record_id]:undefined):d[collection].find((x:any)=>key(x)===a.record_id);
    if(row===undefined){const old=(d.deletedRecords||[]).find((r:any)=>r.record_type===a.record_type&&r.record_id===a.record_id&&!r.restoredAt);if(old)return {success:true,already_deleted:true,deletion_id:old.id};throw Error('未找到指定记录，请先查询精确 ID');}
    const entry={id:crypto.randomUUID(),record_type:a.record_type,record_id:a.record_id,record:structuredClone(row),deletedAt:new Date().toISOString(),reason:a.reason||''};
    d.deletedRecords=[...(d.deletedRecords||[]),entry];
    if(collection==='progress')delete d.progress[a.record_id];else d[collection]=d[collection].filter((x:any)=>key(x)!==a.record_id);
    if(collection!=='reports')track(row);
    return finish({deletion_id:entry.id,deleted:entry,restorable:true});
  }
  if(name==='restore_study_record'){
    const entry=(d.deletedRecords||[]).find((r:any)=>r.id===a.deletion_id);
    if(!entry)throw Error('未找到回收站记录');
    if(entry.restoredAt)return {success:true,already_restored:true,record_id:entry.record_id};
    const collection=kinds[entry.record_type], row=structuredClone(entry.record);
    const conflict=collection==='progress'?Object.hasOwn(d.progress,entry.record_id):d[collection].some((x:any)=>key(x)===entry.record_id||(collection==='logs'&&x.date===row.date)||(collection==='reports'&&x.type===row.type&&x.date===row.date&&(x.end||'')===(row.end||'')));
    if(conflict)throw Error('同一记录已存在，无法恢复覆盖；请先查看并处理冲突');
    if(collection==='progress')d.progress[entry.record_id]=row;else d[collection].push(row);
    entry.restoredAt=new Date().toISOString();if(collection!=='reports')track(row);
    return finish({record_id:entry.record_id,record:row});
  }
  if(Object.keys(a).length<2)throw Error('请提供要修改的字段');
  if(name==='edit_study_task'){
    const row=d.tasks.find((t:any)=>t.id===a.task_id);if(!row)throw Error('未找到任务');
    if(a.date!==undefined)date(a.date);
    if(a.subject!==undefined&&!subjects.includes(a.subject))throw Error('科目无效');
    if(a.status!==undefined&&!['待开始','已完成','部分完成','未完成'].includes(a.status))throw Error('状态无效');
    if(a.priority!==undefined&&!['高','中','低'].includes(a.priority))throw Error('优先级无效');
    if(a.topic!==undefined)text(a.topic,500,true);if(a.chapter!==undefined)text(a.chapter,500);
    if(a.time!==undefined&&(typeof a.time!=='string'||a.time!==''&&!/^([01]\d|2[0-3]):[0-5]\d$/.test(a.time)))throw Error('时间必须为 HH:mm 或空字符串');
    if(a.duration_minutes!==undefined)num(a.duration_minutes,1440);if(a.actual_minutes!==undefined)num(a.actual_minutes,1440,true);
    track(row);for(const k of ['date','subject','chapter','topic','status','priority','time'])if(a[k]!==undefined)row[k]=a[k];
    if(a.duration_minutes!==undefined)row.duration=a.duration_minutes;if(a.actual_minutes!==undefined)row.actual=a.actual_minutes;track(row);
    return finish({task:row});
  }
  date(a.date);const row=d.logs.find((l:any)=>l.date===a.date);if(!row)throw Error('未找到该日学习记录');
  if(a.hours!==undefined)num(a.hours,24,true);if(a.notes!==undefined)text(a.notes,3000);
  for(const k of ['items','subject_hours'])if(a[k]!==undefined){if(!a[k]||typeof a[k]!=='object'||Array.isArray(a[k]))throw Error('科目映射无效');for(const [s,v] of Object.entries(a[k])){if(!subjects.includes(s))throw Error('科目无效');if(v!==null){if(k==='items')text(v,3000);else num(v,24);}}}
  if(a.hours!==undefined)row.hours=a.hours;if(a.notes!==undefined)row.notes=a.notes;
  for(const [src,dst] of [['items','items'],['subject_hours','subjectHours']])if(a[src]){row[dst]={...row[dst]};for(const [s,v] of Object.entries(a[src])){if(v===null)delete row[dst][s];else row[dst][s]=v;}}
  row.updatedAt=new Date().toISOString();track(row);return finish({log:row});
}
