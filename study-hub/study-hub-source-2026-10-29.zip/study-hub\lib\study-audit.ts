type AuditMeta = { action: string; actor: string; revision: number; requestId?: string };

const collections: Record<string, (value: any) => string> = {
  tasks: (x) => String(x.id),
  logs: (x) => String(x.id || x.date),
  mistakes: (x) => String(x.id),
  reports: (x) => String(x.id || `${x.type}|${x.date}|${x.end || ""}`),
};
const auditedFields = ["tasks", "logs", "mistakes", "reports", "progress"];

export function withStudyAudit(previous: any, nextValue: any, meta: AuditMeta) {
  const next = normalize(nextValue);
  if (!previous || typeof previous !== "object") return next;
  const before = normalize(previous);
  const changes: any[] = [];

  for (const collection of auditedFields) {
    if (collection === "progress") {
      const keys = new Set([...Object.keys(before.progress), ...Object.keys(next.progress)]);
      for (const key of keys) {
        const oldValue = before.progress[key] ?? null;
        const newValue = next.progress[key] ?? null;
        if (stable(oldValue) !== stable(newValue)) changes.push({ collection, key, before: snapshot(oldValue), after: snapshot(newValue) });
      }
      continue;
    }
    const keyOf = collections[collection];
    const oldRecords = new Map((before[collection] || []).map((x: any) => [keyOf(x), x]));
    const newRecords = new Map((next[collection] || []).map((x: any) => [keyOf(x), x]));
    for (const key of new Set([...oldRecords.keys(), ...newRecords.keys()])) {
      const oldValue = oldRecords.get(key) ?? null;
      const newValue = newRecords.get(key) ?? null;
      if (stable(oldValue) !== stable(newValue)) changes.push({ collection, key, before: snapshot(oldValue), after: snapshot(newValue) });
    }
  }

  if (!changes.length) return next;
  const event = {
    id: crypto.randomUUID(), at: new Date().toISOString(), revision: meta.revision,
    actor: meta.actor, action: meta.action, requestId: meta.requestId || null,
    changes: changes.slice(0, 40),
    changes_truncated: changes.length > 40,
  };
  next.audit = [...(Array.isArray(next.audit) ? next.audit : []), event].slice(-300);
  return next;
}

function normalize(value: any) {
  return {
    ...value,
    tasks: Array.isArray(value?.tasks) ? value.tasks : [],
    logs: Array.isArray(value?.logs) ? value.logs : [],
    mistakes: Array.isArray(value?.mistakes) ? value.mistakes : [],
    reports: Array.isArray(value?.reports) ? value.reports : [],
    progress: value?.progress && typeof value.progress === "object" ? value.progress : {},
    audit: Array.isArray(value?.audit) ? value.audit : [],
  };
}
function stable(value: any) {
  try { return JSON.stringify(value); } catch { return "[unserializable]"; }
}
function snapshot(value: any): any {
  if (value === null) return null;
  const parsed = JSON.parse(JSON.stringify(value));
  if (typeof parsed === "string") return limitText(parsed);
  if (Array.isArray(parsed)) return parsed.slice(0, 50).map(snapshot);
  if (parsed && typeof parsed === "object") {
    return Object.fromEntries(Object.entries(parsed).slice(0, 80).map(([key, child]) => [key, snapshot(child)]));
  }
  return parsed;
}
function limitText(value: string) {
  return value.length <= 1200 ? value : { preview: value.slice(0, 1200), truncated: true };
}
