import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "希濂 · 考研学习空间",
  description: "按科目安排计划、整理错题与间隔复测。使用自己的账号，建立独立的考研学习空间。",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className="antialiased">{children}</body>
    </html>
  );
}
