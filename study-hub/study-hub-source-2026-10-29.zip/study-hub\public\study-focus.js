/* 番茄专注：计时器、专注页（计时 / 统计 / 记录）、沉浸模式、专注记录与补录。
   计算在 study-focus-model.js；这里负责界面与读写。
   专注记录单独保存在 db.focusSessions：不会把任务标成完成，也不会自动填写任务的“实际用时”。
   正在进行的计时只存在本机（按账号分开的 localStorage），刷新、切换页面和多个标签页共用同一份状态。 */
const F=StudyFocus;
const FOCUS_KEY=KEY+'-focus-timer',FOCUS_PICK_KEY=KEY+'-focus-pick',FOCUS_CLAIM_KEY=KEY+'-focus-claim';
const FOCUS_GROUPS=['数学','英语二','408','政治','其他'];
const NOTE_COMPLETION=['','按计划完成','完成了一部分','没完成'];
const RING_C=2*Math.PI*104;
let focusTimer=null,focusPick=null,focusTab='计时',focusStatsView='日',focusStatsAnchor=today,focusRecordGroup='全部',focusTaskId=null;
let focusAudio=null,focusTicker=null,focusImmersive=false,focusBaseTitle=document.title,focusRecordLimit=40;

function focusRead(key){try{return JSON.parse(localStorage.getItem(key)||'null');}catch{return null;}}
function focusWrite(key,value){try{if(value===null)localStorage.removeItem(key);else localStorage.setItem(key,JSON.stringify(value));}catch{}}
function focusReadTimer(){const t=focusRead(FOCUS_KEY);return t&&t.id&&F.PHASE_LABEL[t.phase]?t:null;}
function focusReadPick(){return {taskId:null,label:'',subject:'其他',direction:'down',...(focusRead(FOCUS_PICK_KEY)||{})};}
focusTimer=focusReadTimer();focusPick=focusReadPick();
const focusSignature=t=>t?JSON.stringify({...t,lastSeen:0}):'';
function setFocusTimer(t){const changed=focusSignature(t)!==focusSignature(focusTimer);focusTimer=t;focusWrite(FOCUS_KEY,t);if(changed)focusRefresh();else paintFocus();}
function setFocusPick(patch){focusPick={...focusPick,...patch};focusWrite(FOCUS_PICK_KEY,focusPick);}
function focusRefresh(){if(page==='专注')render();else paintFocus();if(focusImmersive)buildImmersive();}
function focusSettings(){return F.settings(db);}
function phaseMinutes(phase){const s=focusSettings();return phase==='focus'?s.focus:phase==='short'?s.short:s.long;}
function findTask(id){return id?db.tasks.find(t=>t.id===id)||null:null;}
function focusTarget(){const t=focusTimer,task=findTask(t?t.taskId:focusPick.taskId);return {task,label:task?.topic||(t?t.label:focusPick.label)||'',subject:task?.subject||(t?t.subject:focusPick.subject)||'其他'};}
function focusState(){const t=focusTimer;return !t?'idle':t.pendingGap?'gap':t.running?'running':t.startedAt?'paused':'ready';}
const fmtClock=ms=>{const s=Math.max(0,Math.round(ms/1000)),h=Math.floor(s/3600),m=Math.floor(s%3600/60),r=s%60,p=n=>String(n).padStart(2,'0');return h?`${h}:${p(m)}:${p(r)}`:`${p(m)}:${p(r)}`;};
const fmtSeconds=sec=>minutes(Math.round((Number(sec)||0)/60));
function focusRows(){return F.list(db);}
function todayFocusSeconds(){const t=focusTimer,live=t&&t.phase==='focus'&&F.day(t.startedAt??Date.now())===today&&!focusRows().some(r=>r.id===t.id)?F.elapsed(t,Date.now())/1000:0;return F.totals(F.inRange(db,today,today)).seconds+live;}

/* ---------- 提示音与通知 ---------- */
function ensureFocusAudio(){try{focusAudio??=new (window.AudioContext||window.webkitAudioContext)();if(focusAudio.state==='suspended')void focusAudio.resume();}catch{focusAudio=null;}}
function focusBeep(){try{ensureFocusAudio();const ctx=focusAudio;if(!ctx)return;[0,.32,.64].forEach(d=>{const o=ctx.createOscillator(),g=ctx.createGain(),at=ctx.currentTime+d;o.type='sine';o.frequency.value=d<.6?784:1046;g.gain.setValueAtTime(.0001,at);g.gain.exponentialRampToValueAtTime(.22,at+.02);g.gain.exponentialRampToValueAtTime(.0001,at+.26);o.connect(g).connect(ctx.destination);o.start(at);o.stop(at+.3);});}catch{}}
function focusAlert(message){const s=focusSettings();if(s.sound)focusBeep();if(s.notify&&'Notification' in window&&Notification.permission==='granted'){try{new Notification('希濂 · 专注',{body:message,tag:'xilien-focus'});}catch{}}toast(message,null,'done');}

/* ---------- 计时动作 ---------- */
function focusStart(){
  ensureFocusAudio();const now=Date.now();
  if(focusTimer?.pendingGap)return showFocusGap();
  if(!focusTimer){const {task,label,subject}=focusTarget();if(!task&&!label.trim())return openFocusPicker();
    setFocusTimer(F.start(F.create({phase:'focus',direction:focusPick.direction,minutes:phaseMinutes('focus'),taskId:task?.id||null,label:task?'':label.trim(),subject,cycle:0,now}),now));}
  else setFocusTimer(F.start(focusTimer,now));
  if(focusTimer?.taskId)rememberTask(focusTimer.taskId);
}
function focusPause(){if(focusTimer?.running)setFocusTimer(F.pause(focusTimer,Date.now()));}
// 提前结束：专注满 1 分钟才生成记录；休息直接结束，准备下一个番茄。
function focusFinish(){
  const t=focusTimer;if(!t)return;const now=Date.now();
  if(t.phase!=='focus')return setFocusTimer(nextFocus(t,now,false));
  const record=saveFocusRecord(t,now,t.direction==='up'?'完成':'提前结束');
  setFocusTimer(null);
  if(record)openFocusReview(record.id);else toast('不足 1 分钟，没有生成专注记录');
}
function focusAbandon(){showDialog(`<div class="dialoghead"><h2>放弃这一轮？</h2><button class="iconbtn" aria-label="关闭" onclick="closeModal()">${svgIcon('close')}</button></div><p>已经计的 ${fmtClock(focusTimer?F.elapsed(focusTimer,Date.now()):0)} 不会生成专注记录。想保留这段时间，请点“结束并记录”。</p><div class="dialog-actions"><button class="btn quiet danger" onclick="closeModal();setFocusTimer(null);toast('已放弃这一轮')">放弃，不记录</button><button class="btn primary" onclick="closeModal();focusFinish()">结束并记录</button><button class="btn" onclick="closeModal()">继续计时</button></div>`);}
function focusSkipBreak(){if(focusTimer&&focusTimer.phase!=='focus')setFocusTimer(nextFocus(focusTimer,Date.now(),false));}
function nextFocus(t,at,auto){const next=F.create({phase:'focus',direction:focusPick.direction,minutes:phaseMinutes('focus'),taskId:t.taskId,label:t.label,subject:t.subject,cycle:t.cycle,now:at});return auto?F.start(next,at):next;}
function focusSetDirection(direction){if(focusTimer)return;setFocusPick({direction});render();}

// 同一轮只由一个标签页收尾，记录 ID 与计时 ID 相同，重复写入会被跳过。
function claimFocus(key){if(focusRead(FOCUS_CLAIM_KEY)===key)return false;focusWrite(FOCUS_CLAIM_KEY,key);return true;}
function saveFocusRecord(t,endMs,status){
  if(F.elapsed(t,endMs)<F.MIN_RECORD_MS)return null;
  db.focusSessions??=[];const existing=db.focusSessions.find(r=>r.id===t.id);if(existing)return existing;
  const r=F.record(t,endMs,status,findTask(t.taskId));db.focusSessions.push(r);audit('专注记录',{id:r.id,seconds:r.seconds,status});void save();return r;
}
// 倒计时自然结束：记录按结束的那一刻保存，再按设置进入休息或下一个番茄。
function finishPhase(t,endMs){
  if(!claimFocus(t.id+':'+t.phase))return;
  const s=focusSettings();
  if(t.phase==='focus'){
    const record=saveFocusRecord(t,endMs,'完成'),cycle=t.cycle+1,phase=cycle%s.longEvery===0?'long':'short';
    let next=F.create({phase,minutes:phaseMinutes(phase),taskId:t.taskId,label:t.label,subject:t.subject,cycle,now:endMs});
    if(s.autoBreak)next=F.start(next,endMs);
    setFocusTimer(next);focusAlert(`第 ${cycle} 个番茄完成，${phase==='long'?'长休息':'休息'}一下`);
    if(record)openFocusReview(record.id);
  }else{setFocusTimer(nextFocus(t,endMs,s.autoFocus));focusAlert('休息结束，准备下一个番茄');}
}

/* ---------- 浏览器关闭或电脑休眠后的中断 ---------- */
function showFocusGap(){const t=focusTimer;if(!t?.pendingGap)return;const {from,to}=t.pendingGap;showDialog(`<div class="dialoghead"><div><span class="eyebrow">${F.PHASE_LABEL[t.phase]}中断</span><h2>计时停了一段时间</h2></div></div><p>从 <b>${F.clock(from)}</b> 到 <b>${F.clock(to)}</b>，页面有 ${fmtSeconds((to-from)/1000)} 没有运行，可能是关闭了浏览器或电脑休眠。</p><p class="muted">计时已经停在 ${F.clock(from)}。这段时间要算作有效${t.phase==='focus'?'专注':'休息'}吗？${t.direction==='down'?'最多算到本轮结束。':''}</p><div class="dialog-actions"><button class="btn primary" onclick="resolveFocusGap(true)">算进去</button><button class="btn" onclick="resolveFocusGap(false)">不算，从中断处暂停</button></div>`);}
function resolveFocusGap(count){
  const before=focusTimer;if(!before?.pendingGap)return closeModal();
  const t=F.resolveGap(before,count,Date.now());closeModal();
  if(t.direction==='down'&&t.accumulatedMs>=t.plannedMs){focusTimer=t;finishPhase(t,before.pendingGap.from+(before.plannedMs-before.accumulatedMs));return;}
  setFocusTimer(t);toast(count?'已计入，计时处于暂停，点“继续”接着来':'没有计入，计时处于暂停');
}

/* ---------- 心跳与刷新 ---------- */
function focusTick(){
  const t=focusTimer;
  if(t?.running){const now=Date.now(),gap=F.detectGap(t,now);
    if(gap!==t){setFocusTimer(gap);showFocusGap();return;}
    if(F.finished(t,now)){finishPhase(t,F.dueAt(t));return;}
    if(now-t.lastSeen>10000){focusTimer=F.beat(t,now);focusWrite(FOCUS_KEY,focusTimer);}}
  paintFocus();
}
function focusProgress(t,now){if(!t)return 0;const e=F.elapsed(t,now);return t.direction==='down'?Math.min(1,e/t.plannedMs):(e%3600000)/3600000;}
function focusClockText(t,now){if(!t)return fmtClock(focusPick.direction==='up'?0:phaseMinutes('focus')*60000);return fmtClock(t.direction==='down'?F.remaining(t,now):F.elapsed(t,now));}
function paintFocus(){
  const t=focusTimer,now=Date.now(),text=focusClockText(t,now),offset=RING_C*(1-focusProgress(t,now));
  document.querySelectorAll('[data-fx-clock]').forEach(el=>{if(el.textContent!==text)el.textContent=text;});
  document.querySelectorAll('[data-fx-ring]').forEach(el=>el.setAttribute('stroke-dashoffset',offset.toFixed(1)));
  const todayText=fmtSeconds(todayFocusSeconds());document.querySelectorAll('[data-fx-today]').forEach(el=>{if(el.textContent!==todayText)el.textContent=todayText;});
  const pill=document.querySelector('#focusPill'),state=focusState();
  if(pill){const show=state!=='idle'&&page!=='专注';pill.classList.toggle('hidden',!show);if(show){const label=(state==='running'?F.PHASE_LABEL[t.phase]:state==='gap'?'计时中断':state==='paused'?'已暂停':'待开始')+' '+text;if(pill.textContent!==label)pill.textContent=label;pill.classList.toggle('warn',state!=='running');}}
  const title=state==='running'?`${text} ${F.PHASE_LABEL[t.phase]} · ${focusBaseTitle}`:focusBaseTitle;if(document.title!==title)document.title=title;
}
function initFocus(){
  if(focusTicker)return;
  if(focusTimer?.running){const now=Date.now(),gap=F.detectGap(focusTimer,now);if(gap!==focusTimer){focusTimer=gap;focusWrite(FOCUS_KEY,gap);setTimeout(showFocusGap,300);}}
  if(focusTimer?.pendingGap)setTimeout(showFocusGap,300);
  focusTicker=setInterval(focusTick,500);
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')focusTick();});
  window.addEventListener('focus',focusTick);
  window.addEventListener('storage',event=>{if(event.key===FOCUS_KEY){const next=focusReadTimer(),changed=focusSignature(next)!==focusSignature(focusTimer);focusTimer=next;if(changed){if(focusTimer?.pendingGap&&!document.querySelector('#modal.open'))showFocusGap();focusRefresh();}else paintFocus();}else if(event.key===FOCUS_PICK_KEY){focusPick=focusReadPick();if(page==='专注'&&!focusTimer)render();}});
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&focusImmersive&&!document.querySelector('#modal').classList.contains('open'))closeImmersive();});
  paintFocus();
}

/* ---------- 任务关联 ---------- */
function openTaskFocus(id){
  const t=findTask(id);if(!t)return toast('这项任务已变更，请刷新计划');
  focusTaskId=id;rememberTask(id);focusTab='计时';
  if(!focusTimer)setFocusPick({taskId:id,label:''});
  else if(focusTimer.taskId!==id)toast('正在进行另一轮专注，结束后再切换到这项任务');
  setPage('专注');
}
function openFocusPicker(){
  if(focusTimer)return toast('计时进行中，结束这一轮后再换任务');
  const tasks=M.dayTasks(db,today).slice().sort(taskSort);
  showDialog(`<div class="dialoghead"><div><span class="eyebrow">专注对象</span><h2>这一轮做什么？</h2></div><button class="iconbtn" aria-label="关闭" onclick="closeModal()">${svgIcon('close')}</button></div>`+
  (tasks.length?`<div class="fx-pick-list">${tasks.map(t=>{const sum=F.forTask(db,t.id);return `<button class="fx-pick${focusPick.taskId===t.id?' selected':''}" onclick="chooseFocusTask(${identifier(t.id)})">${subjectBadge(t.subject)}<span><strong>${esc(snippet(t.topic,60))}</strong><small>${esc([t.time,t.chapter].filter(Boolean).join(' · ')||'今天')}${sum.sessions?' · 已专注 '+fmtSeconds(sum.seconds):''}</small></span>${taskStateChip(t.status)}</button>`;}).join('')}</div>`:blank('今天还没有任务','可以先写一个临时任务开始专注。'))+
  `<h3 class="fx-subtitle">临时任务</h3><p class="muted">只用于这次专注记录，不会加入学习计划。</p><div class="formgrid"><div class="field"><label for="fxLabel">要做什么</label><input id="fxLabel" value="${esc(focusPick.taskId?'':focusPick.label)}" placeholder="如：整理今天的错题"></div><div class="field"><label for="fxSubject">科目</label><select id="fxSubject">${options([...subjects.filter(s=>s!=='健身'),'其他'],focusPick.taskId?'其他':focusPick.subject)}</select></div></div><div class="dialog-actions"><button class="btn primary" onclick="chooseFocusLabel()">用临时任务</button></div>`);
}
function chooseFocusTask(id){setFocusPick({taskId:id,label:''});focusTaskId=id;closeModal();render();}
function chooseFocusLabel(){const label=val('fxLabel').trim();if(!label)return toast('写一下这次要做什么');setFocusPick({taskId:null,label,subject:val('fxSubject')});closeModal();render();}
function setTaskPomodoros(id,delta){const t=findTask(id);if(!t)return;const n=Math.min(20,Math.max(0,(Number(t.pomodoros)||0)+delta));if(n===(Number(t.pomodoros)||0))return;t.pomodoros=n;audit('预计番茄数',{id,pomodoros:n});void save();}
// 任务卡片上的专注概况：只显示真实专注记录和你填写的预计番茄数。
function focusTaskLine(t){const sum=F.forTask(db,t.id),plan=Number(t.pomodoros)||0;if(!sum.sessions&&!plan)return '';return `<span class="fx-task-line">${svgIcon('clock')}专注 ${fmtSeconds(sum.seconds)}${plan||sum.pomodoros?` · 番茄 ${sum.pomodoros}${plan?'/'+plan:''}`:''}</span>`;}
function focusTodaySeconds(){return todayFocusSeconds();}

/* ---------- 专注页 ---------- */
function focusPage(){
  const tabs=['计时','统计','记录'];
  return heading('专注','番茄专注','选一项任务开始计时。专注记录单独保存，不会自动把任务标成完成。',`<button class="btn" onclick="openManualFocus()">${svgIcon('plus')}补录专注</button><button class="btn" onclick="openImmersive()">${svgIcon('external')}全屏专注</button>`)+
  `<div class="subject-tabs fx-tabs" role="tablist" aria-label="专注页面">${tabs.map(k=>`<button role="tab" aria-selected="${focusTab===k}" class="${focusTab===k?'selected':''} tone-blue" onclick="focusTab='${k}';render()">${svgIcon(k==='计时'?'clock':k==='统计'?'report':'notebook')}${k}</button>`).join('')}</div>`+
  (focusTab==='统计'?focusStatsMarkup():focusTab==='记录'?focusRecordsMarkup():focusTimerMarkup());
}
function focusRing(size='',extra=''){const t=focusTimer,now=Date.now();return `<svg class="fx-ring${size}" viewBox="0 0 240 240" aria-hidden="true"><circle class="fx-ring-track" cx="120" cy="120" r="104"/><circle class="fx-ring-bar" cx="120" cy="120" r="104" data-fx-ring stroke-dasharray="${RING_C.toFixed(1)}" stroke-dashoffset="${(RING_C*(1-focusProgress(t,now))).toFixed(1)}" transform="rotate(-90 120 120)"/>${extra}</svg>`;}
function focusControls(){
  const t=focusTimer,state=focusState(),brk=t&&t.phase!=='focus';
  if(state==='gap')return `<button class="btn primary" onclick="showFocusGap()">处理中断</button>`;
  if(state==='idle')return `<button class="btn primary fx-main" onclick="focusStart()">${svgIcon('play')}开始专注</button>`;
  if(state==='ready')return brk?`<button class="btn primary fx-main" onclick="focusStart()">${svgIcon('play')}开始休息</button><button class="btn" onclick="focusSkipBreak()">跳过休息</button>`:`<button class="btn primary fx-main" onclick="focusStart()">${svgIcon('play')}开始下一个番茄</button><button class="btn" onclick="setFocusTimer(null)">先不开始</button>`;
  if(state==='running')return `<button class="btn fx-main" onclick="focusPause()">暂停</button><button class="btn" onclick="${brk?'focusSkipBreak()':'focusFinish()'}">${brk?'结束休息':'结束并记录'}</button>`;
  return `<button class="btn primary fx-main" onclick="focusStart()">${svgIcon('play')}继续</button><button class="btn" onclick="${brk?'focusSkipBreak()':'focusFinish()'}">${brk?'结束休息':'结束并记录'}</button>${brk?'':`<button class="btn quiet" onclick="focusAbandon()">放弃</button>`}`;
}
function focusPhaseInfo(){const t=focusTimer,s=focusSettings(),phase=t?.phase||'focus',cycle=t?.cycle||0,round=phase==='focus'?cycle+1:cycle;return {phase,tone:phase==='focus'?'blue':'mint',text:phase==='focus'?`第 ${round} 个番茄 · 每 ${s.longEvery} 个长休息一次`:`已完成 ${cycle} 个番茄`};}
function focusTimerMarkup(){
  const t=focusTimer,state=focusState(),info=focusPhaseInfo(),direction=t?t.direction:focusPick.direction;
  const sub=state==='idle'?(direction==='up'?'正计时 · 结束时记录':'倒计时 · '+phaseMinutes('focus')+' 分钟'):state==='gap'?'计时中断，等你确认':state==='running'?(direction==='up'?'正计时中':'剩余时间'):state==='paused'?'已暂停':'准备开始';
  const modes=state==='idle'?`<div class="fx-mode" role="group" aria-label="计时方式"><button class="${direction==='down'?'selected':''}" aria-pressed="${direction==='down'}" onclick="focusSetDirection('down')">倒计时</button><button class="${direction==='up'?'selected':''}" aria-pressed="${direction==='up'}" onclick="focusSetDirection('up')">正计时</button></div>`:'';
  return `<div class="fx-layout"><section class="card fx-timer fx-${info.phase}"><div class="fx-phase-row">${chip(F.PHASE_LABEL[info.phase],info.tone)}<span class="muted">${info.text}</span></div><div class="fx-dial">${focusRing()}<div class="fx-dial-text"><strong data-fx-clock>${focusClockText(t,Date.now())}</strong><small>${sub}</small></div></div><div class="fx-controls">${focusControls()}</div>${modes}</section>`+
  `<div class="fx-side">${focusTargetCard()}${focusTodayCard()}${focusSettingsCard()}</div></div>`;
}
function focusTargetCard(){
  const {task,label,subject}=focusTarget(),locked=!!focusTimer,change=locked?'':`<button class="text-button" onclick="openFocusPicker()">${task||label?'换一项':'选择任务'}${svgIcon('arrow')}</button>`;
  if(!task&&!label)return `<section class="card fx-target"><div class="section-head"><h2>专注对象</h2>${change}</div>${blank('还没选任务','从今天的计划里选一项，或写一个临时任务。',`<button class="btn primary" onclick="openFocusPicker()">选择任务</button>`)}</section>`;
  if(!task)return `<section class="card fx-target"><div class="section-head"><h2>专注对象</h2>${change}</div><div class="chip-row">${subjectChip(subject)}${chip('临时任务','yellow')}</div><p class="fx-target-text">${esc(label)}</p><p class="muted">临时任务只记在专注记录里，不进入学习计划。</p></section>`;
  const id=identifier(task.id),sum=F.forTask(db,task.id),plan=Number(task.pomodoros)||0,done=task.status==='已完成';
  return `<section class="card fx-target"><div class="section-head"><h2>专注对象</h2>${change}</div><div class="chip-row">${subjectChip(task.subject)}${taskStateChip(task.status)}${task.date!==today?`<span class="muted">${esc(task.date)}</span>`:''}</div>${task.chapter?`<p class="next-chapter">${esc(task.chapter)}</p>`:''}<p class="fx-target-text">${esc(task.topic)}</p><div class="task-times">${timeLine(task)}</div>`+
  `<div class="fx-tomato-row"><span>番茄 <b>${sum.pomodoros}</b>${plan?` / 预计 ${plan}`:''} · 已专注 <b>${fmtSeconds(sum.seconds)}</b></span><span class="fx-stepper" role="group" aria-label="预计番茄数"><button class="iconbtn" aria-label="预计番茄减一" onclick="setTaskPomodoros(${id},-1)">−</button><b>${plan}</b><button class="iconbtn" aria-label="预计番茄加一" onclick="setTaskPomodoros(${id},1)">${svgIcon('plus')}</button></span></div>`+
  (plan?`<span class="bar tone-mint" aria-hidden="true"><i style="width:${Math.min(100,sum.pomodoros/plan*100)}%"></i></span>`:'')+
  `<div class="toolbar fx-target-actions">${done?`<button class="btn small" onclick="reopenTask(${id})">${svgIcon('undo')}恢复未完成</button>`:`<button class="btn small mint" onclick="completeTask(${id})">${svgIcon('check')}确认任务完成</button>`}<button class="btn small" onclick="logTime(${id})">${svgIcon('clock')}记录实际用时</button></div><p class="muted fx-note">完成番茄不会自动完成任务；任务是否完成、实际用时多少，由你确认。</p></section>`;
}
function focusTodayCard(){
  const rows=F.inRange(db,today,today).sort((a,b)=>b.start.localeCompare(a.start)),sum=F.totals(rows);
  return `<section class="card"><div class="section-head"><h2>今天的专注</h2><button class="text-button" onclick="focusTab='统计';focusStatsView='日';focusStatsAnchor=today;render()">统计${svgIcon('arrow')}</button></div><div class="fx-today"><div><span>专注时长</span><b data-fx-today>${fmtSeconds(todayFocusSeconds())}</b></div><div><span>完成番茄</span><b>${sum.pomodoros}</b></div><div><span>专注次数</span><b>${sum.sessions}</b></div></div>${rows.length?`<div class="fx-mini-list">${rows.slice(0,4).map(focusRecordRow).join('')}</div>`:'<p class="muted">今天还没有专注记录。</p>'}</section>`;
}
function focusSettingsCard(){
  const s=focusSettings(),num=(id,label,value,max)=>`<div class="field"><label for="${id}">${label}</label><input id="${id}" type="number" inputmode="numeric" min="1" max="${max}" value="${value}"></div>`,box=(id,label,on)=>`<label class="switch"><input id="${id}" type="checkbox" ${on?'checked':''}><span>${label}</span></label>`;
  return `<details class="card fx-settings"><summary><span>${svgIcon('settings')}计时设置</span><small class="muted">专注 ${s.focus} · 短休 ${s.short} · 长休 ${s.long} 分钟</small></summary><div class="formgrid">${num('fxFocus','专注（分钟）',s.focus,240)}${num('fxShort','短休息（分钟）',s.short,240)}${num('fxLong','长休息（分钟）',s.long,240)}${num('fxEvery','几个番茄后长休息',s.longEvery,12)}</div><div class="fx-switches">${box('fxAutoBreak','专注结束后自动开始休息',s.autoBreak)}${box('fxAutoFocus','休息结束后自动开始下一个番茄',s.autoFocus)}${box('fxSound','结束时播放提示音',s.sound)}${box('fxNotify','结束时发送浏览器通知',s.notify)}</div><p class="muted fx-note">新的时长从下一轮开始生效。浏览器在后台时会放慢页面，结束提示可能晚几十秒，但记录按实际结束的时刻保存。</p><div class="dialog-actions"><button class="btn primary" onclick="saveFocusSettings()">保存设置</button></div></details>`;
}
async function saveFocusSettings(){
  const n=id=>Number(val(id)),checked=id=>!!document.querySelector('#'+id)?.checked,next={focus:n('fxFocus'),short:n('fxShort'),long:n('fxLong'),longEvery:n('fxEvery'),autoBreak:checked('fxAutoBreak'),autoFocus:checked('fxAutoFocus'),sound:checked('fxSound'),notify:checked('fxNotify')};
  for(const k of ['focus','short','long'])if(!Number.isInteger(next[k])||next[k]<1||next[k]>240)return toast('时长须为 1–240 分钟');
  if(!Number.isInteger(next.longEvery)||next.longEvery<1||next.longEvery>12)return toast('长休息间隔须为 1–12 个番茄');
  if(next.notify&&'Notification' in window&&Notification.permission!=='granted'){try{const p=await Notification.requestPermission();if(p!=='granted'){next.notify=false;toast('浏览器没有允许通知，已关闭通知选项');}}catch{next.notify=false;}}
  if(next.notify&&!('Notification' in window)){next.notify=false;toast('这个浏览器不支持通知');}
  db.settings={...db.settings,focus:next};audit('修改专注设置');void save();toast('计时设置已保存');
}

/* ---------- 专注记录 ---------- */
function focusKindChip(r){const k=F.kindOf(r);return chip(k,k==='完成'?'mint':k==='提前结束'?'yellow':k==='补录'?'neutral':'coral');}
function focusRecordRow(r){const s=Date.parse(r.start),e=Date.parse(r.end),task=findTask(r.taskId),title=task?.topic||r.topic||r.label||'未关联任务';return `<button class="record-item fx-record" onclick="openFocusReview(${identifier(r.id)})">${subjectBadge(r.subject)}<span class="record-body"><strong>${esc(snippet(title,48))}</strong><small>${F.clock(s)}–${F.clock(e)} · ${fmtSeconds(r.seconds)}${r.note?.summary||r.note?.content?' · '+esc(snippet(r.note.summary||r.note.content,30)):''}</small></span>${focusKindChip(r)}</button>`;}
function focusRecordsMarkup(){
  const rows=focusRows().filter(r=>focusRecordGroup==='全部'||M.group(r.subject)===focusRecordGroup).sort((a,b)=>b.start.localeCompare(a.start)),shown=rows.slice(0,focusRecordLimit),dates=[...new Set(shown.map(r=>r.date))];
  const tabs=`<div class="subject-tabs" role="tablist" aria-label="记录科目">${['全部',...FOCUS_GROUPS].map(g=>`<button role="tab" aria-selected="${g===focusRecordGroup}" class="${g===focusRecordGroup?'selected':''} tone-${g==='全部'?'blue':look(g).tone}" onclick="focusRecordGroup='${g}';focusRecordLimit=40;render()">${g==='全部'?`<span class="subject-badge tone-blue" aria-hidden="true">${svgIcon('grid')}</span>全部`:subjectBadge(g)+g}</button>`).join('')}</div>`;
  return tabs+`<p class="muted fx-legend">${chip('完成','mint')} 倒计时走完或正计时结束 ${chip('提前结束','yellow')} 倒计时中途结束 ${chip('异常中断','coral')} 计时期间浏览器关闭或电脑休眠 ${chip('补录','neutral')} 手动补记</p>`+
  (rows.length?dates.map(d=>{const day=shown.filter(r=>r.date===d),sum=F.totals(day);return `<section class="card fx-day-group"><div class="section-head"><h2>${d===today?'今天':esc(d.slice(5).replace('-','/'))} <span class="muted">${esc(d)}</span></h2><span class="muted">${fmtSeconds(sum.seconds)} · 番茄 ${sum.pomodoros}</span></div><div class="record-list">${day.map(focusRecordRow).join('')}</div></section>`;}).join('')+(rows.length>shown.length?`<button class="btn fx-more" onclick="focusRecordLimit+=40;render()">再显示 ${Math.min(40,rows.length-shown.length)} 条</button>`:''):blank('还没有专注记录','开始一个番茄，结束后会出现在这里；也可以补录线下的学习时间。',`<button class="btn primary" onclick="focusTab='计时';render()">${svgIcon('play')}开始专注</button><button class="btn" onclick="openManualFocus()">补录专注</button>`));
}
// 结束时的复盘与之后修改备注共用一个对话框；开始、结束和时长只读，保证计时数据准确。
function openFocusReview(id){
  const r=focusRows().find(r=>r.id===id)||db.focusSessions?.find(r=>r.id===id);if(!r)return toast('这条记录已不存在');
  const task=findTask(r.taskId),n=r.note||{},qid=identifier(r.id),s=Date.parse(r.start),e=Date.parse(r.end);
  const gap=r.interrupted?`<div><dt>中断</dt><dd>${fmtSeconds(r.gapSeconds)}${r.gapCountedSeconds?'，其中 '+fmtSeconds(r.gapCountedSeconds)+' 按你的确认计入':'，未计入'}</dd></div>`:'';
  showDialog(`<div class="dialoghead"><div><div class="chip-row">${subjectChip(r.subject)}${focusKindChip(r)}</div><h2>${esc(task?.topic||r.topic||r.label||'未关联任务')}</h2></div><button class="iconbtn" aria-label="关闭" onclick="closeModal()">${svgIcon('close')}</button></div>`+
  `<dl class="detail-meta"><div><dt>日期</dt><dd>${esc(r.date)}</dd></div><div><dt>时间</dt><dd>${F.clock(s)}–${F.clock(e)}</dd></div><div><dt>有效时长</dt><dd>${fmtSeconds(r.seconds)}</dd></div><div><dt>方式</dt><dd>${esc(r.mode)}${r.plannedMinutes?' · '+r.plannedMinutes+' 分钟':''}</dd></div>${gap}</dl>`+
  `<div class="field"><label for="fxNoteContent">本次学习内容</label><textarea id="fxNoteContent" rows="2" placeholder="如：880 第1章 基础选择(1)–(8)">${esc(n.content||'')}</textarea></div><div class="field"><label for="fxNoteCompletion">完成情况</label><select id="fxNoteCompletion">${NOTE_COMPLETION.map(v=>`<option value="${v}" ${v===(n.completion||'')?'selected':''}>${v||'未填写'}</option>`).join('')}</select></div><div class="field"><label for="fxNoteProblems">遇到的问题</label><textarea id="fxNoteProblems" rows="2" placeholder="卡在哪、哪里不确定">${esc(n.problems||'')}</textarea></div><div class="field"><label for="fxNoteSummary">一句话总结</label><textarea id="fxNoteSummary" rows="2">${esc(n.summary||'')}</textarea></div>`+
  (task&&!r.addedToActual?`<label class="switch"><input id="fxAddActual" type="checkbox"><span>把这次 ${fmtSeconds(r.seconds)} 加到任务的“实际用时”（当前 ${task.actual==null?'未记录':Number(task.actual)+' 分钟'}）</span></label>`:task&&r.addedToActual?'<p class="muted">这次时长已经加到任务的实际用时里。</p>':'')+
  `<p class="muted fx-note">这里只修改备注；开始、结束时间和有效时长保持计时时的记录。</p><div class="dialog-actions"><button class="btn primary" onclick="saveFocusNote(${qid})">保存</button><button class="btn" onclick="closeModal()">稍后再写</button></div>`);
}
function saveFocusNote(id){
  const r=db.focusSessions?.find(r=>r.id===id);if(!r)return toast('这条记录已不存在');
  r.note={content:val('fxNoteContent').trim(),completion:val('fxNoteCompletion'),problems:val('fxNoteProblems').trim(),summary:val('fxNoteSummary').trim()};r.editedAt=new Date().toISOString();
  if(document.querySelector('#fxAddActual')?.checked&&!r.addedToActual){const t=findTask(r.taskId);if(t){t.actual=(M.number(t.actual)||0)+Math.round(r.seconds/60);r.addedToActual=true;audit('专注时长计入实际用时',{id:t.id,record:r.id});}}
  audit('专注记录备注',{id});closeModal();void save();toast('已保存');
}
function openManualFocus(){
  const tasks=M.dayTasks(db,today).slice().sort(taskSort),now=F.clock(Date.now());
  showDialog(`<div class="dialoghead"><div><span class="eyebrow">补录</span><h2>补录一段专注</h2></div><button class="iconbtn" aria-label="关闭" onclick="closeModal()">${svgIcon('close')}</button></div><p class="muted">忘了开计时器时用。补录的记录会标为“补录”，不算番茄数，和计时记录分开显示。</p>`+
  `<div class="field"><label for="fxManTask">关联今天的任务</label><select id="fxManTask"><option value="">不关联（填写下面的内容）</option>${tasks.map(t=>`<option value="${esc(t.id)}">${esc(t.subject+' · '+snippet(t.topic,40))}</option>`).join('')}</select></div><div class="formgrid"><div class="field"><label for="fxManLabel">学习内容（不关联任务时必填）</label><input id="fxManLabel"></div><div class="field"><label for="fxManSubject">科目</label><select id="fxManSubject">${options([...subjects.filter(s=>s!=='健身'),'其他'],'其他')}</select></div><div class="field"><label for="fxManDate">日期</label><input id="fxManDate" type="date" value="${today}" max="${today}"></div><div class="field"><label for="fxManTime">开始时间</label><input id="fxManTime" type="time" value="${now}"></div><div class="field"><label for="fxManMinutes">时长（分钟）</label><input id="fxManMinutes" type="number" inputmode="numeric" min="1" max="600" placeholder="如 40"></div></div><div class="field"><label for="fxManNote">备注（可空）</label><textarea id="fxManNote" rows="2"></textarea></div><div class="dialog-actions"><button class="btn primary" onclick="saveManualFocus()">保存补录</button><button class="btn" onclick="closeModal()">取消</button></div>`);
}
function saveManualFocus(){
  const taskId=val('fxManTask'),task=findTask(taskId),label=val('fxManLabel').trim(),date=val('fxManDate'),time=val('fxManTime'),mins=Number(val('fxManMinutes'));
  if(!task&&!label)return toast('请选择任务，或写下学习内容');
  if(!isDate(date)||date>today)return toast('请选择今天或之前的日期');
  if(!/^\d{2}:\d{2}$/.test(time))return toast('请填写开始时间');
  if(!Number.isInteger(mins)||mins<1||mins>600)return toast('时长须为 1–600 分钟');
  const r=F.manual({id:'m-'+crypto.randomUUID(),taskId:task?.id,task,label,subject:val('fxManSubject'),date,time,minutes:mins,note:val('fxManNote').trim(),now:Date.now()});
  if(Date.parse(r.end)>Date.now()+60000)return toast('结束时间不能晚于现在');
  db.focusSessions??=[];db.focusSessions.push(r);audit('补录专注',{id:r.id,minutes:mins});closeModal();void save();toast('补录已保存');
}

/* ---------- 统计（全部来自已保存的专注记录） ---------- */
function weekStart(date){const dow=new Date(date+'T12:00:00Z').getUTCDay();return addDays(date,-((dow+6)%7));}
function monthDays(month){const [y,m]=month.split('-').map(Number);return new Date(y,m,0).getDate();}
function focusStatsMove(step){if(focusStatsView==='日')focusStatsAnchor=addDays(focusStatsAnchor,step);else if(focusStatsView==='周')focusStatsAnchor=addDays(focusStatsAnchor,step*7);else{const [y,m]=focusStatsAnchor.split('-').map(Number),d=new Date(Date.UTC(y,m-1+step,1));focusStatsAnchor=d.toISOString().slice(0,10);}if(focusStatsAnchor>today)focusStatsAnchor=today;render();}
function subjectBars(bySubject){const total=Object.values(bySubject).reduce((a,b)=>a+b,0);if(!total)return '<p class="muted">这段时间没有专注记录。</p>';const max=Math.max(...Object.values(bySubject));return `<div class="fx-subject-bars">${FOCUS_GROUPS.filter(g=>bySubject[g]).sort((a,b)=>bySubject[b]-bySubject[a]).map(g=>`<div class="fx-sbar tone-${look(g).tone}">${subjectBadge(g)}<span class="fx-sbar-name">${g}</span><span class="bar"><i style="width:${bySubject[g]/max*100}%"></i></span><span class="fx-sbar-val">${fmtSeconds(bySubject[g])}<small>${Math.round(bySubject[g]/total*100)}%</small></span></div>`).join('')}</div>`;}
function barChart(days,labelFn){const max=Math.max(1800,...days.map(d=>d.seconds));return `<div class="week-chart fx-chart" style="grid-template-columns:repeat(${days.length},minmax(0,1fr))">${days.map(d=>`<button class="week-day${d.date>today?' unrecorded':''}" onclick="focusStatsView='日';focusStatsAnchor='${d.date}';render()" aria-label="${d.date}，专注 ${fmtSeconds(d.seconds)}"><span class="week-value">${d.date>today?'':d.seconds?fmtSeconds(d.seconds):'0'}</span><span class="week-track"><i style="height:${d.seconds?Math.max(4,d.seconds/max*100):0}%"></i></span><span>${labelFn(d)}</span></button>`).join('')}</div>`;}
function focusStatsMarkup(){
  const views=['日','周','月'],a=focusStatsAnchor;let title,body;
  if(focusStatsView==='日'){
    const rows=F.inRange(db,a,a),sum=F.totals(rows),longest=rows.reduce((m,r)=>Math.max(m,Number(r.seconds)),0),line=F.timeline(db,a);
    title=a===today?'今天':fmtDate(a);
    body=`<div class="metrics">${stat('有效专注',fmtSeconds(sum.seconds),a===today?'不含进行中的这一轮':'')}${stat('完成番茄',sum.pomodoros+' 个','倒计时完整走完')}${stat('专注次数',sum.sessions+' 次','含补录')}${stat('最长一次',longest?fmtSeconds(longest):'—','')}</div>`+
    `<section class="card"><div class="section-head"><h2>专注时间轴</h2><span class="muted">6:00 – 24:00</span></div>${line.length?`<div class="fx-timeline" role="img" aria-label="当天专注时间分布">${[6,9,12,15,18,21,24].map(h=>`<span class="fx-tick" style="left:${(h-6)/18*100}%">${h}</span>`).join('')}${line.filter(x=>x.to>360).map(x=>{const from=Math.max(360,x.from);return `<i class="tone-${look(subjectGroup(x.subject)).tone}" style="left:${(from-360)/1080*100}%;width:${Math.max(.6,(x.to-from)/1080*100)}%" title="${esc(x.subject)} ${fmtSeconds(x.seconds)}"></i>`;}).join('')}</div>`:'<p class="muted">这一天没有专注记录。</p>'}</section><section class="card"><div class="section-head"><h2>各科专注</h2></div>${subjectBars(sum.bySubject)}</section>`+
    (rows.length?`<section class="card"><div class="section-head"><h2>当天记录</h2></div><div class="record-list">${rows.sort((x,y)=>x.start.localeCompare(y.start)).map(focusRecordRow).join('')}</div></section>`:'');
  }else if(focusStatsView==='周'){
    const start=weekStart(a),days=F.daily(db,start,7,addDays),sum=F.totals(F.inRange(db,start,addDays(start,6))),prev=F.totals(F.inRange(db,addDays(start,-7),addDays(start,-1))),active=days.filter(d=>d.seconds).length;
    const trend=prev.seconds?Math.round((sum.seconds-prev.seconds)/prev.seconds*100):null;
    title=`${start.slice(5).replace('-','/')} – ${addDays(start,6).slice(5).replace('-','/')}`;
    body=`<div class="metrics">${stat('本周专注',fmtSeconds(sum.seconds),active?`${active} 天有专注`:'')}${stat('完成番茄',sum.pomodoros+' 个','')}${stat('日均',active?fmtSeconds(sum.seconds/active):'—','按有专注的天数')}${stat('比上周',trend===null?'—':(trend>=0?'+':'')+trend+'%',prev.seconds?'上周 '+fmtSeconds(prev.seconds):'上周没有记录')}</div>`+
    `<section class="card"><div class="section-head"><h2>每日专注时长</h2><span class="muted">点柱子看当天</span></div>${barChart(days,d=>['一','二','三','四','五','六','日'][days.indexOf(d)])}</section><section class="card"><div class="section-head"><h2>各科时间分布</h2></div>${subjectBars(sum.bySubject)}</section>`;
  }else{
    const month=a.slice(0,7),first=month+'-01',n=monthDays(month),days=F.daily(db,first,n,addDays),sum=F.totals(F.inRange(db,first,addDays(first,n-1))),active=days.filter(d=>d.seconds),best=active.reduce((m,d)=>d.seconds>(m?.seconds||0)?d:m,null),max=Math.max(1,...days.map(d=>d.seconds)),offset=(new Date(first+'T12:00:00Z').getUTCDay()+6)%7;
    const level=s=>!s?0:s<max*.25?1:s<max*.5?2:s<max*.75?3:4;
    title=`${month.slice(0,4)} 年 ${Number(month.slice(5))} 月`;
    body=`<div class="metrics">${stat('本月专注',fmtSeconds(sum.seconds),active.length+' 天有专注')}${stat('完成番茄',sum.pomodoros+' 个','')}${stat('日均',active.length?fmtSeconds(sum.seconds/active.length):'—','按有专注的天数')}${stat('最多的一天',best?fmtSeconds(best.seconds):'—',best?best.date.slice(5).replace('-','/'):'')}</div>`+
    `<div class="home-grid"><section class="card"><div class="section-head"><h2>专注日历</h2><span class="fx-heat-legend muted">少 ${[0,1,2,3,4].map(l=>`<i class="fx-heat-${l}"></i>`).join('')} 多</span></div><div class="fx-heat">${['一','二','三','四','五','六','日'].map(d=>`<span class="weekday">${d}</span>`).join('')}${Array(offset).fill('<span></span>').join('')}${days.map((d,i)=>`<button class="fx-heat-${d.date>today?'x':level(d.seconds)}${d.date===today?' is-today':''}" onclick="focusStatsView='日';focusStatsAnchor='${d.date}';render()" aria-label="${d.date}，专注 ${fmtSeconds(d.seconds)}" title="${d.date} · ${fmtSeconds(d.seconds)}">${i+1}</button>`).join('')}</div></section><section class="card"><div class="section-head"><h2>科目占比</h2></div>${subjectBars(sum.bySubject)}</section></div>`+
    `<section class="card"><div class="section-head"><h2>每日趋势</h2></div>${barChart(days,d=>{const k=Number(d.date.slice(8));return k===1||k%5===0?String(k):'';})}</section>`;
  }
  return `<div class="fx-stats-bar"><div class="fx-mode" role="group" aria-label="统计范围">${views.map(v=>`<button class="${focusStatsView===v?'selected':''}" aria-pressed="${focusStatsView===v}" onclick="focusStatsView='${v}';render()">${v}</button>`).join('')}</div><div class="toolbar"><button class="iconbtn" aria-label="上一${focusStatsView}" onclick="focusStatsMove(-1)"><span aria-hidden="true">‹</span></button><strong class="fx-stats-title">${esc(title)}</strong><button class="iconbtn" aria-label="下一${focusStatsView}" onclick="focusStatsMove(1)" ${focusStatsView==='日'&&a>=today?'disabled':''}><span aria-hidden="true">›</span></button>${a!==today?`<button class="btn small" onclick="focusStatsAnchor=today;render()">回到今天</button>`:''}</div></div>`+body;
}

/* ---------- 沉浸模式 ---------- */
function openImmersive(){focusImmersive=true;buildImmersive();try{document.documentElement.requestFullscreen?.().catch(()=>{});}catch{}}
function closeImmersive(){focusImmersive=false;document.querySelector('#fxImmersive')?.remove();try{if(document.fullscreenElement)document.exitFullscreen?.().catch(()=>{});}catch{}if(page==='专注')render();}
function buildImmersive(){
  let el=document.querySelector('#fxImmersive');if(!el){el=document.createElement('div');el.id='fxImmersive';el.className='fx-immersive';el.setAttribute('role','dialog');el.setAttribute('aria-label','沉浸专注');document.body.append(el);}
  const {task,label,subject}=focusTarget(),info=focusPhaseInfo();
  el.className='fx-immersive fx-'+info.phase;
  el.innerHTML=`<button class="iconbtn fx-exit" aria-label="退出全屏专注" onclick="closeImmersive()">${svgIcon('close')}</button><div class="fx-im-body"><div class="chip-row">${chip(F.PHASE_LABEL[info.phase],info.tone)}${task||label?subjectChip(subject):''}</div><p class="fx-im-task">${esc(task?.topic||label||'还没选任务')}</p><div class="fx-dial fx-dial-big">${focusRing(' fx-ring-big')}<div class="fx-dial-text"><strong data-fx-clock>${focusClockText(focusTimer,Date.now())}</strong><small>${info.text}</small></div></div><div class="fx-controls">${focusControls()}</div><p class="fx-im-today">今日专注 <b data-fx-today>${fmtSeconds(todayFocusSeconds())}</b></p></div>`;
  paintFocus();
}
document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement&&focusImmersive)closeImmersive();});
window.initFocus=initFocus;
