/* 专注计时的纯计算：计时状态、断档判断、专注记录与统计。不读写页面，也不直接改动档案。
   计时一律由时间戳推算（已累计时长 + 本段开始到现在），不依赖定时器累加秒数。 */
(function (global) {
  const ZONE = 'Asia/Shanghai';
  // 页面心跳超过这个间隔没有更新，视为浏览器关闭或电脑休眠，需要用户确认这段时间算不算学习。
  const GAP_MS = 150000;
  // 不足 1 分钟的专注不生成记录，避免误触产生碎片记录。
  const MIN_RECORD_MS = 60000;
  const DEFAULTS = {focus:25, short:5, long:15, longEvery:4, autoBreak:false, autoFocus:false, sound:true, notify:false};
  const PHASE_LABEL = {focus:'专注', short:'短休息', long:'长休息'};

  const day = ms => new Date(ms).toLocaleDateString('en-CA', {timeZone:ZONE});
  const clock = ms => new Date(ms).toLocaleTimeString('zh-CN', {timeZone:ZONE, hour:'2-digit', minute:'2-digit', hour12:false});
  function minuteOfDay(ms) {
    const [h, m] = clock(ms).split(':').map(Number);
    return (h % 24) * 60 + m;
  }
  function settings(data) {
    const saved = data?.settings?.focus || {};
    const out = {...DEFAULTS};
    for (const key of ['focus','short','long','longEvery']) {
      const n = Number(saved[key]);
      if (Number.isFinite(n) && n >= 1 && n <= (key === 'longEvery' ? 12 : 240)) out[key] = Math.round(n);
    }
    for (const key of ['autoBreak','autoFocus','sound','notify']) if (typeof saved[key] === 'boolean') out[key] = saved[key];
    return out;
  }

  /* ---------- 计时状态 ---------- */
  function create({phase='focus', direction='down', minutes=25, taskId=null, label='', subject='其他', cycle=0, now}) {
    return {id:'f-'+now.toString(36)+'-'+Math.random().toString(36).slice(2,8), phase, direction:phase==='focus'?direction:'down',
      plannedMs:Math.max(1, minutes) * 60000, accumulatedMs:0, segmentStart:null, running:false, startedAt:null, lastSeen:now,
      taskId, label, subject, cycle, gapMs:0, gapCounted:0, pendingGap:null};
  }
  const elapsed = (t, now) => t.accumulatedMs + (t.running && t.segmentStart !== null ? Math.max(0, now - t.segmentStart) : 0);
  const remaining = (t, now) => t.direction === 'down' ? Math.max(0, t.plannedMs - elapsed(t, now)) : null;
  // 倒计时自然结束的精确时刻；后台标签页里定时器被浏览器放慢时，记录仍按这个时刻结束。
  const dueAt = t => t.running && t.direction === 'down' && t.segmentStart !== null ? t.segmentStart + (t.plannedMs - t.accumulatedMs) : null;
  const finished = (t, now) => t.direction === 'down' && t.running && now >= dueAt(t);
  function start(t, now) {
    if (t.running || t.pendingGap) return t;
    return {...t, running:true, segmentStart:now, startedAt:t.startedAt ?? now, lastSeen:now};
  }
  function pause(t, now) {
    if (!t.running) return t;
    return {...t, running:false, accumulatedMs:elapsed(t, now), segmentStart:null, lastSeen:now};
  }
  function beat(t, now) { return t.running ? {...t, lastSeen:now} : t; }
  // 心跳中断过久：先把计时停在最后一次心跳的时刻，等用户决定中间这段算不算。
  function detectGap(t, now) {
    if (!t.running || now - t.lastSeen <= GAP_MS) return t;
    const until = t.direction === 'down' ? Math.min(t.lastSeen, dueAt(t)) : t.lastSeen;
    return {...t, running:false, accumulatedMs:t.accumulatedMs + Math.max(0, until - t.segmentStart), segmentStart:null,
      pendingGap:{from:t.lastSeen, to:now}};
  }
  function resolveGap(t, count, now) {
    if (!t.pendingGap) return t;
    const gap = Math.max(0, t.pendingGap.to - t.pendingGap.from);
    let added = count ? gap : 0;
    if (count && t.direction === 'down') added = Math.min(added, Math.max(0, t.plannedMs - t.accumulatedMs));
    return {...t, accumulatedMs:t.accumulatedMs + added, gapMs:t.gapMs + gap, gapCounted:t.gapCounted + added, pendingGap:null, lastSeen:now};
  }

  /* ---------- 专注记录 ---------- */
  function record(t, endMs, status, task) {
    const effective = Math.round(elapsed(t, endMs) / 1000);
    const startMs = t.startedAt ?? endMs - effective * 1000;
    return {id:t.id, source:'计时', taskId:t.taskId || null, label:t.label || '', subject:task?.subject || t.subject || '其他',
      topic:task?.topic || t.label || '', date:day(startMs), start:new Date(startMs).toISOString(), end:new Date(endMs).toISOString(),
      mode:t.direction === 'down' ? '倒计时' : '正计时', plannedMinutes:t.direction === 'down' ? Math.round(t.plannedMs / 60000) : null,
      seconds:effective, status, pomodoro:t.direction === 'down' && status === '完成',
      interrupted:t.gapMs > 0, gapSeconds:Math.round(t.gapMs / 1000), gapCountedSeconds:Math.round(t.gapCounted / 1000),
      note:{content:'', completion:'', problems:'', summary:''}, createdAt:new Date(endMs).toISOString()};
  }
  function manual({id, taskId, task, label, subject, date, time, minutes, note, now}) {
    const startMs = Date.parse(date + 'T' + (time || '00:00') + ':00+08:00');
    return {id, source:'补录', taskId:taskId || null, label:label || '', subject:task?.subject || subject || '其他', topic:task?.topic || label || '',
      date, start:new Date(startMs).toISOString(), end:new Date(startMs + minutes * 60000).toISOString(), mode:'补录', plannedMinutes:null,
      seconds:Math.round(minutes * 60), status:'完成', pomodoro:false, interrupted:false, gapSeconds:0, gapCountedSeconds:0,
      note:{content:note || '', completion:'', problems:'', summary:''}, createdAt:new Date(now).toISOString()};
  }
  const kindOf = r => r.source === '补录' ? '补录' : r.interrupted ? '异常中断' : r.status;

  /* ---------- 统计（只读真实记录） ---------- */
  const group = subject => global.StudyModel ? global.StudyModel.group(subject) : subject;
  const list = data => Array.isArray(data?.focusSessions) ? data.focusSessions.filter(r => r && r.date && Number(r.seconds) > 0) : [];
  const inRange = (data, startDate, endDate) => list(data).filter(r => r.date >= startDate && r.date <= endDate);
  function totals(rows) {
    const bySubject = {};
    let seconds = 0, pomodoros = 0;
    for (const r of rows) { seconds += Number(r.seconds); if (r.pomodoro) pomodoros++; const g = group(r.subject); bySubject[g] = (bySubject[g] || 0) + Number(r.seconds); }
    return {seconds, pomodoros, sessions:rows.length, bySubject};
  }
  function daily(data, startDate, days, addDays) {
    return Array.from({length:days}, (_, i) => { const date = addDays(startDate, i); return {date, ...totals(inRange(data, date, date))}; });
  }
  function forTask(data, taskId) { return totals(list(data).filter(r => r.taskId === taskId)); }
  function timeline(data, date) {
    return inRange(data, date, date).filter(r => r.source !== '补录' || r.start).map(r => {
      const s = Date.parse(r.start), e = Date.parse(r.end);
      const from = minuteOfDay(s), length = Math.max(1, Math.round((e - s) / 60000));
      return {id:r.id, subject:r.subject, from, to:Math.min(1440, from + length), seconds:Number(r.seconds)};
    }).sort((a, b) => a.from - b.from);
  }

  global.StudyFocus = {ZONE, GAP_MS, MIN_RECORD_MS, DEFAULTS, PHASE_LABEL, day, clock, settings, create, elapsed, remaining, dueAt, finished,
    start, pause, beat, detectGap, resolveGap, record, manual, kindOf, list, inRange, totals, daily, forTask, timeline};
})(globalThis);
