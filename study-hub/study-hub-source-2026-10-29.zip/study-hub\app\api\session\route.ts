import { getChatGPTUser } from '../../chatgpt-auth';
import { studyCacheScope } from '../../../lib/study-account';
import { getDb } from '../../../db';
import { studyStates } from '../../../db/schema';

export const dynamic = 'force-dynamic';
export async function GET() {
  const user = await getChatGPTUser();
  const headers = { 'Cache-Control': 'no-store, private' };
  if (!user) return Response.json({ authenticated: false }, { status: 401, headers });
  // The original private installation had one stored account. Only that sole
  // account may bring its unscoped legacy cache forward; others start isolated.
  let legacyCacheEligible = false;
  try {
    const rows = await getDb().select({ userId: studyStates.userId }).from(studyStates).limit(2);
    legacyCacheEligible = rows.length === 1 && rows[0].userId === user.userId;
  } catch { /* Cloud data still loads through the normal sync route. */ }
  return Response.json({ authenticated: true, cacheScope: await studyCacheScope(user.userId), displayName: user.displayName, legacyCacheEligible }, { headers });
}
