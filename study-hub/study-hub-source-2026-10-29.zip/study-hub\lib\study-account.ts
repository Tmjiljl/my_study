// Cache scope binds an open client to its signed-in identity. It is not an auth token.
export async function studyCacheScope(userId: string) {
  const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('study-hub:' + userId));
  return Array.from(new Uint8Array(hash), n => n.toString(16).padStart(2, '0')).join('');
}
export async function matchesStudyScope(request: Request, userId: string) {
  return request.headers.get('X-Study-Scope') === await studyCacheScope(userId);
}
export function makeEmptyStudyData() {
  return { tasks: [], logs: [], mistakes: [], reports: [], progress: {}, history: [], chat: [] };
}
