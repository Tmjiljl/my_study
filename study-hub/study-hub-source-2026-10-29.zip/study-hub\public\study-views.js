/* 希濂 · 学习手账：视图层
   导航、各页面、对话框与操作反馈都在这里；记录规则在 study-ui.js，数据计算在 study-model.js。
   本文件统一替换 study-core.js 中早期的页面函数（renderNav、render、各页面、taskCard、reviewMistake、toast）。
   以后改界面请直接修改本文件和 study-theme.css，不再追加覆盖脚本。 */

const PRACTICE_URL='https://cxyonly.fans/math';
const SUBJECT_LIST=['数学','英语二','408','政治'];
const SUBJECT_LOOK={
  数学:{tone:'blue',icon:'math',hint:'高数与线代：学透一章，再做整章训练'},
  英语二:{tone:'yellow',icon:'words',hint:'单词、长难句、阅读与写作'},
  '408':{tone:'mint',icon:'cs',hint:'数据结构、组成原理、操作系统、计算机网络'},
  政治:{tone:'coral',icon:'politics',hint:'按章节积累，辨析易混知识点'},
  其他:{tone:'gray',icon:'other',hint:'复盘、运动与其他安排'}
};
const TASK_TONE={待开始:'neutral',部分完成:'yellow',未完成:'coral',已完成:'mint'};
const REVIEW_TONE={待独立复测:'blue',已讲懂:'yellow',独立未通过:'coral',独立通过:'mint'};
const PROGRESS_TONE={未开始:'neutral',学习中:'blue',待巩固:'yellow',需要复习:'coral',已掌握:'mint'};
const PROGRESS_STATES=['未开始','学习中','待巩固','需要复习','已掌握'];
const LAST_TASK_KEY=KEY+'-last-task';
let workspaceSubject='数学',toastTimer=null,katexLoading=null;

/* ---------- 图标与吉祥物 ---------- */
const ICON_PATHS={
  home:'M4 11.5 12 5l8 6.5V20a1 1 0 0 1-1 1h-4.5v-5.5h-5V21H5a1 1 0 0 1-1-1z',
  calendar:'M5 6h14a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1z M8 4v4 M16 4v4 M4 11h16 M8 15h3',
  notebook:'M6 4h11a2 2 0 0 1 2 2v14H8a2 2 0 0 1-2-2z M6 18a2 2 0 0 1 2-2h11 M10 9.5l1.6 1.6L15 7.6',
  progress:'M12 4 3 8.5l9 4.5 9-4.5z M3 13l9 4.5 9-4.5',
  report:'M6 3h9l4 4v14H6z M14 3v5h5 M9.5 17v-3 M12.5 17v-6 M15.5 17v-2',
  practice:'M15 4l5 5-10.5 10.5H4.5v-5z M13 6l5 5',
  settings:'M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6z M12 3v2.5 M12 18.5V21 M3 12h2.5 M18.5 12H21 M5.6 5.6l1.8 1.8 M16.6 16.6l1.8 1.8 M5.6 18.4l1.8-1.8 M16.6 7.4l1.8-1.8',
  sparkle:'M12 3.5l1.8 5.2 5.2 1.8-5.2 1.8L12 17.5l-1.8-5.2L5 10.5l5.2-1.8z M18.5 16l.7 1.8 1.8.7-1.8.7-.7 1.8-.7-1.8-1.8-.7 1.8-.7z',
  user:'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M4.5 20.5a7.5 7.5 0 0 1 15 0',
  share:'M14 4h6v6 M20 4l-9 9 M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5',
  search:'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14z M20 20l-4-4',
  moon:'M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z',
  menu:'M4 7h16 M4 12h16 M4 17h10',
  plus:'M12 5v14 M5 12h14',
  check:'M5 12.5l4.5 4.5L19 7.5',
  clock:'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z M12 7.5V12l3 2',
  play:'M8 5.5v13l10-6.5z',
  undo:'M9 14 4 9l5-5 M4 9h10a6 6 0 0 1 0 12h-3',
  external:'M14 4h6v6 M20 4l-8.5 8.5 M18 13.5V19a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5.5',
  chevron:'M6 9l6 6 6-6',
  more:'M5 11a1 1 0 1 0 0 2 1 1 0 0 0 0-2z M12 11a1 1 0 1 0 0 2 1 1 0 0 0 0-2z M19 11a1 1 0 1 0 0 2 1 1 0 0 0 0-2z',
  close:'M6 6l12 12 M18 6 6 18',
  edit:'M4 20h4L19 9l-4-4L4 16z M13.5 6.5l4 4',
  arrow:'M5 12h14 M13 6l6 6-6 6',
  trash:'M4 7h16 M9 7V4h6v3 M6 7l1 13h10l1-13',
  math:'M17 5H7l5.5 7L7 19h10',
  words:'M5 5h10a2 2 0 0 1 2 2v12H7a2 2 0 0 1-2-2z M8 14.5l2.5-6 2.5 6 M8.9 12.5h3.2 M17 8.5h1.5a.5.5 0 0 1 .5.5v10a2 2 0 0 1-2 2H9',
  cs:'M4 5h16v11H4z M2 19.5h20 M10 8.5 8 10.5l2 2 M14 8.5l2 2-2 2',
  politics:'M3 5.5h6a3 3 0 0 1 3 3V20a2.5 2.5 0 0 0-2.5-2.5H3z M21 5.5h-6a3 3 0 0 0-3 3V20a2.5 2.5 0 0 1 2.5-2.5H21z',
  other:'M6 8.5v7 M18 8.5v7 M3.5 10.5v3 M20.5 10.5v3 M6 12h12',
  grid:'M4 4h7v7H4z M13 4h7v7h-7z M4 13h7v7H4z M13 13h7v7h-7z'
};
function svgIcon(name,cls='icon'){return `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="${ICON_PATHS[name]||ICON_PATHS.sparkle}"/></svg>`;}
// 吉祥物“小濂”：一本长出新芽的笔记本。mood: calm 平静 / done 完成 / think 思考
function mascot(mood='calm',size=56){
  const mouth=mood==='done'?'M26 39.5q6 6.5 12 0':mood==='think'?'M28 41h8':'M27 40q5 4 10 0';
  const stars=mood==='done'?'<path class="mascot-star" d="M7 12l1.4 3.4 3.4 1.4-3.4 1.4L7 21.6l-1.4-3.4-3.4-1.4 3.4-1.4z"/><path class="mascot-star" d="M57 6l1 2.4 2.4 1-2.4 1-1 2.4-1-2.4-2.4-1 2.4-1z"/>':'';
  return `<svg class="mascot mascot-${mood}" width="${size}" height="${size}" viewBox="0 0 64 64" aria-hidden="true" focusable="false"><path class="mascot-leaf" d="M32 15c-.2-5.5 3-9.2 8.6-10-.3 5.6-3.5 9.2-8.6 10z"/><path class="mascot-leaf mascot-leaf-2" d="M32 15c-.1-4.4-2.7-7.2-7-7.6.2 4.3 2.7 7 7 7.6z"/><rect class="mascot-body" x="9" y="15" width="46" height="42" rx="17"/><path class="mascot-line" d="M18 23.5h28"/><circle class="mascot-eye" cx="25" cy="33" r="2.6"/><circle class="mascot-eye" cx="39" cy="33" r="2.6"/><circle class="mascot-cheek" cx="19.5" cy="39" r="3"/><circle class="mascot-cheek" cx="44.5" cy="39" r="3"/><path class="mascot-mouth" d="${mouth}"/>${stars}</svg>`;
}

/* ---------- 通用片段 ---------- */
function subjectGroup(subject){return SUBJECT_LOOK[subject]?subject:M.group(subject);}
function look(subject){return SUBJECT_LOOK[subjectGroup(subject)]||SUBJECT_LOOK.其他;}
function snippet(text,length){const value=String(text||'').replace(/\s+/g,' ').trim();return value.length>length?value.slice(0,length-1)+'…':value;}
function heading(kicker,title,description,actions=''){return `<header class="page-head"><div class="page-head-text">${kicker?`<span class="eyebrow">${kicker}</span>`:''}<h1>${title}</h1>${description?`<p class="sub">${description}</p>`:''}</div>${actions?`<div class="page-actions">${actions}</div>`:''}</header>`;}
function blank(title,body,actions='',mood='calm'){return `<div class="empty-state">${mascot(mood,48)}<div><strong>${title}</strong><p>${body}</p>${actions?`<div class="empty-actions">${actions}</div>`:''}</div></div>`;}
function stat(label,value,note){return `<div class="metric"><span>${label}</span><strong>${value}</strong>${note?`<small>${note}</small>`:''}</div>`;}
function chip(text,tone='neutral',iconName=''){return `<span class="state-chip state-${tone}">${iconName?svgIcon(iconName):''}${esc(text)}</span>`;}
function taskStateChip(status){const s=status||'待开始';return chip(s,TASK_TONE[s]||'neutral',s==='已完成'?'check':'');}
function subjectChip(subject){const l=look(subject);return `<span class="subject-chip tone-${l.tone}">${svgIcon(l.icon)}${esc(subject||'未分科')}</span>`;}
function subjectBadge(subject){const l=look(subject);return `<span class="subject-badge tone-${l.tone}" aria-hidden="true">${svgIcon(l.icon)}</span>`;}
function subjectTabs(scope,selected,all=false){const label=scope==='mistakes'?'错题科目':scope==='progress'?'进度科目':'计划科目';return `<div class="subject-tabs" role="tablist" aria-label="${label}">${(all?['全部',...subjectSpaces]:subjectSpaces).map(s=>`<button role="tab" aria-selected="${s===selected}" class="${s===selected?'selected':''} tone-${s==='全部'?'blue':look(s).tone}" onclick="selectSubject('${scope}','${s}')">${s==='全部'?`<span class="subject-badge tone-blue" aria-hidden="true">${svgIcon('grid')}</span>`:subjectBadge(s)}${s==='全部'?'全部科目':s}</button>`).join('')}</div>`;}
function practiceLink(label='打开数学题库',cls='btn primary'){return `<a class="${cls}" href="${PRACTICE_URL}" target="_blank" rel="noopener noreferrer">${svgIcon('external')}${label}<span class="sr-only">（新标签页）</span></a>`;}
function taskSort(a,b){const rank={高:0,中:1,低:2};return Number(a.status==='已完成')-Number(b.status==='已完成')||(a.time||'99:99').localeCompare(b.time||'99:99')||(rank[a.priority]??1)-(rank[b.priority]??1);}
function timeLine(t){return `<span>${svgIcon('clock')}${t.time?esc(t.time)+' 开始 · ':''}计划 ${M.number(t.duration)??0} 分钟</span><span class="${t.actual==null?'is-unknown':''}">实际 ${t.actual==null?'未记录':Number(t.actual)+' 分钟'}</span>`;}
function readLastTask(){try{return localStorage.getItem(LAST_TASK_KEY);}catch{return null;}}
function rememberTask(id){try{localStorage.setItem(LAST_TASK_KEY,id);}catch{}}
function greeting(){const hour=Number(new Date().toLocaleString('en-US',{timeZone:'Asia/Shanghai',hour:'2-digit',hourCycle:'h23'}));return hour<5?'夜深了':hour<11?'早上好':hour<13?'中午好':hour<18?'下午好':'晚上好';}

/* ---------- 反馈：轻提示与可撤销操作 ---------- */
toast=function(message,action,mood){const el=document.querySelector('#toast');if(!el)return;clearTimeout(toastTimer);el.setAttribute('role','status');el.setAttribute('aria-live','polite');el.innerHTML=(mood==='done'?mascot('done',30):'')+`<span>${esc(message)}</span>`;if(action){const button=document.createElement('button');button.type='button';button.className='toast-action';button.textContent=action.label;button.onclick=()=>{el.classList.remove('show');action.run();};el.append(button);}el.classList.add('show');toastTimer=setTimeout(()=>el.classList.remove('show'),action?6500:2800);};

/* ---------- 数学公式：题目含 $…$、\(…\)、\[…\] 时按需加载 KaTeX 排版 ---------- */
function needsMath(text){return /\$[^$]+\$|\\\(|\\\[/.test(text);}
function loadKatex(){if(window.renderMathInElement)return Promise.resolve(true);if(katexLoading)return katexLoading;const base='https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/';const script=src=>new Promise((resolve,reject)=>{const s=document.createElement('script');s.src=src;s.onload=resolve;s.onerror=reject;document.head.append(s);});katexLoading=new Promise(resolve=>{const css=document.createElement('link');css.rel='stylesheet';css.href=base+'katex.min.css';document.head.append(css);script(base+'katex.min.js').then(()=>script(base+'contrib/auto-render.min.js')).then(()=>resolve(true)).catch(()=>{katexLoading=null;resolve(false);});});return katexLoading;}
function typesetMath(root){if(!root)return;const nodes=[...root.querySelectorAll('.math-text')].filter(n=>needsMath(n.textContent));if(!nodes.length)return;loadKatex().then(ok=>{if(!ok||!window.renderMathInElement)return;nodes.forEach(n=>{if(!n.isConnected)return;try{renderMathInElement(n,{delimiters:[{left:'$$',right:'$$',display:true},{left:'\\[',right:'\\]',display:true},{left:'$',right:'$',display:false},{left:'\\(',right:'\\)',display:false}],throwOnError:false});}catch{}});});}
function richText(value,fallback='未记录'){return value&&String(value).trim()?`<div class="rich-text math-text">${esc(value)}</div>`:`<p class="muted">${fallback}</p>`;}

/* ---------- 任务卡片 ---------- */
taskCard=function(t){
  const id=identifier(t.id),done=t.status==='已完成',long=String(t.topic||'').length>80;
  const title=long?`<details class="task-text"><summary><span class="clamp">${esc(t.topic)}</span><span class="more-label"><span class="when-closed">展开全文</span><span class="when-open">收起</span></span></summary><p>${esc(t.topic)}</p></details>`:`<p class="task-title">${esc(t.topic)}</p>`;
  return `<article class="task-card${done?' is-done':''}" data-task-id="${esc(t.id)}"><div class="task-card-top">${subjectChip(t.subject)}${t.chapter?`<span class="task-chapter">${esc(t.chapter)}</span>`:''}<span class="chip-push">${t.priority==='高'&&!done?chip('高优先','coral'):''}${taskStateChip(t.status)}</span></div>${title}<div class="task-times">${timeLine(t)}${focusTaskLine(t)}</div><div class="task-actions">${done?`<button class="btn small quiet" onclick="reopenTask(${id})">${svgIcon('undo')}恢复未完成</button>`:`<button class="btn small mint" onclick="completeTask(${id})">${svgIcon('check')}完成</button><button class="btn small" onclick="openTaskFocus(${id})">${svgIcon('play')}${focusTimer?.taskId===t.id?'专注中':'开始专注'}</button>`}<button class="btn small" onclick="logTime(${id})">${svgIcon('clock')}记录用时</button><button class="btn small" onclick="editTask(${id})">${svgIcon('edit')}编辑</button>${done?'':`<button class="btn small quiet" onclick="delayTask(${id})">顺延一天</button>`}</div></article>`;
};

/* ---------- 首页：今天 ---------- */
todayPage=function(){
  const s=M.daySummary(db,today),tasks=s.tasks.slice().sort(taskSort),pending=tasks.filter(t=>t.status!=='已完成'),due=M.due(db,today);
  const lastId=readLastTask(),last=db.tasks.find(t=>t.id===lastId&&t.status!=='已完成');
  const next=last&&last.date===today?last:pending[0],allDone=tasks.length>0&&!pending.length;
  const overview=[['今日任务',tasks.length+' 项'],['已完成',s.done+' 项'],['计划',tasks.length?minutes(s.planned):'—'],['实际',minutes(s.actual),s.actual===null],['专注',minutes(Math.round(focusTodaySeconds()/60))],['待复测',due.length+' 题']];
  const title=allDone?'今天的任务都完成啦':pending.length?'先做好下一件事':'今天还没有安排';
  return `<section class="hello-card"><div class="hello-mascot">${mascot(allDone?'done':'calm',68)}</div><div class="hello-text"><span class="eyebrow">${fmtDate(today)} · ${targetLabel()}</span><h1>${greeting()}，${title}</h1><ul class="overview" aria-label="今日概况">${overview.map(([k,v,unknown])=>`<li class="${unknown?'unknown':''}"><span>${k}</span><b>${v}</b></li>`).join('')}</ul></div><div class="hello-actions"><button class="btn primary" onclick="newTask('全部')">${svgIcon('plus')}添加任务</button><button class="btn" onclick="openPlannedDay(today)">${svgIcon('calendar')}今天的计划</button></div></section>`+
  `<div class="home-grid"><div class="home-col">${nextCard(next,!!last&&next===last,allDone)}${todayListCard(tasks)}</div><div class="home-col">${carryOverCard()}${reviewCard(due)}${resumeCard(last,next)}${practiceCard()}</div></div>`+
  subjectProgressSection()+recentRecordsSection();
};
function nextCard(t,isResume,allDone){
  if(!t)return `<section class="card next-card is-empty">${allDone?blank('今天的任务都完成了','记得把实际用时记下来，再看看明天的安排。',`<button class="btn" onclick="setPage('报告')">${svgIcon('report')}学习记录</button><button class="btn" onclick="openPlannedDay(addDays(today,1))">${svgIcon('calendar')}安排明天</button>`,'done'):blank('今天还没有任务','写下今天最想完成的一件事，从一项开始就好。',`<button class="btn primary" onclick="newTask('全部')">${svgIcon('plus')}添加第一项任务</button><button class="btn" onclick="openModal('assistant')">${svgIcon('sparkle')}粘贴一份计划</button>`)}</section>`;
  const id=identifier(t.id);
  return `<section class="card next-card" aria-labelledby="nextTitle"><div class="next-top"><span class="next-label">${svgIcon(isResume?'play':'arrow')}${isResume?'继续上次的学习':'接下来先做'}</span>${subjectChip(t.subject)}<span class="chip-push">${t.priority==='高'?chip('高优先','coral'):''}${taskStateChip(t.status)}</span></div>${t.chapter?`<p class="next-chapter">${esc(t.chapter)}</p>`:''}<h2 id="nextTitle" class="next-topic">${esc(t.topic)}</h2><div class="task-times">${timeLine(t)}</div><div class="next-actions"><button class="btn primary" onclick="openTaskFocus(${id})">${svgIcon('play')}${isResume?'继续学习':'开始学习'}</button><button class="btn mint" onclick="completeTask(${id})">${svgIcon('check')}完成</button><button class="btn" onclick="logTime(${id})">${svgIcon('clock')}记录用时</button><button class="btn quiet" onclick="editTask(${id})">${svgIcon('edit')}编辑</button></div></section>`;
}
// 之前没做完的任务：只提示，由你勾选后才移到今天。
function carryOverCard(){const rows=carryOverTasks();if(!rows.length)return '';return `<section class="card carry-card"><div class="section-head"><div><h2>${svgIcon('undo')}之前没做完<span class="count-badge">${rows.length}</span></h2><p>最近 14 天里还没完成的任务</p></div></div><div class="toolbar"><button class="btn small primary" onclick="openCarryOver()">选择移到今天</button></div></section>`;}
function todayListCard(tasks){return `<section class="card"><div class="section-head"><div><h2>今日任务</h2><p>${tasks.length?`共 ${tasks.length} 项 · 按时间排序，已完成的放在后面`:'今天的计划是空的'}</p></div><button class="text-button" onclick="openPlannedDay(today)">按科目查看${svgIcon('arrow')}</button></div>${tasks.length?`<div class="task-list">${tasks.map(t=>taskCard(t)).join('')}</div>`:blank('还没有任务','可以在这里添加，也可以去“学习计划”按科目安排。',`<button class="btn" onclick="newTask('全部')">${svgIcon('plus')}添加任务</button>`)}</section>`;}
function reviewItem(m){const id=identifier(m.id),late=m.next<today;return `<div class="review-item">${subjectBadge(m.subject)}<div class="review-info"><strong>${esc(m.topic)}</strong><small>${esc([m.book||m.source,m.problemId,m.chapter].filter(Boolean).join(' · ')||'来源待补充')}</small></div><div class="review-side">${chip(late?'逾期 · '+m.next.slice(5).replace('-','/'):'今天',late?'coral':'blue')}<button class="btn small primary" onclick="reviewMistake(${id})">复测</button></div></div>`;}
function reviewCard(due){return `<section class="card note-card"><div class="section-head"><div><h2>${svgIcon('notebook')}待复测错题<span class="count-badge">${due.length}</span></h2><p>先独立作答，再展开答案核对</p></div>${due.length?`<button class="text-button" onclick="showDue()">全部${svgIcon('arrow')}</button>`:''}</div>${due.length?`<div class="review-list">${due.slice(0,5).map(reviewItem).join('')}</div>${due.length>5?`<button class="text-button more-link" onclick="showDue()">还有 ${due.length-5} 题${svgIcon('arrow')}</button>`:''}`:blank('今天没有到期的错题','新记录的错题第二天开始复测，通过后按 3 / 7 / 14 天再测。',`<button class="btn small" onclick="setPage('错题')">打开错题本</button>`)}</section>`;}
function resumeCard(last,next){
  if(last&&last!==next)return `<section class="card"><div class="section-head"><h2>${svgIcon('play')}继续上次的学习</h2></div><div class="resume-row">${subjectChip(last.subject)}<p>${esc(snippet(last.topic,70))}</p><small>${last.date===today?'今天':esc(last.date)} · ${esc(last.status||'待开始')}</small><button class="btn small" onclick="openTaskFocus(${identifier(last.id)})">继续</button></div></section>`;
  const recent=progressItems().filter(x=>x.last).sort((a,b)=>b.last.localeCompare(a.last))[0];
  if(recent)return `<section class="card"><div class="section-head"><h2>${svgIcon('progress')}上次更新的知识点</h2></div><div class="resume-row">${subjectChip(recent.subject)}<p>${esc(recent.topic)}</p><small>${esc(recent.chapter||'')} · ${esc(recent.last)}</small><span>${chip(recent.state==='未开始'?'未学':recent.state,PROGRESS_TONE[recent.state]||'neutral')}</span><button class="btn small" onclick="progressSubject=${identifier(subjectGroup(recent.subject))};setPage('学习进度')">去章节</button></div></section>`;
  return '';
}
function practiceCard(){return `<section class="card practice-mini"><div class="section-head"><h2>${svgIcon('practice')}刷题入口</h2></div><p class="muted">数学题库在新标签页打开。在那里做错的题，回来记进错题本。</p><div class="toolbar">${practiceLink()}<button class="btn" onclick="notebookSubject='数学';newMistake()">${svgIcon('plus')}记录错题</button></div></section>`;}
function subjectStats(subject){const items=progressItems().filter(x=>M.matches(x.subject,subject));return {items,total:items.length,mastered:items.filter(x=>x.state==='已掌握').length,learning:items.filter(x=>x.state==='学习中').length,review:items.filter(x=>['待巩固','需要复习'].includes(x.state)).length};}
function subjectProgressSection(){return `<section class="home-section"><div class="section-head"><div><h2>各科进度</h2><p>按你在“各科进度”里标记的知识点状态统计</p></div><button class="text-button" onclick="setPage('学习进度')">全部章节${svgIcon('arrow')}</button></div><div class="subject-progress">${SUBJECT_LIST.map(s=>{const st=subjectStats(s),pend=M.dayTasks(db,today,s).filter(t=>t.status!=='已完成').length,due=M.due(db,today,s).length;return `<button class="sp-card tone-${look(s).tone}" onclick="progressSubject='${s}';setPage('学习进度')"><span class="sp-head">${subjectBadge(s)}<strong>${s}</strong></span><span class="sp-line">${st.total?`已掌握 <b>${st.mastered}</b> / ${st.total} 个知识点`:'还没有章节记录'}</span><span class="bar" aria-hidden="true"><i style="width:${st.total?st.mastered/st.total*100:0}%"></i></span><small>${[st.learning?`学习中 ${st.learning}`:'',st.review?`待巩固 ${st.review}`:'',pend?`今日待办 ${pend}`:'',due?`待复测 ${due}`:''].filter(Boolean).join(' · ')||'今天没有待办'}</small></button>`;}).join('')}</div></section>`;}
function recordItem(l){const s=M.daySummary(db,l.date),items=Object.entries(l.items||{});return `<button class="record-item" onclick="showDayDetail(${identifier(l.date)})"><span class="record-date"><b>${esc(String(l.date).slice(5).replace('-','/'))}</b><small>${l.date===today?'今天':esc(String(l.date).slice(0,4))}</small></span><span class="record-body"><strong class="${s.actual===null?'is-unknown':''}">${s.actual===null?'用时未记录':'学习 '+minutes(s.actual)}</strong><small>${items.length?esc(snippet(items.map(([k,v])=>k+'：'+v).join('；'),90)):'没有内容记录'}</small></span>${svgIcon('arrow')}</button>`;}
function recentRecordsSection(){const logs=db.logs.filter(l=>l.confirmed!==false&&l.date).slice().sort((a,b)=>b.date.localeCompare(a.date)).slice(0,3);return `<section class="home-section"><div class="section-head"><div><h2>最近学习记录</h2><p>来自你确认过的每日记录</p></div><button class="text-button" onclick="setPage('报告')">全部记录${svgIcon('arrow')}</button></div>${logs.length?`<div class="record-list">${logs.map(recordItem).join('')}</div>`:blank('还没有学习记录','学完后在学习助手里粘贴当天总结，确认后会出现在这里。',`<button class="btn" onclick="openModal('assistant')">${svgIcon('sparkle')}补充今天的记录</button>`)}</section>`;}

/* ---------- 学习计划（日历） ---------- */
function subjectTaskPanel(subject,date){const s=M.daySummary(db,date,subject),due=M.due(db,date,subject).length,tasks=s.tasks.slice().sort(taskSort);return `<section class="card subject-panel tone-${look(subject).tone}"><div class="section-head"><div class="subject-title">${subjectBadge(subject)}<div><h2>${subject}</h2><p>${s.done}/${tasks.length} 项完成 · 实际 ${minutes(s.actual)}${due?' · '+due+' 题待复测':''}</p></div></div><button class="iconbtn" aria-label="添加${subject}任务" onclick="newTask('${subject}',${identifier(date)})">${svgIcon('plus')}</button></div>${tasks.length?`<div class="task-list">${tasks.map(t=>taskCard(t)).join('')}</div>`:blank('这一天还没有'+subject+'任务','点右上角 ＋ 添加一项清楚的小目标。')}</section>`;}
calendarPage=function(){
  const [y,m]=calendarMonth.split('-').map(Number),offset=(new Date(y,m-1,1).getDay()+6)%7,days=new Date(y,m,0).getDate(),cells=Array(offset).fill(0).concat(Array.from({length:days},(_,i)=>i+1));while(cells.length%7)cells.push(0);
  const panels=activeSubject==='全部'?SUBJECT_LIST.concat(M.dayTasks(db,selectedDate,'其他').length?['其他']:[]):[activeSubject];
  return heading('学习计划','按日期和科目安排','先选日期，再按科目安排。计划时长和实际用时分开记录。',`<input type="date" aria-label="跳到日期" value="${esc(selectedDate)}" onchange="openPlannedDay(this.value)"><button class="btn primary" onclick="newTask(activeSubject,selectedDate)">${svgIcon('plus')}添加任务</button>`)+subjectTabs('tasks',activeSubject,true)+
  `<section class="card calendar-card"><div class="section-head"><h2>${y} 年 ${m} 月</h2><div class="toolbar"><button class="iconbtn" aria-label="上一月" onclick="calendarMove(-1)"><span aria-hidden="true">‹</span></button><button class="btn small" onclick="openPlannedDay(today)">回到今天</button><button class="iconbtn" aria-label="下一月" onclick="calendarMove(1)"><span aria-hidden="true">›</span></button></div></div><div class="calendar">${['一','二','三','四','五','六','日'].map(d=>`<div class="weekday">${d}</div>`).join('')}${cells.map(n=>{if(!n)return '<div class="calendar-blank"></div>';const date=calendarMonth+'-'+String(n).padStart(2,'0'),ts=M.dayTasks(db,date,activeSubject),done=ts.filter(t=>t.status==='已完成').length,groups=[...new Set(ts.map(t=>subjectGroup(t.subject)))];return `<button class="day${selectedDate===date?' selected':''}${date===today?' is-today':''}" aria-pressed="${selectedDate===date}" aria-label="${date}${date===today?'（今天）':''}，${ts.length?ts.length+' 项任务，完成 '+done+' 项':'没有任务'}" onclick="selectedDate='${date}';render()"><span class="day-num">${n}</span>${ts.length?`<small>${ts.length} 项 · 完成 ${done}</small>`:''}<span class="calendar-dots">${groups.slice(0,4).map(g=>`<i class="tone-${look(g).tone}"></i>`).join('')}</span></button>`;}).join('')}</div></section>`+
  `<div class="section-head section-gap"><h2>${fmtDate(selectedDate)}</h2><button class="text-button" onclick="showDayDetail(${identifier(selectedDate)})">当天实际记录${svgIcon('arrow')}</button></div><div class="subject-grid">${panels.map(s=>subjectTaskPanel(s,selectedDate)).join('')}</div>`;
};

/* ---------- 错题本 ---------- */
function mistakeSource(m){return [m.book,m.source&&m.source!==m.book?m.source:'',m.problemId,m.chapter].filter(Boolean).join(' · ');}
function mistakeItem(m){const state=M.reviewState(m),id=identifier(m.id),dueNow=m.next&&m.next<=today&&m.status!=='已掌握';return `<article class="mistake-item"><div class="mistake-item-main"><div class="chip-row">${subjectChip(m.subject)}${chip(state,REVIEW_TONE[state]||'neutral')}${dueNow?chip(m.next<today?'已逾期':'今天复测','coral'):''}</div><button class="mistake-open" onclick="openMistakeDetail(${id})"><strong>${esc(m.topic)}</strong><span>${esc(mistakeSource(m)||'来源待补充')}</span></button>${m.question?`<p class="mistake-snippet math-text">${esc(snippet(m.question,110))}</p>`:''}</div><div class="mistake-item-side"><small>${m.next?'下次复测 '+esc(m.next):m.status==='已掌握'?'已长期掌握':'尚未排期'} · 错 ${Number(m.count)||1} 次</small><div class="row-actions"><button class="btn small" onclick="openMistakeDetail(${id})">查看</button><button class="btn small primary" onclick="reviewMistake(${id})">复测</button></div></div></article>`;}
function mistakeResultsMarkup(){const rows=filteredMistakes();return `<div class="section-head"><h2>${notebookSubject==='全部'?'全部科目':notebookSubject} · ${rows.length} 题</h2><span class="muted">按下次复测日期排序</span></div>${rows.length?`<div class="mistake-list">${rows.map(mistakeItem).join('')}</div>`:db.mistakes.length?blank('没有符合条件的题目','换个关键词，或清空筛选再看看。',`<button class="btn small" onclick="clearNotebookFilters()">清空筛选</button>`,'think'):blank('还没有错题','做错的题记下来：题目原文、正确答案和解析分开写，复测时会先只显示题目。',`<button class="btn small primary" onclick="newMistake()">${svgIcon('plus')}记录第一道错题</button>`)}`;}
function onNotebookSearch(input){notebookScope.query=input.value;const box=document.querySelector('#mistakeResults');if(box){box.innerHTML=mistakeResultsMarkup();typesetMath(box);}}
function setNotebookChapter(value){notebookScope.chapter=value;notebookScope.topic='';render();}
function clearNotebookFilters(){notebookScope={query:'',chapter:'',topic:'',book:'',source:'',state:'',due:false};render();}
mistakesPage=function(){
  const scoped=db.mistakes.filter(m=>M.matches(m.subject,notebookSubject)),f=notebookScope;
  const chapterList=[...new Set(scoped.map(m=>m.chapter).filter(Boolean))],topics=[...new Set(scoped.filter(m=>!f.chapter||m.chapter===f.chapter).map(m=>m.topic).filter(Boolean))];
  const filtered=f.query||f.chapter||f.topic||f.book||f.source||f.state||f.due;
  return heading('错题复测','错题本','先看题、独立作答，再展开答案。只有你确认“独立做对”才算通过。',`${['数学','全部'].includes(notebookSubject)?practiceLink('数学题库','btn'):''}<button class="btn" onclick="exportMistakes()">导出</button><button class="btn" onclick="openModal('importmistakes')">导入</button><button class="btn primary" onclick="newMistake()">${svgIcon('plus')}记录错题</button>`)+subjectTabs('mistakes',notebookSubject,true)+
  `<div class="metrics">${stat('收录',scoped.length+' 题',notebookSubject==='全部'?'全部科目':notebookSubject)}${stat('到期复测',M.due(db,today,notebookSubject).length+' 题','含逾期')}${stat('已讲懂',scoped.filter(m=>M.reviewState(m)==='已讲懂').length+' 题','看懂解析，还没独立通过')}${stat('独立通过',scoped.filter(m=>M.reviewState(m)==='独立通过').length+' 题','以你确认的复测结果为准')}</div>`+
  `<section class="card filter-card"><div class="filter-search">${svgIcon('search')}<input id="notebookQuery" type="search" aria-label="搜索错题" placeholder="搜索题干、题号、知识点、书目" value="${esc(f.query)}" oninput="onNotebookSearch(this)"></div><div class="filter-row"><label>章节<select onchange="setNotebookChapter(this.value)">${options(['',...chapterList],f.chapter)}</select></label><label>知识点<select onchange="filterNotebook('topic',this.value)">${options(['',...topics],f.topic)}</select></label><label>复测状态<select onchange="filterNotebook('state',this.value)">${options(['','待独立复测','已讲懂','独立未通过','独立通过'],f.state)}</select></label><label class="switch"><input type="checkbox" ${f.due?'checked':''} onchange="filterNotebook('due',this.checked)"><span>只看到期</span></label></div><details class="plain-details more-filters"${f.book||f.source?' open':''}><summary>更多筛选：书目、来源</summary><div class="filter-row"><label>书目<select onchange="filterNotebook('book',this.value)">${options(['',...new Set(scoped.map(m=>m.book||'未记录书目'))],f.book)}</select></label><label>来源<select onchange="filterNotebook('source',this.value)">${options(['',...new Set(scoped.map(m=>m.source).filter(Boolean))],f.source)}</select></label></div></details>${filtered?`<button class="text-button" onclick="clearNotebookFilters()">${svgIcon('close')}清空筛选</button>`:''}</section>`+
  `<div id="mistakeResults">${mistakeResultsMarkup()}</div>`;
};
function mistakeHead(m,closeLabel='关闭'){const state=M.reviewState(m);return `<div class="dialoghead"><div><div class="chip-row">${subjectChip(m.subject)}${chip(state,REVIEW_TONE[state]||'neutral')}</div><h2>${esc(m.topic)}</h2><p class="sub">${esc(mistakeSource(m)||'来源待补充')}</p></div><button class="iconbtn" aria-label="${closeLabel}" onclick="closeModal()">${svgIcon('close')}</button></div>`;}
function questionBlock(m){return `<section class="q-block" aria-label="题目"><div class="q-label">题目</div>${richText(m.question,'还没有题目原文，点“编辑题目”补充。')}</section>`;}
function reveal(title,body){return `<details class="reveal"><summary><span>${title}</span><span class="reveal-hint"><span class="when-closed">点击展开</span><span class="when-open">收起</span></span></summary><div class="reveal-body">${body}</div></details>`;}
function openMistakeDetail(id){
  const m=db.mistakes.find(m=>m.id===id);if(!m)return toast('这道题已不存在');const qid=identifier(id),history=m.reviewHistory||[];
  const mine=`<h4>我的原作答</h4>${richText(m.wrong)}<h4>错误原因</h4><p>${esc(m.reason||'未分析')}</p>${m.errorSteps?'<h4>错误步骤</h4>'+richText(m.errorSteps):''}${m.cause?'<h4>改进办法</h4>'+richText(m.cause):''}`;
  showDialog(mistakeHead(m)+questionBlock(m)+reveal('正确答案',richText(m.correct))+reveal('解析与解题过程',richText(m.solution))+reveal('我的作答与错因',mine)+
  `<dl class="detail-meta"><div><dt>复测状态</dt><dd>${esc(M.reviewState(m))}</dd></div><div><dt>错误次数</dt><dd>${Number(m.count)||1} 次</dd></div><div><dt>连续独立通过</dt><dd>${Number(m.reviewPasses)||0} 次</dd></div><div><dt>下次复测</dt><dd>${esc(m.next||(m.status==='已掌握'?'已长期掌握':'未安排'))}</dd></div></dl>`+
  `<div class="dialog-actions"><button class="btn primary" onclick="reviewMistake(${qid})">${svgIcon('play')}开始独立复测</button><button class="btn" onclick="markExplained(${qid})">看了解析，记为已讲懂</button><button class="btn" onclick="editMistake(${qid})">${svgIcon('edit')}编辑题目</button><button class="btn quiet danger" onclick="deleteMistake(${qid})">${svgIcon('trash')}移入回收站</button></div>`+
  `<details class="plain-details"><summary>复测记录（${history.length} 次）</summary>${history.length?`<ul class="history-list">${history.slice().reverse().map(r=>`<li>${esc(r.date)} · ${r.pass?'独立通过':'未通过'}</li>`).join('')}</ul>`:'<p class="muted">还没有逐次复测记录。</p>'}</details>`);
  typesetMath(document.querySelector('#dialog'));
}
reviewMistake=function(id){
  const m=db.mistakes.find(m=>m.id===id);if(!m)return toast('这道题已不存在');const qid=identifier(id);
  showDialog(mistakeHead(m,'关闭，不记录复测')+`<ol class="steps"><li>先在纸上独立作答，不看答案</li><li>做完再展开下面的答案和解析</li><li>按真实结果选一项；关闭窗口不会记录</li></ol>`+questionBlock(m)+reveal('正确答案',richText(m.correct))+reveal('解析与解题过程',richText(m.solution))+
  `<h3 class="result-title">这次的结果</h3><div class="result-choices"><button class="choice choice-pass" onclick="finishNotebookReview(${qid},true)"><strong>${svgIcon('check')}独立做对了</strong><small>没看答案，过程和结果都对</small></button><button class="choice choice-fail" onclick="finishNotebookReview(${qid},false)"><strong>没做对</strong><small>做错或做不出来，明天再练</small></button><button class="choice choice-explained" onclick="markExplained(${qid})"><strong>看了解析才会</strong><small>记为“已讲懂”，不算独立通过</small></button></div><div class="dialog-foot"><button class="text-button" onclick="closeModal()">暂不记录，关闭</button></div>`);
  typesetMath(document.querySelector('#dialog'));
};

/* ---------- 各科进度 ---------- */
function mathWorkflow(key){const state=db.chapterWorkflows?.[key]||{},stages=['章节学习','章节练习','统一订正讲解'];return `<div class="math-workflow"><p><b>章节流程</b><span>学完一章，再完成章节练习和统一订正</span></p><div class="workflow-steps">${stages.map((label,index)=>{const done=(state.completed||[]).includes(index);return `<button class="${done?'complete':''}" aria-pressed="${done}" onclick="toggleChapterStage(${identifier(key)},${index})"><span>${done?svgIcon('check'):index+1}</span>${label}${done?'<em>已完成</em>':''}</button>`;}).join('')}</div></div>`;}
function topicRow(x){const linked=db.mistakes.filter(m=>m.topic===x.topic).length,label=x.state==='未开始'?'未学':x.state;return `<div class="topic-row"><div class="topic-info"><strong>${esc(x.topic)}</strong><small>${x.last?'最近更新 '+esc(x.last):'还没有记录'}${linked?` · 关联错题 ${linked} 道`:''}</small></div>${chip(label,PROGRESS_TONE[x.state]||'neutral')}<select aria-label="修改“${esc(x.topic)}”的状态" onchange="setProgress(${identifier(x.key)},this.value)">${PROGRESS_STATES.map(s=>`<option value="${s}" ${x.state===s?'selected':''}>${s==='未开始'?'未学':s}</option>`).join('')}</select></div>`;}
function chapterCard(key,rows,index){const mastered=rows.filter(x=>x.state==='已掌握').length,learning=rows.filter(x=>x.state==='学习中').length,weak=rows.filter(x=>['待巩固','需要复习'].includes(x.state)).length;return `<details class="card chapter-card tone-${look(rows[0].subject).tone}" ${learning||weak||index===0?'open':''}><summary><span class="chapter-name"><small>${esc(rows[0].subject)}${rows[0].ref?' · '+esc(rows[0].ref):''}</small><strong>${esc(rows[0].chapter)}</strong></span><span class="chapter-meter"><span>已掌握 ${mastered}/${rows.length}${learning?` · 学习中 ${learning}`:''}${weak?` · 待巩固 ${weak}`:''}</span><span class="bar" aria-hidden="true"><i style="width:${mastered/rows.length*100}%"></i></span></span><span class="chapter-chevron">${svgIcon('chevron')}</span></summary><div class="chapter-body">${M.group(rows[0].subject)==='数学'?mathWorkflow(key):''}${rows.map(topicRow).join('')}</div></details>`;}
function expandChapters(open){document.querySelectorAll('details.chapter-card').forEach(d=>d.open=open);}
progressPage=function(){
  const items=progressItems().filter(x=>M.matches(x.subject,progressSubject)),groups=new Map();items.forEach(x=>{const key=x.subject+'|'+x.chapter;if(!groups.has(key))groups.set(key,[]);groups.get(key).push(x);});
  const count=s=>items.filter(x=>x.state===s).length;
  return heading('各科进度',`${progressSubject} · 章节与知识点`,'逐章展开查看。状态由你标记，“已掌握”需要独立测试或明确确认。',`<button class="btn primary" onclick="openModal('progress')">${svgIcon('plus')}添加或更新知识点</button>`)+subjectTabs('progress',progressSubject)+
  `<div class="metrics">${stat('知识点',items.length+' 个','本科目录')}${stat('学习中',count('学习中')+' 个','正在推进')}${stat('待巩固 / 需复习',(count('待巩固')+count('需要复习'))+' 个','需要安排练习')}${stat('已掌握',count('已掌握')+' 个','以独立测试或明确确认为准')}</div>`+
  `<div class="progress-tools"><div class="state-legend"><span>状态：</span>${PROGRESS_STATES.map(s=>chip(s==='未开始'?'未学':s,PROGRESS_TONE[s])).join('')}</div><div class="toolbar">${progressSubject==='数学'?practiceLink('数学题库','btn'):''}<button class="btn" onclick="expandChapters(true)">全部展开</button><button class="btn" onclick="expandChapters(false)">全部收起</button></div></div>`+
  (groups.size?[...groups].map(([key,rows],index)=>chapterCard(key,rows,index)).join(''):blank('这个科目还没有章节','点“添加或更新知识点”，写下正在学的知识点。'));
};

/* ---------- 科目工作台 ---------- */
function openSubjectWorkspace(subject){if(!SUBJECT_LIST.includes(subject))return;workspaceSubject=subject;setPage('科目');}
function goSubjectSection(subject,section){
  if(section==='计划'){activeSubject=subject;openPlannedDay(today);return;}
  if(section==='错题'||section==='到期'){notebookSubject=subject;notebookScope={query:'',chapter:'',topic:'',book:'',source:'',state:'',due:section==='到期'};setPage('错题');return;}
  progressSubject=subject;setPage('学习进度');
}
function subjectWorkspacePage(){
  const s=workspaceSubject,l=look(s),sum=M.daySummary(db,today,s),tasks=sum.tasks.slice().sort(taskSort),due=M.due(db,today,s),st=subjectStats(s),weak=st.items.filter(x=>['学习中','待巩固','需要复习'].includes(x.state));
  return `<section class="subject-hero tone-${l.tone}">${subjectBadge(s)}<div><span class="eyebrow">科目工作台</span><h1>${s}</h1><p class="sub">${l.hint}</p></div><button class="btn primary" onclick="newTask('${s}')">${svgIcon('plus')}添加任务</button></section>`+
  `<div class="quick-links">${s==='数学'?practiceLink('数学题库','btn'):''}<button class="btn" onclick="goSubjectSection('${s}','计划')">${svgIcon('calendar')}学习计划</button><button class="btn" onclick="goSubjectSection('${s}','错题')">${svgIcon('notebook')}错题本</button><button class="btn" onclick="goSubjectSection('${s}','进度')">${svgIcon('progress')}章节进度</button><button class="btn" onclick="goSubjectSection('${s}','到期')">待复测 ${due.length} 题</button></div>`+
  `<div class="metrics">${stat('今日任务',tasks.length+' 项','已完成 '+sum.done+' 项')}${stat('实际学习',minutes(sum.actual),'以你的记录为准')}${stat('待复测',due.length+' 题','含逾期')}${stat('已掌握',st.mastered+' / '+st.total,'知识点')}</div>`+
  `<div class="home-grid"><section class="card"><div class="section-head"><h2>今天学什么</h2></div>${tasks.length?`<div class="task-list">${tasks.map(t=>taskCard(t)).join('')}</div>`:blank('今天这一科没有任务','添加一项，或者从下面的待巩固知识点开始。',`<button class="btn" onclick="newTask('${s}')">${svgIcon('plus')}添加任务</button>`)}</section><section class="card note-card"><div class="section-head"><h2>${svgIcon('notebook')}需要再练一次<span class="count-badge">${due.length}</span></h2></div>${due.length?`<div class="review-list">${due.slice(0,6).map(reviewItem).join('')}</div>`:blank('这一科今天没有到期错题','新错题会自动排进复测。')}</section></div>`+
  `<section class="card section-gap"><div class="section-head"><h2>正在学习与待巩固</h2><button class="text-button" onclick="goSubjectSection('${s}','进度')">完整章节目录${svgIcon('arrow')}</button></div>${weak.length?`<div class="topic-chips">${weak.slice(0,12).map(x=>`<button class="topic-chip" onclick="goSubjectSection('${s}','进度')"><span>${esc(x.topic)}</span>${chip(x.state,PROGRESS_TONE[x.state])}</button>`).join('')}</div>`:blank('暂时没有待巩固记录','在“各科进度”里标记正在学的知识点。')}</section>`;
}

/* ---------- 刷题中心 ---------- */
function practicePage(){
  const due=M.due(db,today);
  return heading('刷题中心','练新题，再回来复测','外部题库负责练习；做错的题记进错题本，到期后独立复测。')+
  `<div class="practice-grid"><section class="card practice-feature tone-blue">${subjectBadge('数学')}<h2>数学在线题库</h2><p>在新标签页打开 cxyonly.fans 的数学学习区，按自己的进度选章节做题。</p>${practiceLink()}<small>这是外部网站，与本站账号不互通；在那里做的题需要回到这里记录。</small></section>`+
  `<section class="card practice-feature tone-coral">${svgIcon('notebook','icon feature-icon')}<h2>${due.length} 道错题等待复测</h2><p>先独立作答，再展开答案核对，按真实结果记录。</p><button class="btn primary" onclick="showDue()">${due.length?'开始今天的复测':'查看错题本'}</button><small>“已讲懂”和“独立通过”分开记录</small></section>`+
  `<section class="card practice-feature tone-mint">${svgIcon('progress','icon feature-icon')}<h2>找下一块薄弱点</h2><p>从“各科进度”里挑学习中、待巩固的知识点，安排下一次练习。</p><button class="btn" onclick="setPage('学习进度')">查看各科进度</button><small>数学、英语二、408、政治分科管理</small></section></div>`+
  `<section class="card practice-loop"><h2>一次练习的完整闭环</h2><ol><li><b>1</b><span><strong>选章节</strong><small>对照各科进度</small></span></li><li><b>2</b><span><strong>去练习</strong><small>在题库独立作答</small></span></li><li><b>3</b><span><strong>记错题</strong><small>题目、答案、解析分开写</small></span></li><li><b>4</b><span><strong>到期复测</strong><small>独立做对才算通过</small></span></li></ol><div class="toolbar">${practiceLink('打开数学题库','btn')}<button class="btn" onclick="notebookSubject='数学';newMistake()">${svgIcon('plus')}记录数学错题</button></div></section>`;
}

/* 专注页（番茄计时、统计、记录）在 study-focus.js。 */

/* ---------- 学习记录与报告 ---------- */
function weekCard(){const days=Array.from({length:7},(_,i)=>{const date=addDays(today,i-6);return {date,actual:M.daySummary(db,date).actual};}),max=Math.max(60,...days.map(d=>d.actual||0));return `<section class="card"><div class="section-head"><div><h2>近 7 天学习用时</h2><p>只显示已记录的实际用时；斜线表示未记录</p></div></div><div class="week-chart">${days.map(d=>`<button class="week-day${d.actual===null?' unrecorded':''}" onclick="showDayDetail(${identifier(d.date)})" aria-label="${d.date}，${d.actual===null?'用时未记录':minutes(d.actual)}"><span class="week-value">${d.actual===null?'未记录':minutes(d.actual)}</span><span class="week-track"><i style="height:${d.actual===null?0:Math.max(4,d.actual/max*100)}%"></i></span><span>${d.date===today?'今天':d.date.slice(5).replace('-','/')}</span></button>`).join('')}</div></section>`;}
reportsPage=function(){
  const reports=db.reports.slice().sort((a,b)=>(b.date||'').localeCompare(a.date||'')),logs=db.logs.filter(l=>l.confirmed!==false&&l.date).slice().sort((a,b)=>b.date.localeCompare(a.date));
  return heading('回顾','学习记录与报告','只汇总你确认过的记录；没有记录的时长显示为“未记录”。',`<input type="date" id="reportDate" aria-label="日报日期" value="${today}"><button class="btn primary" onclick="generateReport(document.querySelector('#reportDate').value)">生成日报</button><button class="btn" onclick="generatePeriod(7)">生成周报</button><button class="btn" onclick="generatePeriod(30)">生成月报</button>`)+weekCard()+
  `<div class="home-grid section-gap"><section class="card"><div class="section-head"><h2>每日记录</h2><button class="text-button" onclick="openModal('assistant')">${svgIcon('sparkle')}补充记录</button></div>${logs.length?`<div class="record-list">${logs.slice(0,12).map(recordItem).join('')}</div>`:blank('还没有每日记录','在学习助手里粘贴当天总结，确认后会出现在这里。')}</section><section class="card"><div class="section-head"><h2>报告</h2><span class="muted">${reports.length} 份</span></div>${reports.length?`<div class="report-list">${reports.map(r=>`<button class="report-item" onclick="viewReport(${identifier(r.date)},${identifier(r.type)})">${chip(r.type,r.type==='日报'?'blue':r.type==='周报'?'mint':'yellow')}<span><strong>${esc(r.date)}${r.end?' — '+esc(r.end):''}</strong><small>${esc(r.summary||'报告已生成')}</small></span>${svgIcon('arrow')}</button>`).join('')}</div>`:blank('还没有报告','日报可以基于任意日期生成，周报和月报汇总已有记录。')}</section></div>`;
};

/* ---------- 搜索 ---------- */
function searchResultsMarkup(){const q=searchQ;const sections=[['任务',db.tasks,t=>`editTask(${identifier(t.id)})`,t=>`${t.date} · ${t.subject} · ${t.topic}`],['错题',db.mistakes,m=>`openMistakeDetail(${identifier(m.id)})`,m=>`${m.subject} · ${m.topic}`],['学习记录',db.logs,l=>`showDayDetail(${identifier(l.date)})`,l=>`${l.date} · ${Object.entries(l.items||{}).map(([s,v])=>s+' '+v).join('；')}`],['报告',db.reports,r=>`viewReport(${identifier(r.date)},${identifier(r.type)})`,r=>`${r.type} · ${r.date} · ${r.summary}`]];return heading('搜索','搜索结果',`“${esc(q)}” · 点击结果直接查看或修改`)+sections.map(([label,rows,action,title])=>{const found=rows.filter(row=>JSON.stringify(row).toLowerCase().includes(q));return `<section class="card search-section"><h2>${label} <span class="count-badge">${found.length}</span></h2>${found.map(row=>`<button class="search-result" onclick="${action(row)}"><span>${esc(title(row))}</span>${svgIcon('arrow')}</button>`).join('')||'<p class="muted">没有匹配记录</p>'}</section>`;}).join('');}

/* ---------- 导航与外框 ---------- */
renderNav=function(){
  const dueCount=M.due(db,today).length,badge=dueCount?`<i class="nav-count" aria-label="${dueCount} 题待复测">${dueCount}</i>`:'';
  const main=[['今日','今天','home'],['日历','学习计划','calendar'],['专注','专注计时','clock'],['错题','错题复测','notebook'],['学习进度','各科进度','progress'],['报告','学习记录','report'],['刷题','刷题中心','practice']];
  document.querySelector('.brand').innerHTML=`<span class="brand-mark">${mascot('calm',38)}</span><div class="label"><b>希濂 · 学习手账</b><small>${targetLabel()}</small></div>`;
  document.querySelector('#nav').innerHTML=`<div class="nav-caption">每天</div>${main.map(([key,label,iconName])=>`<button class="${page===key?'active':''}" ${page===key?'aria-current="page"':''} title="${label}" onclick="setPage('${key}')">${svgIcon(iconName)}<span class="label">${label}</span>${key==='错题'?badge:''}</button>`).join('')}<div class="nav-caption">我的科目</div>${SUBJECT_LIST.map(s=>`<button class="${page==='科目'&&workspaceSubject===s?'active':''}" ${page==='科目'&&workspaceSubject===s?'aria-current="page"':''} title="${s}" onclick="openSubjectWorkspace('${s}')">${subjectBadge(s)}<span class="label">${s}</span></button>`).join('')}`;
  document.querySelector('.sidefoot').innerHTML=`<a class="side-link" href="${PRACTICE_URL}" target="_blank" rel="noopener noreferrer" title="数学题库（新标签页）">${svgIcon('external')}<span class="label">数学题库</span></a><button onclick="openModal('assistant')" title="学习助手">${svgIcon('sparkle')}<span class="label">学习助手</span></button><button onclick="openModal('settings')" title="设置与数据">${svgIcon('settings')}<span class="label">设置与数据</span></button>`;
  const mobile=[['今日','今天','home'],['日历','计划','calendar'],['专注','专注','clock'],['错题','错题','notebook'],['学习进度','科目','progress']],moreActive=['报告','刷题','科目','搜索'].includes(page);
  document.querySelector('#mobile').innerHTML=mobile.map(([key,label,iconName])=>`<button class="${page===key?'active':''}" ${page===key?'aria-current="page"':''} onclick="setPage('${key}')">${svgIcon(iconName)}<span>${label}</span>${key==='错题'?badge:''}</button>`).join('')+`<button class="${moreActive?'active':''}" aria-haspopup="dialog" onclick="openMoreSheet()">${svgIcon('more')}<span>更多</span></button>`;
};
render=function(){renderNav();const views={今日:todayPage,日历:calendarPage,错题:mistakesPage,报告:reportsPage,搜索:searchResultsMarkup,学习进度:progressPage,刷题:practicePage,科目:subjectWorkspacePage,专注:focusPage};const view=document.querySelector('#view');view.innerHTML=(views[page]||todayPage)();typesetMath(view);paintFocus();};
function openMoreSheet(){showDialog(`<div class="dialoghead"><h2>更多</h2><button class="iconbtn" aria-label="关闭" onclick="closeModal()">${svgIcon('close')}</button></div><div class="more-grid"><button onclick="closeModal();setPage('报告')">${svgIcon('report')}<span>学习记录</span></button><button onclick="closeModal();setPage('刷题')">${svgIcon('practice')}<span>刷题中心</span></button>${SUBJECT_LIST.map(s=>`<button onclick="closeModal();openSubjectWorkspace('${s}')">${subjectBadge(s)}<span>${s}</span></button>`).join('')}<button onclick="closeModal();toggleMobileSearch()">${svgIcon('search')}<span>搜索</span></button><button onclick="openModal('assistant')">${svgIcon('sparkle')}<span>学习助手</span></button><button onclick="openModal('settings')">${svgIcon('settings')}<span>设置与数据</span></button><a href="${PRACTICE_URL}" target="_blank" rel="noopener noreferrer">${svgIcon('external')}<span>数学题库</span></a></div>`);}
function toggleSidebar(){const collapsed=document.body.classList.toggle('sidebar-collapsed');try{localStorage.setItem('xilien-sidebar',collapsed?'1':'0');}catch{}document.querySelector('#sidebarToggle')?.setAttribute('aria-expanded',String(!collapsed));}
function toggleMobileSearch(){const open=document.body.classList.toggle('search-open');if(open)requestAnimationFrame(()=>document.querySelector('#search')?.focus());}
function shareStudySpace(){showDialog(`<div class="dialoghead"><div><span class="eyebrow">分享</span><h2>把这个学习空间分享给朋友</h2></div><button class="iconbtn" aria-label="关闭" onclick="closeModal()">${svgIcon('close')}</button></div><p class="muted">朋友用自己的 ChatGPT 账号登录，会得到独立的计划和错题本。分享链接不会带上你的学习档案。</p><div class="share-link"><input id="shareUrl" aria-label="网站分享链接" readonly value="${esc(location.origin)}"><button class="btn primary" onclick="copyStudyLink()">复制链接</button></div>`);}
async function copyStudyLink(){try{await navigator.clipboard.writeText(location.origin);toast('链接已复制，可以发给朋友');}catch{document.querySelector('#shareUrl').select();toast('请选择并复制上方链接');}}
function accountStudySpace(){showDialog(`<div class="dialoghead"><h2>我的学习空间</h2><button class="iconbtn" aria-label="关闭" onclick="closeModal()">${svgIcon('close')}</button></div><div class="account-panel"><span class="account-avatar">${mascot('calm',44)}</span><div><strong>${esc(window.StudySession?.displayName||'已登录账号')}</strong><p class="muted">计划、错题、记录与备份按账号分别保存。</p></div></div><div class="dialog-actions"><button class="btn" onclick="openModal('settings')">${svgIcon('settings')}设置与数据</button><button class="btn" onclick="shareStudySpace()">${svgIcon('share')}分享空间</button><a class="btn quiet" href="/signout-with-chatgpt?return_to=%2F" target="_top">退出当前账号</a></div>`);}
function renderShell(){
  document.querySelector('.top').innerHTML=`<button id="sidebarToggle" class="iconbtn only-desktop" aria-label="展开或收起侧栏" aria-expanded="${!document.body.classList.contains('sidebar-collapsed')}" onclick="toggleSidebar()">${svgIcon('menu')}</button><span class="top-brand only-mobile">${mascot('calm',30)}<b>希濂</b></span><div class="search" role="search">${svgIcon('search','icon search-icon')}<input id="search" type="search" aria-label="全站搜索" placeholder="搜索任务、知识点、错题（按 / 聚焦）" oninput="doSearch(this.value)"></div><div class="topright"><button id="focusPill" class="pill fx-pill hidden" title="回到专注计时" onclick="setPage('专注')"></button><button id="cloudStatus" class="pill" title="点击立即同步" onclick="retryCloudSync()">正在连接档案</button><button class="iconbtn only-mobile" aria-label="搜索" onclick="toggleMobileSearch()">${svgIcon('search')}</button><button class="iconbtn" aria-label="切换深色或浅色" onclick="toggleTheme()">${svgIcon('moon')}</button><button class="iconbtn only-desktop" aria-label="分享学习空间" onclick="shareStudySpace()">${svgIcon('share')}</button><button class="iconbtn" aria-label="我的账号" onclick="accountStudySpace()">${svgIcon('user')}</button></div>`;
}
try{if(localStorage.getItem('xilien-sidebar')==='1')document.body.classList.add('sidebar-collapsed');}catch{}
renderShell();
document.addEventListener('keydown',event=>{if(event.key==='/'&&!event.ctrlKey&&!event.metaKey&&!event.altKey&&!/^(INPUT|TEXTAREA|SELECT)$/.test(event.target.tagName)&&!event.target.isContentEditable&&!document.querySelector('#modal').classList.contains('open')){event.preventDefault();if(window.matchMedia('(max-width: 900px)').matches)document.body.classList.add('search-open');document.querySelector('#search').focus();}});
render();
