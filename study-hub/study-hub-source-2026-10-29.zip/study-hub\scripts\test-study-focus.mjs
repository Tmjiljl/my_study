import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';
const root = new URL('../',import.meta.url);
const read = file => fs.readFileSync(new URL(file,root),'utf8');
const context = vm.createContext({crypto:webcrypto,Date,Math,JSON});
vm.runInContext(read('public/study-model.js'),context);
vm.runInContext(read('public/study-focus-model.js'),context);
const F=context.StudyFocus;
const addDays=(date,n)=>new Date(Date.parse(date+'T12:00:00Z')+n*86400000).toISOString().slice(0,10);
const T0=Date.parse('2026-10-24T09:00:00+08:00'),MIN=60000;

// Countdown is derived from timestamps: pausing and resuming never double counts.
let t=F.create({minutes:25,taskId:'a',subject:'408',now:T0});
assert.equal(F.elapsed(t,T0+5*MIN),0,'a timer that has not started has no elapsed time');
t=F.start(t,T0);
assert.equal(F.remaining(t,T0+10*MIN),15*MIN);
t=F.pause(t,T0+10*MIN);
assert.equal(F.elapsed(t,T0+50*MIN),10*MIN,'paused time is not counted');
t=F.start(t,T0+50*MIN);
assert.equal(F.start(t,T0+51*MIN),t,'starting a running timer again changes nothing');
assert.equal(F.dueAt(t),T0+65*MIN);
assert.equal(F.finished(t,T0+64*MIN),false);
assert.equal(F.finished(t,T0+65*MIN),true);
const done=F.record(t,F.dueAt(t),'完成',{subject:'408',topic:'单链表'});
assert.equal(done.seconds,25*60,'a finished countdown records exactly the planned time even if noticed late');
assert.equal(done.pomodoro,true);assert.equal(done.date,'2026-10-24');assert.equal(done.taskId,'a');assert.equal(done.interrupted,false);
assert.equal(done.start,new Date(T0).toISOString(),'start is the first start, not the last resume');

// Heartbeats keep a background tab running; a long silence freezes the timer at the last heartbeat.
let r=F.start(F.create({minutes:25,subject:'408',now:T0}),T0);
r=F.beat(r,T0+2*MIN);
assert.equal(F.detectGap(r,T0+3*MIN),r,'short silences (throttled tabs) are not gaps');
const gap=F.detectGap(r,T0+42*MIN);
assert.equal(gap.running,false);assert.deepEqual({...gap.pendingGap},{from:T0+2*MIN,to:T0+42*MIN});
assert.equal(F.elapsed(gap,T0+60*MIN),2*MIN,'time after the last heartbeat is not counted until confirmed');
assert.equal(F.start(gap,T0+43*MIN),gap,'a timer waiting for a gap decision cannot be resumed');
const skipped=F.resolveGap(gap,false,T0+43*MIN);
assert.equal(F.elapsed(skipped,T0+43*MIN),2*MIN);assert.equal(skipped.gapMs,40*MIN);assert.equal(skipped.gapCounted,0);
const counted=F.resolveGap(gap,true,T0+43*MIN);
assert.equal(F.elapsed(counted,T0+43*MIN),25*MIN,'a counted gap is capped at the end of the countdown');
assert.equal(counted.gapCounted,23*MIN);
const rec=F.record(F.start(skipped,T0+43*MIN),T0+50*MIN,'提前结束');
assert.equal(rec.seconds,9*60);assert.equal(rec.interrupted,true);assert.equal(F.kindOf(rec),'异常中断');assert.equal(rec.pomodoro,false);

// Count-up timers never finish on their own.
let up=F.start(F.create({direction:'up',now:T0}),T0);
assert.equal(F.finished(up,T0+500*MIN),false);assert.equal(F.remaining(up,T0),null);
assert.equal(F.record(up,T0+40*MIN,'完成').pomodoro,false,'only countdowns count as pomodoros');

// Settings fall back to defaults for invalid values.
assert.equal(F.settings({settings:{focus:{focus:50,short:0,longEvery:99,sound:false}}}).focus,50);
assert.equal(F.settings({settings:{focus:{focus:50,short:0}}}).short,5);
assert.equal(F.settings({settings:{focus:{longEvery:99}}}).longEvery,4);
assert.equal(F.settings({}).sound,true);

// Statistics read only saved records.
const m=F.manual({id:'m1',label:'整理错题',subject:'高数',date:'2026-10-24',time:'20:00',minutes:30,now:T0});
assert.equal(m.source,'补录');assert.equal(m.pomodoro,false);assert.equal(F.kindOf(m),'补录');assert.equal(m.end,new Date(Date.parse('2026-10-24T20:30:00+08:00')).toISOString());
const data={tasks:[],focusSessions:[done,rec,m,{id:'bad',date:'2026-10-24',seconds:0}]};
const sum=F.totals(F.inRange(data,'2026-10-24','2026-10-24'));
assert.equal(sum.sessions,3,'empty records are ignored');assert.equal(sum.pomodoros,1);
assert.equal(sum.seconds,25*60+9*60+30*60);
assert.equal(sum.bySubject['408'],25*60+9*60);assert.equal(sum.bySubject['数学'],30*60,'subjects are grouped like the rest of the site');
assert.equal(F.totals(F.inRange(data,'2026-10-25','2026-10-31')).seconds,0);
const week=F.daily(data,'2026-10-19',7,addDays);
assert.equal(week.length,7);assert.equal(week[5].date,'2026-10-24');assert.equal(week[5].seconds,sum.seconds);
assert.equal(F.forTask(data,'a').pomodoros,1);
const line=F.timeline(data,'2026-10-24');
assert.equal(line[0].from,9*60);assert.equal(line.at(-1).from,20*60);assert.equal(line.at(-1).to,20*60+30);
assert.equal(F.day(Date.parse('2026-10-24T23:30:00+08:00')),'2026-10-24','dates use Beijing time');

// Focus records merge by id across devices and tabs.
const syncContext=vm.createContext({window:{},JSON,Map,Set});vm.runInContext(read('public/local-sync.js'),syncContext);
const merged=syncContext.window.mergeStudy({focusSessions:[]},{focusSessions:[done]},{focusSessions:[done,m]});
assert.equal(merged.data.focusSessions.length,2,'the same record from two tabs is kept once');
assert.equal(merged.conflicts.length,0);
console.log('study focus tests passed');
