/* No account data is read until the server has identified the current visitor. */
(async function () {
  const boot=document.getElementById('bootScreen');
  const load=src=>new Promise((resolve,reject)=>{const s=document.createElement('script');s.src=src;s.onload=resolve;s.onerror=()=>reject(Error('页面资源加载失败'));document.body.appendChild(s);});
  function fail(title,message){boot.innerHTML='';const h=document.createElement('h1'),p=document.createElement('p'),a=document.createElement('a');h.textContent=title;p.textContent=message;a.href='/signin-with-chatgpt?return_to=%2F';a.target='_top';a.className='btn primary';a.textContent='使用 ChatGPT 登录';boot.append(h,p,a);}
  try {
    const response=await fetch('/api/session',{credentials:'same-origin',cache:'no-store'});
    if(!response.ok){fail('打开你自己的学习空间','请先登录。每个人的计划、错题与进度分别保存。');return;}
    const session=await response.json();
    if(!session.authenticated||!/^[a-f0-9]{64}$/.test(session.cacheScope))throw Error('无法确认当前账号，请重新登录');
    window.StudySession={...session,cacheKey:'xilien-study-v2:'+session.cacheScope,databaseName:'xilien-study-local:'+session.cacheScope};
    // Old storage is retained. A newly signed-in visitor never reads it.
    if(session.legacyCacheEligible&&!localStorage.getItem(window.StudySession.cacheKey)){
      await migrateLegacyCache(window.StudySession);
    }
    // 数据与同步 → 旧版基础函数 → 错题表单与 CSV → 计算 → 记录规则 → 界面
    for(const src of ['/local-sync.js','/study-core.js','/mistake-notebook.js','/study-model.js','/study-focus-model.js','/study-ui.js','/study-focus.js','/study-views.js'])await load(src);
    document.body.classList.remove('booting');boot.remove();
    window.initFocus?.();
    await window.startStudySession();
  }catch(error){fail('暂时无法连接学习空间',error.message||'请检查网络后刷新。尚未载入账号数据。');}

  async function migrateLegacyCache(session){
    try {
      let oldDatabase=null;
      const old=await new Promise(resolve=>{const req=indexedDB.open('xilien-study-local',1);req.onupgradeneeded=()=>req.transaction.abort();req.onerror=()=>resolve(null);req.onsuccess=()=>{oldDatabase=req.result;if(!oldDatabase.objectStoreNames.contains('state'))return resolve(null);const tx=oldDatabase.transaction('state','readonly'),get=tx.objectStore('state').get('current');get.onsuccess=()=>resolve(get.result||null);get.onerror=()=>resolve(null);};});
      const local=localStorage.getItem('xilien-study-v1'),localStamp=Number(localStorage.getItem('xilien-study-v1-stamp')||0);
      const snapshot=old&&old.stamp>=localStamp?old:local?{data:JSON.parse(local),base:old?.base||null,revision:Number(localStorage.getItem('xilien-study-v1-revision')||0),dirty:localStorage.getItem('xilien-study-v1-dirty')==='1',stamp:localStamp}:old;
      if(!snapshot)return;
      localStorage.setItem(session.cacheKey,JSON.stringify(snapshot.data));localStorage.setItem(session.cacheKey+'-revision',String(snapshot.revision||0));localStorage.setItem(session.cacheKey+'-stamp',String(snapshot.stamp||Date.now()));if(snapshot.dirty)localStorage.setItem(session.cacheKey+'-dirty','1');
      const database=await new Promise((resolve,reject)=>{const req=indexedDB.open(session.databaseName,1);req.onupgradeneeded=()=>req.result.createObjectStore('state');req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});
      const backups={};if(oldDatabase)for(const key of ['ui-prechange','ui-redesign-baseline'])backups[key]=await new Promise(resolve=>{const get=oldDatabase.transaction('state','readonly').objectStore('state').get(key);get.onsuccess=()=>resolve(get.result);get.onerror=()=>resolve(null);});
      await new Promise((resolve,reject)=>{const tx=database.transaction('state','readwrite'),store=tx.objectStore('state');store.put(snapshot,'current');Object.entries(backups).forEach(([key,value])=>{if(value)store.put(value,key);});tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});
      for(const suffix of ['-prechange','-redesign-baseline']){const value=localStorage.getItem('xilien-study-v1'+suffix);if(value)localStorage.setItem(session.cacheKey+suffix,value);}
      database.close();oldDatabase?.close();
    }catch { /* Keep every legacy byte intact; the authenticated cloud copy remains available. */ }
  }
})();
