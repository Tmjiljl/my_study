# Learning Workspace Redesign Implementation Plan

**Goal:** Make the existing study hub easier to use with a blue and white learning workspace inspired by cxyonly.fans.

**Architecture:** Add study-workspace.js and study-workspace.css after the existing UI layer, reusing record calculations, dialogs, account isolation and sync. Add subject workspaces, a practice center and a task focus view without changing the record schema. welcome-workspace.css aligns the public sign-in page.

**Tech Stack:** Vanilla browser JavaScript/CSS, existing Vinext host and D1 persistence.

**Scope:** Existing Site appgprj_6acbcdb20acc81919cb593c76089842e. Keep its audience and identity. Reference observations come from the public learning shell stylesheet and dashboard modules; browser inspection was unavailable.

## Tasks

- [x] Replace navigation and dashboard with clear actions, real counts, subject entries and a seven-day actual-time view.
- [x] Add subject workspaces, task focus view and practice center linking directly to https://cxyonly.fans/math.
- [x] Apply a responsive blue/white theme across existing dialogs, plans, notebook and progress; update the public welcome screen.
- [x] Run existing isolated UI/account checks and checks for new navigation, canceled task actions and empty states; build the app.
- [ ] Package the pushed source, save a version, publish to the existing Site and report the result.

## Review focus

- Render and navigation must not write or mark existing study records complete.
- Starting a task must show its full text, and completion must require the user's explicit action.
- Unknown actual minutes remain unknown, distinct from zero and planned minutes.
- Empty subjects and removed task IDs must have usable fallbacks.
- Mobile navigation, dark mode, keyboard focus and dialogs must remain available.

## Verification completed before publication

- Isolated DOM checks pass for view-only navigation, four subject workspaces, the practice URL, missing tasks, empty data, chapter disclosure, explicit task completion and preservation of unknown actual minutes.
- Account checks pass for anonymous rejection, per-user scope and cross-account isolation.
- Production build succeeds.
- Browser preview checked at desktop width and at 390 × 844: five mobile destinations, task focus view, dark theme and no horizontal overflow. Preview uses synthetic records only.
