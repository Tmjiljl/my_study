# Local UI preview server (development only, never deployed).
# Serves public/ and fakes /api/session and /api/sync with in-memory synthetic data from seed.json.
# It never connects to the hosted database or any real account.
# Kept ASCII-only so Windows PowerShell 5.1 parses it regardless of file encoding.
# With -Persist, the archive is kept in local-data.json next to this script and survives restarts.
param([int]$Port = 5180, [switch]$Persist)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$public = [IO.Path]::GetFullPath((Join-Path $root 'public'))
$tz = [TimeZoneInfo]::FindSystemTimeZoneById('China Standard Time')
$today = [TimeZoneInfo]::ConvertTimeFromUtc([DateTime]::UtcNow, $tz).Date
$seedText = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'seed.json'), [Text.Encoding]::UTF8)
$seedText = [regex]::Replace($seedText, '\{\{D(-?\d+)\}\}', { param($m) $today.AddDays([int]$m.Groups[1].Value).ToString('yyyy-MM-dd') })
if ($env:STUDY_PREVIEW_EMPTY -eq '1') { $seedText = '{"tasks":[],"logs":[],"mistakes":[],"reports":[],"progress":{},"history":[],"chat":[]}' }
$state = @{ data = $seedText; revision = 1 }
$dataFile = Join-Path $PSScriptRoot 'local-data.json'
if ($Persist -and (Test-Path -LiteralPath $dataFile)) {
  $saved = [IO.File]::ReadAllText($dataFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
  $state.data = $saved.data; $state.revision = [int]$saved.revision
}
function SaveState {
  if (-not $Persist) { return }
  $tmp = $dataFile + '.tmp'
  [IO.File]::WriteAllText($tmp, '{"revision":' + $state.revision + ',"data":' + (ConvertTo-Json $state.data -Compress) + '}', $utf8)
  Move-Item -LiteralPath $tmp -Destination $dataFile -Force
}
$types = @{ '.html'='text/html; charset=utf-8'; '.js'='text/javascript; charset=utf-8'; '.css'='text/css; charset=utf-8'; '.svg'='image/svg+xml'; '.json'='application/json; charset=utf-8' }
$utf8 = New-Object Text.UTF8Encoding($false)
$listener = New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback, $Port)
$listener.Start()
Write-Host "Study preview on http://localhost:$Port/ (today $($today.ToString('yyyy-MM-dd')))"

function Reply($stream, [int]$status, [string]$type, [byte[]]$body) {
  $reason = @{200='OK';404='Not Found';500='Server Error'}[$status]
  $head = "HTTP/1.1 $status $reason`r`nContent-Type: $type`r`nContent-Length: $($body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n"
  $h = [Text.Encoding]::ASCII.GetBytes($head)
  $stream.Write($h, 0, $h.Length); $stream.Write($body, 0, $body.Length); $stream.Flush()
}
function ReplyJson($stream, [string]$json) { Reply $stream 200 'application/json; charset=utf-8' ($utf8.GetBytes($json)) }

while ($true) {
  $client = $listener.AcceptTcpClient()
  try {
    $client.ReceiveTimeout = 5000
    $stream = $client.GetStream()
    # Read headers byte by byte until a blank line, then the body by Content-Length.
    $buffer = New-Object IO.MemoryStream
    $last4 = 0
    while ($true) {
      $b = $stream.ReadByte(); if ($b -lt 0) { break }
      $buffer.WriteByte([byte]$b)
      $last4 = (($last4 -shl 8) -bor $b) -band 0xFFFFFFFF
      if ($last4 -eq 0x0D0A0D0A) { break }
    }
    $headerText = [Text.Encoding]::ASCII.GetString($buffer.ToArray())
    $lines = $headerText -split "`r`n"
    $parts = $lines[0] -split ' '
    if ($parts.Length -lt 2) { $client.Close(); continue }
    $method = $parts[0]; $target = $parts[1]
    $length = 0
    foreach ($line in $lines) { if ($line -match '^Content-Length:\s*(\d+)') { $length = [int]$Matches[1] } }
    $body = New-Object byte[] $length
    $read = 0
    while ($read -lt $length) { $n = $stream.Read($body, $read, $length - $read); if ($n -le 0) { break }; $read += $n }
    $path = ($target -split '\?')[0]
    $query = if ($target.Contains('?')) { ($target -split '\?', 2)[1] } else { '' }
    $path = [Uri]::UnescapeDataString($path)

    if ($path -eq '/api/session') {
      ReplyJson $stream ('{"authenticated":true,"cacheScope":"' + ('b' * 64) + '","displayName":"预览账号（示例数据）","legacyCacheEligible":false}')
    } elseif ($path -eq '/api/sync') {
      if ($method -eq 'PUT') {
        $text = $utf8.GetString($body)
        $start = $text.IndexOf('"data":') + 7; $end = $text.LastIndexOf(',"revision"')
        $state.data = $text.Substring($start, $end - $start); $state.revision++
        SaveState
        ReplyJson $stream ('{"revision":' + $state.revision + '}')
      } elseif ($query -match '(^|&)meta=1') {
        ReplyJson $stream ('{"revision":' + $state.revision + '}')
      } else {
        ReplyJson $stream ('{"data":' + $state.data + ',"revision":' + $state.revision + '}')
      }
    } else {
      if ($path -eq '/') { $path = '/study.html' }
      $file = [IO.Path]::GetFullPath((Join-Path $public ($path.TrimStart('/') -replace '/', '\')))
      if ($file.StartsWith($public) -and (Test-Path -LiteralPath $file -PathType Leaf)) {
        $type = $types[[IO.Path]::GetExtension($file).ToLower()]; if (-not $type) { $type = 'application/octet-stream' }
        Reply $stream 200 $type ([IO.File]::ReadAllBytes($file))
      } else {
        Reply $stream 404 'text/plain' ([Text.Encoding]::ASCII.GetBytes('not found'))
      }
    }
  } catch {
    try { Reply $stream 500 'text/plain' ([Text.Encoding]::ASCII.GetBytes($_.Exception.Message)) } catch {}
  } finally { $client.Close() }
}
