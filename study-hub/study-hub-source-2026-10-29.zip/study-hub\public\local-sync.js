/* Local-first cache. Cloudflare D1 remains the shared, authenticated source for ChatGPT tools. */
(function (global) {
  const clone = value => value === undefined ? undefined : JSON.parse(JSON.stringify(value));
  const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  const keyFor = (kind, row) => kind === 'logs' ? row.date : kind === 'reports' ? [row.type,row.date,row.end || ''].join('|') : kind === 'history' || kind === 'chat' ? row.id || JSON.stringify(row) : row.id;
  function mergeValue(base, local, remote, path, conflicts, preference) {
    if (same(local, base)) return clone(remote);
    if (same(remote, base) || same(local, remote)) return clone(local);
    if (local && remote && typeof local === 'object' && typeof remote === 'object' && !Array.isArray(local) && !Array.isArray(remote)) {
      const result = {};
      for (const k of new Set([...Object.keys(base || {}),...Object.keys(local),...Object.keys(remote)])) {
        const v = mergeValue(base?.[k], local[k], remote[k], path + '.' + k, conflicts, preference);
        if (v !== undefined) result[k] = v;
      }
      return result;
    }
    conflicts.push(path);
    return clone(preference === 'remote' ? remote : local);
  }
  function mergeCollection(kind, base, local, remote, conflicts, preference) {
    const b = new Map((base || []).map(v => [keyFor(kind,v),v]));
    const l = new Map((local || []).map(v => [keyFor(kind,v),v]));
    const r = new Map((remote || []).map(v => [keyFor(kind,v),v]));
    const result = [];
    for (const key of new Set([...r.keys(),...l.keys(),...b.keys()])) {
      const value = mergeValue(b.get(key), l.get(key), r.get(key), kind + ':' + key, conflicts, preference);
      if (value !== undefined) result.push(value);
    }
    return result;
  }
  function mergeStudy(base, local, remote, preference) {
    const conflicts = [], result = {};
    for (const kind of new Set([...Object.keys(base || {}),...Object.keys(local || {}),...Object.keys(remote || {})])) {
      result[kind] = ['tasks','logs','mistakes','reports','history','chat','audit','deletedRecords','focusSessions'].includes(kind)
        ? mergeCollection(kind,base?.[kind],local?.[kind],remote?.[kind],conflicts,preference)
        : mergeValue(base?.[kind],local?.[kind],remote?.[kind],kind,conflicts,preference);
    }
    // Different IDs may intentionally represent repeated practice. Never discard
    // a record just because its topic, date or question matches another record.
    return {data:result,conflicts};
  }
  function openLocalDb(name) {
    return new Promise((resolve,reject) => {
      if (!global.indexedDB) {reject(new Error('IndexedDB 不可用'));return;}
      const request = global.indexedDB.open(name,1);
      request.onupgradeneeded = () => request.result.createObjectStore('state');
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);
    });
  }
  function transaction(database, mode, action) {
    return new Promise((resolve,reject) => {
      const tx = database.transaction('state',mode), request = action(tx.objectStore('state'));
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
      tx.onerror = () => reject(tx.error);
    });
  }
  class StudySync {
    constructor({key,read,apply,status}) {
      this.key=key;this.read=read;this.apply=apply;this.status=status;
      this.databaseName=global.StudySession?.databaseName || 'xilien-study-local:test';
      this.scope=global.StudySession?.cacheScope || '';
      this.revision=Number(localStorage.getItem(key+'-revision') || 0);
      this.dirty=localStorage.getItem(key+'-dirty') === '1';
      this.base=null;this.seq=0;this.saving=false;this.conflict=null;
      this.delay=1500;this.timer=null;this.writeChain=Promise.resolve();this.database=null;
      this.polling=false;this.started=false;
    }
    snapshot() {return {data:clone(this.read()),base:clone(this.base),revision:this.revision,dirty:this.dirty,stamp:Date.now()};}
    persist() {
      const snapshot=this.snapshot();
      try {
        localStorage.setItem(this.key,JSON.stringify(snapshot.data));
        localStorage.setItem(this.key+'-revision',String(snapshot.revision));
        localStorage.setItem(this.key+'-stamp',String(snapshot.stamp));
        if (snapshot.dirty) localStorage.setItem(this.key+'-dirty','1'); else localStorage.removeItem(this.key+'-dirty');
      } catch {this.status('本机缓存已满，正在使用 IndexedDB','bad');}
      if (!this.database) return Promise.resolve();
      this.writeChain=this.writeChain.catch(()=>{}).then(()=>transaction(this.database,'readwrite',s=>s.put(snapshot,'current')));
      return this.writeChain.catch(()=>this.status('本机数据库写入失败，请导出备份','bad'));
    }
    save() {
      this.seq++;this.dirty=true;
      void this.persist();
      this.status('本机已保存 · 待同步','wait');
      this.schedule(350);
    }
    schedule(delay) {
      if (this.conflict || !this.started) return;
      clearTimeout(this.timer);
      this.timer=setTimeout(()=>{this.timer=null;void this.flush()},delay);
    }
    async start() {
      this.status('本机数据已可用 · 正在后台连接','wait');
      try {
        this.database=await openLocalDb(this.databaseName);
        const existing=await transaction(this.database,'readonly',s=>s.get('current'));
        if (existing && this.seq===0) {
          if (Number(localStorage.getItem(this.key+'-stamp') || 0)>existing.stamp) {
            this.base=null;this.dirty=localStorage.getItem(this.key+'-dirty')==='1';
          } else {
            this.revision=existing.revision || 0;this.base=existing.base || null;
            this.dirty=!!existing.dirty;this.apply(existing.data);
          }
          void this.persist();
        } else if (!existing && this.seq===0) {
          // One-time migration of the previous localStorage cache into IndexedDB.
          void this.persist();
        }
      } catch {this.status('IndexedDB 不可用 · 本机备份仍保留','bad');}
      this.started=true;
      global.addEventListener('online',()=>void this.pull());
      global.addEventListener('focus',()=>void this.poll());
      global.document.addEventListener('visibilitychange',()=>{if(global.document.visibilityState==='visible')void this.poll();});
      setInterval(()=>{if(global.document.visibilityState==='visible' && global.navigator.onLine!==false)void this.poll();},3000);
      void this.pull();
    }
    async pull() {
      if (this.saving || this.polling || global.navigator.onLine===false) return;
      this.polling=true;
      const before=this.seq;
      try {
        const response=await fetch('/api/sync',{credentials:'same-origin',cache:'no-store',headers:{'X-Study-Scope':this.scope}});
        if(response.status===403){this.accountMismatch=true;this.status('账号已切换，请刷新后继续','bad');return;}
        if (!response.ok) throw new Error(response.status===401?'登录失效':'云端暂不可用');
        const remote=await response.json();
        if (remote.data && remote.revision !== this.revision) {
          if (this.dirty || this.seq!==before) {
            const merged=mergeStudy(this.base,this.read(),remote.data);
            if (merged.conflicts.length) {
              this.conflict={remote,conflicts:merged.conflicts};
              this.status('发现 '+merged.conflicts.length+' 处冲突 · 点击处理','bad');
              return;
            }
            this.revision=remote.revision;this.base=clone(remote.data);
            this.apply(merged.data);this.dirty=true;await this.persist();
          } else {
            this.revision=remote.revision;this.base=clone(remote.data);
            this.apply(remote.data);this.dirty=false;await this.persist();
          }
        } else if (remote.data && !this.base && !this.dirty) {
          this.base=clone(remote.data);this.apply(remote.data);await this.persist();
        } else if (!remote.data && this.revision>0) {
          this.conflict={remote,conflicts:['云端档案与本机版本不一致']};
          this.status('档案版本冲突 · 点击处理','bad');return;
        }
        if (!remote.data) {this.revision=0;this.dirty=true;await this.persist();}
        this.status(this.dirty?'本机已保存 · 正在同步':'已同步','ok');
      } catch(e) {this.status((e.message || '网络故障')+' · 本机可继续使用','bad');}
      finally {this.polling=false;if(this.dirty&&!this.conflict)this.schedule(0);}
    }
    async flush() {
      if (!this.dirty || this.saving || this.conflict || this.uiHold || this.backupBlocked || this.accountMismatch || !this.started || global.navigator.onLine===false) return;
      this.saving=true;
      const sentSeq=this.seq, sent=clone(this.read()), revision=this.revision;
      try {
        const response=await fetch('/api/sync',{method:'PUT',credentials:'same-origin',headers:{'Content-Type':'application/json','X-Study-Scope':this.scope},body:JSON.stringify({data:sent,revision})});
        if(response.status===403){this.accountMismatch=true;this.status('账号已切换，未向其他账号写入数据','bad');return;}
        if (response.status===409) {this.saving=false;await this.pull();return;}
        if (!response.ok) throw new Error('云端暂不可用');
        const result=await response.json();
        this.revision=result.revision;this.base=sent;this.delay=1500;
        this.dirty=this.seq!==sentSeq;
        await this.persist();
        this.status(this.dirty?'本机已保存 · 正在同步':'已同步');
      } catch {this.status('本机已保存 · 云端重试中','bad');this.schedule(this.delay);this.delay=Math.min(this.delay*2,30000);}
      finally {this.saving=false;if(this.dirty&&!this.timer&&!this.conflict)this.schedule(this.delay);}
    }
    async poll() {
      if(this.polling||this.saving||this.conflict||global.navigator.onLine===false)return;
      if(this.dirty){this.schedule(0);return;}
      this.polling=true;
      try {
        const response=await fetch('/api/sync?meta=1',{credentials:'same-origin',cache:'no-store',headers:{'X-Study-Scope':this.scope}});
        if(response.status===403){this.accountMismatch=true;this.status('账号已切换，请刷新后继续','bad');return;}
        if(response.ok){const head=await response.json();if(head.revision>this.revision){this.polling=false;await this.pull();return;}}
      } catch {} finally {this.polling=false;}
    }
    async syncNow() {if(this.conflict){this.showConflict();return;}await this.pull();if(this.dirty)this.schedule(0);}
    showConflict() {
      const conflict=this.conflict;if(!conflict)return;
      const escaped=conflict.conflicts.slice(0,8).map(s=>String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))).join('、');
      global.document.querySelector('#dialog').innerHTML='<div class="dialoghead"><h2>处理同步冲突</h2><button class="iconbtn" onclick="closeModal()">×</button></div><p>本机与云端同时修改了相同内容，尚未覆盖任何一方。</p><p class="muted">'+escaped+'</p><p>先导出备份，再选择相同字段使用哪个版本。其他互不冲突的修改会合并。</p><div class="toolbar"><button class="btn" onclick="exportJSON()">导出本机备份</button><button class="btn" onclick="sync.resolve(\'remote\')">冲突字段用云端</button><button class="btn primary" onclick="sync.resolve(\'local\')">冲突字段用本机</button></div>';
      global.document.querySelector('#modal').classList.add('open');
    }
    async resolve(preference) {
      if(!this.conflict)return;
      if(!global.confirm('确认已核对冲突并选择'+(preference==='local'?'本机':'云端')+'字段？建议先导出 JSON 备份。'))return;
      const remote=this.conflict.remote;
      const merged=mergeStudy(this.base,this.read(),remote.data || {},preference);
      this.revision=remote.revision;this.base=clone(remote.data || {});this.conflict=null;
      this.apply(merged.data);this.dirty=true;this.seq++;await this.persist();
      global.document.querySelector('#modal').classList.remove('open');this.schedule(0);
    }
  }
  global.StudySync=StudySync;
  global.mergeStudy=mergeStudy;
})(window);
