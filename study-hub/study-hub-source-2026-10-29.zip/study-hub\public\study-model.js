/* Pure view calculations. Original record identities and subject values stay intact. */
(function (global) {
  const group = subject => ['高数','线代','数学二','数学'].includes(subject) ? '数学' : ['英语','英语二'].includes(subject) ? '英语二' : ['408','政治'].includes(subject) ? subject : '其他';
  const number = value => value !== null && value !== undefined && value !== '' && Number.isFinite(Number(value)) && Number(value) >= 0 ? Number(value) : null;
  const matches = (subject, selected) => !selected || selected === '全部' || group(subject) === selected;
  const dayTasks = (data, date, selected) => (data.tasks || []).filter(t => t.date === date && matches(t.subject, selected));
  const due = (data, date, selected) => (data.mistakes || []).filter(m => m.next && m.next <= date && m.status !== '已掌握' && matches(m.subject, selected)).sort((a,b) => a.next.localeCompare(b.next));
  function daySummary(data, date, selected = '全部') {
    const tasks = dayTasks(data,date,selected);
    const log = (data.logs || []).find(l => l.date === date && l.confirmed !== false);
    const done = tasks.filter(t => t.status === '已完成').length;
    let actual = null;
    if (selected === '全部' && number(log?.hours) !== null) actual = number(log.hours) * 60;
    else {
      const names = new Set([...tasks.map(t=>t.subject),...Object.keys(log?.subjectHours || {})]);
      const values = [...names].filter(s=>matches(s,selected) && (selected !== '全部' || group(s) !== '其他')).map(s=>{
        const logged = number(log?.subjectHours?.[s]);
        if (logged !== null) return logged * 60;
        const known = tasks.filter(t=>t.subject===s).map(t=>number(t.actual)).filter(n=>n!==null);
        return known.length ? known.reduce((a,b)=>a+b,0) : null;
      }).filter(n=>n!==null);
      if (values.length) actual = values.reduce((a,b)=>a+b,0);
    }
    return {tasks,done,actual,planned:tasks.reduce((n,t)=>n+(number(t.duration)||0),0),completion:tasks.length && tasks.every(t=>['已完成','部分完成','未完成'].includes(t.status)) ? Math.round(done/tasks.length*100) : null};
  }
  function periodSummary(data,start,end,selected='全部') {
    const dates = [...new Set([...(data.tasks||[]).map(t=>t.date),...(data.logs||[]).map(l=>l.date)])].filter(d=>d>=start&&d<=end);
    const days = dates.map(date=>({date,...daySummary(data,date,selected)}));
    const known = days.filter(d=>d.actual!==null);
    const tasks = days.flatMap(d=>d.tasks),done=tasks.filter(t=>t.status==='已完成').length;
    return {actual:known.length?known.reduce((n,d)=>n+d.actual,0):null,recordDays:known.length,tasks:tasks.length,done,completion:tasks.length&&tasks.every(t=>['已完成','部分完成','未完成'].includes(t.status))?Math.round(done/tasks.length*100):null};
  }
  function reviewState(m) {
    if (m.status === '已掌握') return '独立通过';
    if (['重点薄弱','高频错误'].includes(m.status) && m.reviewState==='独立通过') return '独立未通过';
    if (m.reviewState) return m.reviewState;
    if (m.passedAt && !['重点薄弱','高频错误'].includes(m.status)) return '独立通过';
    return m.explainedAt ? '已讲懂' : '待独立复测';
  }
  function reviewResult(m,pass,date,addDays) {
    const passes = pass ? (Number(m.reviewPasses)||0)+1 : 0;
    const mastered = pass && passes >= 4;
    return {...m,last:date,reviewPasses:passes,reviewState:pass?'独立通过':'独立未通过',
      count:pass ? m.count : (Number(m.count)||0)+1,
      status:mastered?'已掌握':pass?'待复测':(Number(m.count)||0)+1>=3?'高频错误':'重点薄弱',
      next:mastered?'':addDays(date,pass?[3,7,14][passes-1]:1),
      ...(pass?{passedAt:date}:{}),
      reviewHistory:[...(m.reviewHistory||[]),{id:global.crypto.randomUUID(),date,pass,at:new Date().toISOString()}]};
  }
  function validate(data) {
    if (!data || typeof data !== 'object' || Array.isArray(data)) throw Error('备份不是学习档案对象');
    for (const key of ['tasks','logs','mistakes','reports']) {
      if (!Array.isArray(data[key])) throw Error('缺少 '+key+' 记录');
      const ids = new Set();
      for (const row of data[key]) {
        if (!row || typeof row !== 'object' || !row.id && !(key==='logs'&&row.date)) throw Error(key+' 中存在无效记录');
        if (key==='tasks' && (typeof row.topic!=='string'||typeof row.subject!=='string'||typeof row.date!=='string')) throw Error('任务缺少有效内容、科目或日期');
        if (key==='mistakes' && (typeof row.topic!=='string'||typeof row.subject!=='string')) throw Error('错题缺少有效知识点或科目');
        const id=row.id||row.date;
        if (ids.has(id)) throw Error(key+' 中存在重复记录 ID');
        ids.add(id);
      }
    }
    return data;
  }
  global.StudyModel={group,matches,dayTasks,due,daySummary,periodSummary,reviewState,reviewResult,validate,number};
})(globalThis);
